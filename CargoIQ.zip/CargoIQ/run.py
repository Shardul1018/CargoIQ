#!/usr/bin/env python3
"""
CargoIQ Application Runner
"""

import sys
import os
import warnings

# ── Fix torch.classes Streamlit conflict ──────────────────────────
warnings.filterwarnings("ignore")
os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
os.environ["PYTORCH_JIT"] = "0"
# ─────────────────────────────────────────────────────────────────

import argparse
from pathlib import Path

# rest of your existing run.py code below...

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))


def run_dashboard():
    """Run the Streamlit dashboard."""
    import subprocess
    
    dashboard_path = project_root / "app" / "ui" / "dashboard.py"
    
    print("🚀 Starting CargoIQ Dashboard...")
    print(f"   Dashboard: {dashboard_path}")
    print("   Press Ctrl+C to stop")
    print("")
    
    subprocess.run([
        sys.executable, "-m", "streamlit", "run",
        str(dashboard_path),
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false"
    ])


def run_cli_analysis(args):
    """Run command-line analysis."""
    from app.main import CargoIQ
    
    print("=" * 60)
    print("CargoIQ - Command Line Analysis")
    print("=" * 60)
    
    # Initialize system
    cargo_iq = CargoIQ()
    
    # Get images
    if args.images:
        image_paths = args.images
    elif args.image_dir:
        image_dir = Path(args.image_dir)
        image_paths = list(image_dir.glob("*.png")) + \
                     list(image_dir.glob("*.jpg")) + \
                     list(image_dir.glob("*.jpeg"))
        image_paths = [str(p) for p in image_paths]
    else:
        # Use simulation
        print("\nNo images provided. Running simulation with test data...")
        image_paths = [f"simulated_image_{i}.jpg" for i in range(args.num_images)]
    
    # Get declared cargo
    if args.declared:
        declared_cargo = args.declared
    else:
        declared_cargo = ["electronics", "clothing", "documents"]
    
    print(f"\nAnalyzing {len(image_paths)} images...")
    print(f"Declared cargo: {declared_cargo}")
    print("")
    
    # Run analysis
    result = cargo_iq.analyze(
        image_paths=image_paths,
        declared_cargo=declared_cargo,
        shipment_id=args.shipment_id or "CLI-001"
    )
    
    # Print results
    print("=" * 60)
    print("ANALYSIS RESULTS")
    print("=" * 60)
    print(f"\n📦 Shipment ID: {result.shipment_id}")
    print(f"📷 Images Processed: {result.images_processed}")
    print(f"🔍 Total Detections: {result.total_detections}")
    
    print(f"\n📊 Detected Objects: {result.detected_objects}")
    print(f"📈 Object Frequency: {result.object_frequency}")
    print(f"💯 Average Confidence: {result.avg_confidence:.2%}")
    
    print(f"\n⚠️  Mismatch Detected: {result.mismatch_detected}")
    print(f"🔒 Concealment Detected: {result.concealment_detected}")
    print(f"🚨 Anomaly Detected: {result.anomaly_detected}")
    
    print(f"\n📊 Risk Score: {result.risk_score:.1f}/100")
    print(f"📊 Risk Level: {result.risk_level.upper()}")
    
    print(f"\n💡 Explanation:")
    print(f"   {result.explanation}")
    
    print(f"\n✅ Recommendation:")
    print(f"   {result.recommendation}")
    
    print(f"\n⏱️  Processing Time: {result.processing_time:.2f}s")
    print("=" * 60)
    
    # Save report if requested
    if args.output:
        output_path = Path(args.output)
        
        if result.full_explanation and "full_report" in result.full_explanation:
            report = result.full_explanation["full_report"]
        else:
            report = f"""
CargoIQ Analysis Report
=======================
Shipment ID: {result.shipment_id}

Summary
-------
Images: {result.images_processed}
Detections: {result.total_detections}
Risk: {result.risk_score}/100 ({result.risk_level})

Mismatch: {result.mismatch_detected}
Concealment: {result.concealment_detected}
Anomaly: {result.anomaly_detected}

Recommendation
--------------
{result.recommendation}
"""
        
        with open(output_path, 'w') as f:
            f.write(report)
        
        print(f"\n📄 Report saved to: {output_path}")


def run_setup():
    """Run project setup."""
    from setup_project import create_directory_structure
    create_directory_structure()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="CargoIQ - AI-Powered Cargo Intelligence System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Run dashboard:
    python run.py --dashboard
    
  Analyze images:
    python run.py --analyze --images img1.jpg img2.jpg --declared electronics clothing
    
  Analyze directory:
    python run.py --analyze --image-dir ./data/input_images
    
  Run simulation:
    python run.py --analyze --num-images 10
        """
    )
    
    # Mode selection
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        '--dashboard', '-d',
        action='store_true',
        help='Run the Streamlit dashboard (default)'
    )
    mode_group.add_argument(
        '--analyze', '-a',
        action='store_true',
        help='Run command-line analysis'
    )
    mode_group.add_argument(
        '--setup', '-s',
        action='store_true',
        help='Run project setup'
    )
    
    # Analysis options
    parser.add_argument(
        '--images', '-i',
        nargs='+',
        help='Image file paths to analyze'
    )
    parser.add_argument(
        '--image-dir',
        help='Directory containing images to analyze'
    )
    parser.add_argument(
        '--num-images', '-n',
        type=int,
        default=5,
        help='Number of simulated images (when no real images provided)'
    )
    parser.add_argument(
        '--declared',
        nargs='+',
        help='Declared cargo items'
    )
    parser.add_argument(
        '--shipment-id',
        help='Shipment identifier'
    )
    parser.add_argument(
        '--output', '-o',
        help='Output file for analysis report'
    )
    
    args = parser.parse_args()
    
    # Determine mode
    if args.setup:
        run_setup()
    elif args.analyze:
        run_cli_analysis(args)
    else:
        # Default to dashboard
        run_dashboard()


if __name__ == "__main__":
    main()