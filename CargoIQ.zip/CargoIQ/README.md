# CargoIQ - AI-Powered Cargo Intelligence & Risk Analysis System

![CargoIQ Banner](https://img.shields.io/badge/CargoIQ-AI%20Cargo%20Intelligence-blue)
![Python](https://img.shields.io/badge/Python-3.8%2B-green)
![Streamlit](https://img.shields.io/badge/Streamlit-Dashboard-red)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 🎯 Overview

CargoIQ is an AI-powered cargo intelligence and risk analysis system designed to assist customs officers in analyzing cargo/X-ray images. The system provides intelligent decision support through:

- **Object Detection**: Identify objects in cargo images using AI
- **Misdeclaration Detection**: Compare detected items against declared cargo
- **Concealment Detection**: Identify suspicious patterns suggesting hidden items
- **Anomaly Detection**: Flag restricted, prohibited, or suspicious items
- **Risk Scoring**: Calculate comprehensive risk scores with context awareness
- **Decision Support**: Provide actionable recommendations for customs officers

## ✨ Features

### Core Capabilities

- 🔍 **Multi-Image Processing**: Analyze up to 50 images simultaneously
- 💾 **Intelligent Caching**: Avoid recomputation for identical images
- 📊 **Frequency Analysis**: Track object occurrences across images
- 🎯 **Confidence Handling**: Weight analysis by detection confidence
- 🧠 **Semantic Matching**: Smart category-based cargo matching
- ⚖️ **Context-Aware Risk Engine**: Dynamic risk calculation with multipliers

### Analysis Modules

| Module | Description |
|--------|-------------|
| Mismatch Detection | Compares detected vs. declared cargo |
| Concealment Detection | Identifies hidden item patterns |
| Anomaly Detection | Flags restricted/prohibited items |
| Risk Scoring | Calculates 0-100 risk score |
| Explanation Generation | Human-readable analysis reports |
| Decision Advisory | Actionable recommendations |

## 🏗️ Project Structure