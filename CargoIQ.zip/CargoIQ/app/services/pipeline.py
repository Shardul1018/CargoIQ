"""
CargoIQ Pipeline Module

This module orchestrates the complete cargo analysis pipeline,
coordinating all analysis components.
"""

from typing import Dict, List, Any, Optional, Union
from pathlib import Path
from dataclasses import dataclass
import time

from app.models.inference import InferenceEngine, get_inference_engine
from app.services.aggregator import DetectionAggregator, get_aggregator
from app.analytics.frequency import FrequencyAnalyzer, get_frequency_analyzer
from app.intelligence.semantic_matcher import SemanticMatcher, get_semantic_matcher
from app.intelligence.mismatch import MismatchDetector, get_mismatch_detector
from app.intelligence.concealment import ConcealmentDetector, get_concealment_detector
from app.intelligence.anomaly import AnomalyDetector, get_anomaly_detector
from app.intelligence.rules import RulesEngine, get_rules_engine
from app.risk_engine.scorer import RiskScorer, get_risk_scorer
from app.explainability.generator import ExplanationGenerator, get_explanation_generator
from app.decision.advisor import DecisionAdvisor, get_decision_advisor
from app.schemas.request_schema import CargoAnalysisRequest, CargoAnalysisResponse
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


class CargoPipeline:
    """
    Complete Cargo Analysis Pipeline
    
    This pipeline orchestrates the full analysis flow:
    1. Image Inference (with caching)
    2. Detection Aggregation
    3. Frequency Analysis
    4. Semantic Matching
    5. Mismatch Detection
    6. Concealment Detection
    7. Anomaly Detection
    8. Rules Evaluation
    9. Risk Scoring
    10. Explanation Generation
    11. Decision Advisory
    """
    
    def __init__(self):
        """Initialize the pipeline with all components."""
        logger.info("Initializing Cargo Analysis Pipeline...")
        
        # Initialize all components
        self.inference_engine = get_inference_engine()
        self.aggregator = get_aggregator()
        self.frequency_analyzer = get_frequency_analyzer()
        self.semantic_matcher = get_semantic_matcher()
        self.mismatch_detector = get_mismatch_detector()
        self.concealment_detector = get_concealment_detector()
        self.anomaly_detector = get_anomaly_detector()
        self.rules_engine = get_rules_engine()
        self.risk_scorer = get_risk_scorer()
        self.explanation_generator = get_explanation_generator()
        self.decision_advisor = get_decision_advisor()
        
        logger.info("Pipeline initialization complete")
    
    def _run_inference(
        self,
        request: CargoAnalysisRequest
    ) -> Dict[str, Any]:
        """Run inference on images."""
        logger.info("Running inference stage")
        
        # Determine image source
        if request.image_bytes:
            # Process from bytes (Streamlit upload)
            batch_result = self.inference_engine.infer_batch(
                images=request.image_bytes
            )
        elif request.image_paths:
            # Process from paths
            batch_result = self.inference_engine.infer_batch(
                images=request.image_paths
            )
        else:
            # No images - return empty result
            return {
                "total_images": 0,
                "total_detections": 0,
                "batch_result": None,
                "aggregation": None
            }
        
        # Aggregate detections
        aggregation = self.aggregator.aggregate(batch_result)
        
        return {
            "total_images": batch_result.total_images,
            "total_detections": batch_result.total_detections,
            "batch_result": batch_result,
            "aggregation": aggregation
        }
    
    def _run_frequency_analysis(
        self,
        all_labels: List[str],
        confidence_scores: Dict[str, float]
    ) -> Dict[str, Any]:
        """Run frequency analysis."""
        logger.info("Running frequency analysis")
        
        analysis = self.frequency_analyzer.analyze(
            detected_items=all_labels,
            confidence_scores=confidence_scores
        )
        
        return analysis.to_dict()
    
    def _run_mismatch_detection(
        self,
        detected_objects: List[str],
        declared_cargo: List[str],
        confidence_scores: Dict[str, float]
    ) -> Dict[str, Any]:
        """Run mismatch detection."""
        logger.info("Running mismatch detection")
        
        analysis = self.mismatch_detector.detect(
            detected_objects=list(set(detected_objects)),
            declared_cargo=declared_cargo,
            confidence_scores=confidence_scores
        )
        
        return analysis.to_dict()
    
    def _run_concealment_detection(
        self,
        detected_objects: List[str],
        frequency: Dict[str, int],
        confidence_scores: Dict[str, float]
    ) -> Dict[str, Any]:
        """Run concealment detection."""
        logger.info("Running concealment detection")
        
        analysis = self.concealment_detector.detect(
            detected_items=detected_objects,
            frequency=frequency,
            confidence_scores=confidence_scores
        )
        
        return analysis.to_dict()
    
    def _run_anomaly_detection(
        self,
        detected_objects: List[str],
        frequency: Dict[str, int],
        confidence_scores: Dict[str, float],
        declared_cargo: List[str]
    ) -> Dict[str, Any]:
        """Run anomaly detection."""
        logger.info("Running anomaly detection")
        
        analysis = self.anomaly_detector.detect(
            detected_items=detected_objects,
            frequency=frequency,
            confidence_scores=confidence_scores,
            declared_items=declared_cargo
        )
        
        return analysis.to_dict()
    
    def _run_risk_scoring(
        self,
        mismatch_result: Dict,
        concealment_result: Dict,
        anomaly_result: Dict,
        frequency: Dict[str, int],
        avg_confidence: float
    ) -> Dict[str, Any]:
        """Run risk scoring."""
        logger.info("Running risk scoring")
        
        assessment = self.risk_scorer.calculate(
            mismatch_detected=mismatch_result["is_mismatch_detected"],
            mismatch_confidence=avg_confidence,
            mismatch_severity=mismatch_result["mismatch_score"],
            concealment_detected=concealment_result["is_concealment_detected"],
            concealment_confidence=avg_confidence,
            concealment_severity=concealment_result["concealment_score"],
            anomaly_detected=anomaly_result["is_anomaly_detected"],
            anomaly_confidence=avg_confidence,
            anomaly_severity=anomaly_result["anomaly_score"],
            requires_immediate=anomaly_result["requires_immediate_action"],
            frequency=frequency,
            avg_detection_confidence=avg_confidence
        )
        
        return assessment.to_dict()
    
    def _run_decision_advisory(
        self,
        risk_result: Dict,
        mismatch_result: Dict,
        concealment_result: Dict,
        anomaly_result: Dict,
        avg_confidence: float,
        num_detections: int,
        num_images: int
    ) -> Dict[str, Any]:
        """Run decision advisory."""
        logger.info("Running decision advisory")
        
        decision = self.decision_advisor.advise(
            risk_score=risk_result["normalized_score"],
            risk_level=risk_result["risk_level"],
            mismatch_detected=mismatch_result["is_mismatch_detected"],
            mismatch_details=mismatch_result,
            concealment_detected=concealment_result["is_concealment_detected"],
            concealment_details=concealment_result,
            anomaly_detected=anomaly_result["is_anomaly_detected"],
            anomaly_details=anomaly_result,
            avg_detection_confidence=avg_confidence,
            num_detections=num_detections,
            num_images=num_images
        )
        
        return decision.to_dict()
    
    def _run_explanation_generation(
        self,
        shipment_id: str,
        total_images: int,
        total_detections: int,
        detected_objects: List[str],
        frequency: Dict[str, int],
        avg_confidence: float,
        mismatch_result: Dict,
        concealment_result: Dict,
        anomaly_result: Dict,
        risk_result: Dict,
        recommendation: str
    ) -> Dict[str, Any]:
        """Generate explanations."""
        logger.info("Generating explanations")
        
        explanation = self.explanation_generator.generate(
            shipment_id=shipment_id,
            total_images=total_images,
            total_detections=total_detections,
            detected_objects=detected_objects,
            frequency=frequency,
            avg_confidence=avg_confidence,
            mismatch_detected=mismatch_result["is_mismatch_detected"],
            mismatch_details=mismatch_result,
            concealment_detected=concealment_result["is_concealment_detected"],
            concealment_details=concealment_result,
            anomaly_detected=anomaly_result["is_anomaly_detected"],
            anomaly_details=anomaly_result,
            risk_score=risk_result["normalized_score"],
            risk_level=risk_result["risk_level"],
            risk_breakdown=risk_result["breakdown"],
            context_factors=risk_result["context_factors"],
            recommendation=recommendation
        )
        
        return explanation.to_dict()
    
    def process(self, request: CargoAnalysisRequest) -> CargoAnalysisResponse:
        """
        Process a cargo analysis request through the complete pipeline.
        
        Args:
            request: CargoAnalysisRequest containing images and declared cargo
        
        Returns:
            CargoAnalysisResponse with complete analysis results
        """
        start_time = time.time()
        logger.info(f"Processing cargo analysis request: {request.shipment_id}")
        
        # Stage 1: Inference
        inference_result = self._run_inference(request)
        
        if inference_result["total_images"] == 0:
            # Return empty response for no images
            return CargoAnalysisResponse(
                shipment_id=request.shipment_id,
                images_processed=0,
                total_detections=0,
                detected_objects=[],
                object_frequency={},
                avg_confidence=0.0,
                mismatch_detected=False,
                mismatch_details={},
                concealment_detected=False,
                concealment_details={},
                anomaly_detected=False,
                anomaly_details={},
                risk_score=0.0,
                risk_level="minimal",
                risk_breakdown={},
                explanation="No images provided for analysis.",
                recommendation="Please provide cargo images for analysis.",
                decision_details={},
                processing_time=time.time() - start_time
            )
        
        aggregation = inference_result["aggregation"]
        all_labels = aggregation.all_labels
        frequency = aggregation.frequency
        confidence_scores = aggregation.confidence_scores
        
        # Calculate average confidence
        if confidence_scores:
            avg_confidence = sum(confidence_scores.values()) / len(confidence_scores)
        else:
            avg_confidence = 0.8
        
        # Stage 2: Frequency Analysis
        frequency_result = self._run_frequency_analysis(all_labels, confidence_scores)
        
        # Stage 3: Mismatch Detection
        mismatch_result = self._run_mismatch_detection(
            detected_objects=all_labels,
            declared_cargo=request.declared_cargo,
            confidence_scores=confidence_scores
        )
        
        # Stage 4: Concealment Detection
        concealment_result = self._run_concealment_detection(
            detected_objects=all_labels,
            frequency=frequency,
            confidence_scores=confidence_scores
        )
        
        # Stage 5: Anomaly Detection
        anomaly_result = self._run_anomaly_detection(
            detected_objects=all_labels,
            frequency=frequency,
            confidence_scores=confidence_scores,
            declared_cargo=request.declared_cargo
        )
        
        # Stage 6: Risk Scoring
        risk_result = self._run_risk_scoring(
            mismatch_result=mismatch_result,
            concealment_result=concealment_result,
            anomaly_result=anomaly_result,
            frequency=frequency,
            avg_confidence=avg_confidence
        )
        
        # Stage 7: Decision Advisory
        decision_result = self._run_decision_advisory(
            risk_result=risk_result,
            mismatch_result=mismatch_result,
            concealment_result=concealment_result,
            anomaly_result=anomaly_result,
            avg_confidence=avg_confidence,
            num_detections=inference_result["total_detections"],
            num_images=inference_result["total_images"]
        )
        
        # Stage 8: Explanation Generation
        explanation_result = self._run_explanation_generation(
            shipment_id=request.shipment_id,
            total_images=inference_result["total_images"],
            total_detections=inference_result["total_detections"],
            detected_objects=list(set(all_labels)),
            frequency=frequency,
            avg_confidence=avg_confidence,
            mismatch_result=mismatch_result,
            concealment_result=concealment_result,
            anomaly_result=anomaly_result,
            risk_result=risk_result,
            recommendation=decision_result["primary_action"]
        )
        
        processing_time = time.time() - start_time
        
        # Build response
        response = CargoAnalysisResponse(
            shipment_id=request.shipment_id,
            images_processed=inference_result["total_images"],
            total_detections=inference_result["total_detections"],
            detected_objects=list(set(all_labels)),
            object_frequency=frequency,
            avg_confidence=avg_confidence,
            mismatch_detected=mismatch_result["is_mismatch_detected"],
            mismatch_details=mismatch_result,
            concealment_detected=concealment_result["is_concealment_detected"],
            concealment_details=concealment_result,
            anomaly_detected=anomaly_result["is_anomaly_detected"],
            anomaly_details=anomaly_result,
            risk_score=risk_result["normalized_score"],
            risk_level=risk_result["risk_level"],
            risk_breakdown=risk_result["breakdown"],
            explanation=explanation_result["summary"],
            full_explanation=explanation_result,
            recommendation=decision_result["primary_action"],
            decision_details=decision_result,
            processing_time=processing_time
        )
        
        logger.info(
            f"Pipeline complete for {request.shipment_id}. "
            f"Risk: {response.risk_score:.1f} ({response.risk_level}). "
            f"Time: {processing_time:.2f}s"
        )
        
        return response


# Create singleton instance
_pipeline_instance: Optional[CargoPipeline] = None


def get_pipeline() -> CargoPipeline:
    """Get or create the singleton pipeline instance."""
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = CargoPipeline()
    return _pipeline_instance