"""
CargoIQ Detection Aggregator Module

This module aggregates detections from multiple images,
combining and summarizing results for analysis.
"""

from typing import Dict, List, Any, Optional, Tuple
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from app.models.inference import BatchInferenceResult, ImageInferenceResult
from app.models.detector import Detection
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class AggregatedDetection:
    """Aggregated detection across multiple images."""
    label: str
    total_count: int
    image_count: int  # Number of images where detected
    max_confidence: float
    min_confidence: float
    avg_confidence: float
    occurrences: List[Dict]  # Per-image occurrences
    
    def to_dict(self) -> Dict:
        return {
            "label": self.label,
            "total_count": self.total_count,
            "image_count": self.image_count,
            "max_confidence": round(self.max_confidence, 4),
            "min_confidence": round(self.min_confidence, 4),
            "avg_confidence": round(self.avg_confidence, 4),
            "occurrences": self.occurrences
        }


@dataclass
class AggregationResult:
    """Complete aggregation result."""
    total_images: int
    total_detections: int
    unique_labels: int
    aggregated_detections: List[AggregatedDetection]
    all_labels: List[str]
    frequency: Dict[str, int]
    confidence_scores: Dict[str, float]  # label -> avg confidence
    per_image_summary: List[Dict]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_images": self.total_images,
            "total_detections": self.total_detections,
            "unique_labels": self.unique_labels,
            "aggregated_detections": [d.to_dict() for d in self.aggregated_detections],
            "all_labels": self.all_labels,
            "frequency": self.frequency,
            "confidence_scores": {
                k: round(v, 4) for k, v in self.confidence_scores.items()
            },
            "per_image_summary": self.per_image_summary
        }


class DetectionAggregator:
    """
    Detection Aggregator for Multi-Image Analysis
    
    This aggregator:
    - Combines detections from multiple images
    - Calculates aggregate statistics
    - Computes frequency distributions
    - Tracks confidence across occurrences
    """
    
    def __init__(self):
        """Initialize the aggregator."""
        logger.info("Detection Aggregator initialized")
    
    def _aggregate_by_label(
        self,
        batch_result: BatchInferenceResult
    ) -> Dict[str, List[Tuple[str, Detection]]]:
        """Group detections by label."""
        by_label = defaultdict(list)
        
        for img_result in batch_result.results:
            for detection in img_result.detections:
                by_label[detection.label].append((img_result.image_id, detection))
        
        return by_label
    
    def _create_aggregated_detection(
        self,
        label: str,
        occurrences: List[Tuple[str, Detection]]
    ) -> AggregatedDetection:
        """Create aggregated detection from occurrences."""
        confidences = [d.confidence for _, d in occurrences]
        
        # Track which images contain this detection
        images = set(img_id for img_id, _ in occurrences)
        
        # Build occurrence list
        occurrence_list = []
        for img_id, detection in occurrences:
            occurrence_list.append({
                "image_id": img_id,
                "confidence": detection.confidence,
                "bbox": detection.bbox
            })
        
        return AggregatedDetection(
            label=label,
            total_count=len(occurrences),
            image_count=len(images),
            max_confidence=max(confidences),
            min_confidence=min(confidences),
            avg_confidence=sum(confidences) / len(confidences),
            occurrences=occurrence_list
        )
    
    def _calculate_frequency(
        self,
        batch_result: BatchInferenceResult
    ) -> Dict[str, int]:
        """Calculate frequency of each label."""
        all_labels = []
        for img_result in batch_result.results:
            for detection in img_result.detections:
                all_labels.append(detection.label)
        
        return dict(Counter(all_labels))
    
    def _calculate_confidence_scores(
        self,
        aggregated: List[AggregatedDetection]
    ) -> Dict[str, float]:
        """Get average confidence for each label."""
        return {d.label: d.avg_confidence for d in aggregated}
    
    def _create_per_image_summary(
        self,
        batch_result: BatchInferenceResult
    ) -> List[Dict]:
        """Create summary for each image."""
        summaries = []
        
        for img_result in batch_result.results:
            labels = [d.label for d in img_result.detections]
            confidences = [d.confidence for d in img_result.detections]
            
            summaries.append({
                "image_id": img_result.image_id,
                "detection_count": len(img_result.detections),
                "unique_labels": len(set(labels)),
                "labels": list(set(labels)),
                "avg_confidence": sum(confidences) / len(confidences) if confidences else 0,
                "inference_time": img_result.inference_time,
                "from_cache": img_result.from_cache
            })
        
        return summaries
    
    def aggregate(
        self,
        batch_result: BatchInferenceResult
    ) -> AggregationResult:
        """
        Aggregate detections from batch inference result.
        
        Args:
            batch_result: Result from batch inference
        
        Returns:
            AggregationResult with combined statistics
        """
        logger.info(f"Aggregating detections from {batch_result.total_images} images")
        
        # Handle empty results
        if batch_result.total_images == 0 or batch_result.total_detections == 0:
            return AggregationResult(
                total_images=batch_result.total_images,
                total_detections=0,
                unique_labels=0,
                aggregated_detections=[],
                all_labels=[],
                frequency={},
                confidence_scores={},
                per_image_summary=[]
            )
        
        # Group by label
        by_label = self._aggregate_by_label(batch_result)
        
        # Create aggregated detections
        aggregated = []
        for label, occurrences in by_label.items():
            agg_detection = self._create_aggregated_detection(label, occurrences)
            aggregated.append(agg_detection)
        
        # Sort by frequency
        aggregated.sort(key=lambda x: x.total_count, reverse=True)
        
        # Calculate frequency
        frequency = self._calculate_frequency(batch_result)
        
        # Get all labels
        all_labels = []
        for img_result in batch_result.results:
            for detection in img_result.detections:
                all_labels.append(detection.label)
        
        # Get confidence scores
        confidence_scores = self._calculate_confidence_scores(aggregated)
        
        # Create per-image summary
        per_image = self._create_per_image_summary(batch_result)
        
        result = AggregationResult(
            total_images=batch_result.total_images,
            total_detections=batch_result.total_detections,
            unique_labels=len(aggregated),
            aggregated_detections=aggregated,
            all_labels=all_labels,
            frequency=frequency,
            confidence_scores=confidence_scores,
            per_image_summary=per_image
        )
        
        logger.info(
            f"Aggregation complete: {result.total_detections} detections, "
            f"{result.unique_labels} unique labels"
        )
        
        return result
    
    def aggregate_from_detections(
        self,
        detections_per_image: List[List[Detection]],
        image_ids: Optional[List[str]] = None
    ) -> AggregationResult:
        """
        Aggregate from raw detection lists.
        
        Args:
            detections_per_image: List of detection lists per image
            image_ids: Optional image identifiers
        
        Returns:
            AggregationResult with combined statistics
        """
        # Create mock batch result
        if image_ids is None:
            image_ids = [f"image_{i}" for i in range(len(detections_per_image))]
        
        results = []
        total_detections = 0
        
        for img_id, detections in zip(image_ids, detections_per_image):
            results.append(ImageInferenceResult(
                image_id=img_id,
                image_hash="",
                detections=detections,
                inference_time=0,
                from_cache=False
            ))
            total_detections += len(detections)
        
        batch_result = BatchInferenceResult(
            results=results,
            total_images=len(detections_per_image),
            total_detections=total_detections,
            total_time=0,
            cache_hits=0,
            cache_misses=len(detections_per_image)
        )
        
        return self.aggregate(batch_result)


# Create singleton instance
_aggregator_instance: Optional[DetectionAggregator] = None


def get_aggregator() -> DetectionAggregator:
    """Get or create the singleton aggregator instance."""
    global _aggregator_instance
    if _aggregator_instance is None:
        _aggregator_instance = DetectionAggregator()
    return _aggregator_instance