"""
CargoIQ Services Package

This package contains service modules for orchestrating the analysis pipeline.
"""

from app.services.pipeline import CargoPipeline
from app.services.aggregator import DetectionAggregator

__all__ = ["CargoPipeline", "DetectionAggregator"]