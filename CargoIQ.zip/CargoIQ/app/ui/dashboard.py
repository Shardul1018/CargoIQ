"""
CargoIQ Streamlit Dashboard

This module provides the main user interface for the CargoIQ system,
allowing users to upload cargo images and view analysis results.
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from PIL import Image
import io
import time
from typing import List, Dict, Any, Optional

from app.config import ui_config, PATHS
from app.main import CargoIQ
from app.schemas.request_schema import CargoAnalysisRequest, CargoAnalysisResponse
from app.utils.logger import get_logger
from app.utils.image_utils import load_image, create_image_grid, create_thumbnail


# Initialize logger
logger = get_logger(__name__)


# =============================================================================
# PAGE CONFIGURATION
# =============================================================================

def setup_page():
    """Configure Streamlit page settings."""
    st.set_page_config(
        page_title=ui_config.page_title,
        page_icon=ui_config.page_icon,
        layout=ui_config.layout,
        initial_sidebar_state="expanded"
    )
    
    # Custom CSS
    st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1E3A5F;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
    }
    .risk-critical {
        background-color: #ff4b4b;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        font-weight: bold;
    }
    .risk-high {
        background-color: #ffa500;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        font-weight: bold;
    }
    .risk-medium {
        background-color: #ffcc00;
        color: black;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        font-weight: bold;
    }
    .risk-low {
        background-color: #90EE90;
        color: black;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        font-weight: bold;
    }
    .risk-minimal {
        background-color: #00cc00;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        font-weight: bold;
    }
    .stAlert {
        margin-top: 1rem;
    }
    </style>
    """, unsafe_allow_html=True)


# =============================================================================
# SIDEBAR
# =============================================================================

def render_sidebar():
    """Render the sidebar with inputs."""
    with st.sidebar:
        st.markdown("## 📦 Cargo Information")
        
        # Shipment ID
        shipment_id = st.text_input(
            "Shipment ID",
            value="SHIP-001",
            help="Enter a unique identifier for this shipment"
        )
        
        # Declared cargo
        st.markdown("### Declared Cargo Items")
        declared_cargo_text = st.text_area(
            "Enter declared items (one per line)",
            value="electronics\nclothing\nbooks\ndocuments",
            height=150,
            help="List the cargo items as declared in the manifest"
        )
        declared_cargo = [
            item.strip() for item in declared_cargo_text.split('\n') 
            if item.strip()
        ]
        
        st.markdown(f"**{len(declared_cargo)} items declared**")
        
        # Origin/Destination
        st.markdown("### Shipment Route")
        col1, col2 = st.columns(2)
        with col1:
            origin = st.text_input("Origin", value="CN")
        with col2:
            destination = st.text_input("Destination", value="US")
        
        # Analysis options
        st.markdown("### Analysis Options")
        detailed_output = st.checkbox("Detailed Output", value=True)
        skip_cache = st.checkbox("Skip Cache", value=False)
        
        # System info
        st.markdown("---")
        st.markdown("### System Info")
        
        # Initialize CargoIQ to get status
        if 'cargo_iq' not in st.session_state:
            st.session_state.cargo_iq = CargoIQ()
        
        status = st.session_state.cargo_iq.get_system_status()
        
        if status['model_config']['simulation_mode']:
            st.warning("⚠️ Running in Simulation Mode")
        else:
            st.success("✅ Model Loaded")
        
        return {
            "shipment_id": shipment_id,
            "declared_cargo": declared_cargo,
            "origin": origin,
            "destination": destination,
            "detailed_output": detailed_output,
            "skip_cache": skip_cache
        }


# =============================================================================
# IMAGE UPLOAD
# =============================================================================

def render_image_upload():
    """Render image upload section."""
    st.markdown("## 📷 Upload Cargo Images")
    
    uploaded_files = st.file_uploader(
        "Upload cargo/X-ray images",
        type=ui_config.allowed_formats,
        accept_multiple_files=True,
        help=f"Upload up to {ui_config.max_upload_images} images"
    )
    
    if uploaded_files:
        if len(uploaded_files) > ui_config.max_upload_images:
            st.warning(
                f"Maximum {ui_config.max_upload_images} images allowed. "
                f"Only first {ui_config.max_upload_images} will be processed."
            )
            uploaded_files = uploaded_files[:ui_config.max_upload_images]
        
        st.markdown(f"**{len(uploaded_files)} images uploaded**")
        
        # Display thumbnails
        with st.expander("Preview Uploaded Images", expanded=False):
            cols = st.columns(min(5, len(uploaded_files)))
            for i, file in enumerate(uploaded_files):
                col_idx = i % 5
                with cols[col_idx]:
                    img = Image.open(file)
                    st.image(img, caption=file.name, use_column_width=True)
                    # Reset file position
                    file.seek(0)
    
    return uploaded_files


# =============================================================================
# RESULTS DISPLAY
# =============================================================================

def render_risk_gauge(risk_score: float, risk_level: str):
    """Render risk score gauge chart."""
    # Determine color based on level
    colors = {
        "minimal": "#00cc00",
        "low": "#90EE90",
        "medium": "#ffcc00",
        "high": "#ffa500",
        "critical": "#ff4b4b"
    }
    color = colors.get(risk_level, "#666")
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=risk_score,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "Risk Score", 'font': {'size': 24}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1},
            'bar': {'color': color},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 25], 'color': '#e8f5e9'},
                {'range': [25, 50], 'color': '#fff9c4'},
                {'range': [50, 75], 'color': '#ffe0b2'},
                {'range': [75, 90], 'color': '#ffccbc'},
                {'range': [90, 100], 'color': '#ffcdd2'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': risk_score
            }
        }
    ))
    
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig


def render_frequency_chart(frequency: Dict[str, int]):
    """Render object frequency bar chart."""
    if not frequency:
        return None
    
    # Sort by frequency
    sorted_freq = sorted(frequency.items(), key=lambda x: x[1], reverse=True)
    
    # Take top 15
    top_items = sorted_freq[:15]
    
    df = pd.DataFrame(top_items, columns=['Object', 'Count'])
    
    fig = px.bar(
        df,
        x='Count',
        y='Object',
        orientation='h',
        title='Detected Objects Frequency',
        color='Count',
        color_continuous_scale='Blues'
    )
    
    fig.update_layout(
        height=400,
        yaxis={'categoryorder': 'total ascending'},
        showlegend=False
    )
    
    return fig


def render_detection_summary(response: CargoAnalysisResponse):
    """Render detection summary metrics."""
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Images Processed",
            value=response.images_processed
        )
    
    with col2:
        st.metric(
            label="Total Detections",
            value=response.total_detections
        )
    
    with col3:
        st.metric(
            label="Unique Objects",
            value=len(response.detected_objects)
        )
    
    with col4:
        st.metric(
            label="Avg Confidence",
            value=f"{response.avg_confidence:.1%}"
        )


def render_analysis_status(response: CargoAnalysisResponse):
    """Render analysis status indicators."""
    st.markdown("### Analysis Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if response.mismatch_detected:
            st.error("⚠️ Mismatch Detected")
        else:
            st.success("✅ No Mismatch")
    
    with col2:
        if response.concealment_detected:
            st.error("🔒 Concealment Detected")
        else:
            st.success("✅ No Concealment")
    
    with col3:
        if response.anomaly_detected:
            st.error("🚨 Anomaly Detected")
        else:
            st.success("✅ No Anomaly")


def render_risk_level_badge(risk_level: str):
    """Render risk level badge."""
    badge_classes = {
        "minimal": "risk-minimal",
        "low": "risk-low",
        "medium": "risk-medium",
        "high": "risk-high",
        "critical": "risk-critical"
    }
    
    badge_class = badge_classes.get(risk_level, "risk-medium")
    
    st.markdown(
        f'<span class="{badge_class}">{risk_level.upper()}</span>',
        unsafe_allow_html=True
    )


def render_detailed_results(response: CargoAnalysisResponse):
    """Render detailed analysis results."""
    
    # Create tabs for different result sections
    tabs = st.tabs([
        "📊 Overview",
        "🔍 Detections",
        "⚠️ Mismatch",
        "🔒 Concealment",
        "🚨 Anomaly",
        "📋 Decision",
        "📄 Full Report"
    ])
    
    # Overview Tab
    with tabs[0]:
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.plotly_chart(
                render_risk_gauge(response.risk_score, response.risk_level),
                use_container_width=True
            )
        
        with col2:
            st.markdown("### Risk Assessment")
            st.markdown(f"**Risk Level:** ", unsafe_allow_html=True)
            render_risk_level_badge(response.risk_level)
            st.markdown(f"**Risk Score:** {response.risk_score:.1f}/100")
            st.markdown("---")
            st.markdown("**Risk Breakdown:**")
            
            if response.risk_breakdown:
                for key, value in response.risk_breakdown.items():
                    if value > 0:
                        st.markdown(f"- {key}: {value:.1f}")
        
        st.markdown("### Explanation")
        st.info(response.explanation)
        
        st.markdown("### Recommendation")
        if response.risk_level in ["high", "critical"]:
            st.error(f"🚨 {response.recommendation}")
        elif response.risk_level == "medium":
            st.warning(f"⚠️ {response.recommendation}")
        else:
            st.success(f"✅ {response.recommendation}")
    
    # Detections Tab
    with tabs[1]:
        st.markdown("### Detected Objects")
        
        if response.object_frequency:
            fig = render_frequency_chart(response.object_frequency)
            if fig:
                st.plotly_chart(fig, use_container_width=True)
            
            # Frequency table
            st.markdown("### Frequency Table")
            freq_df = pd.DataFrame(
                list(response.object_frequency.items()),
                columns=['Object', 'Count']
            ).sort_values('Count', ascending=False)
            st.dataframe(freq_df, use_container_width=True)
        else:
            st.info("No objects detected")
    
    # Mismatch Tab
    with tabs[2]:
        st.markdown("### Mismatch Analysis")
        
        if response.mismatch_detected:
            st.error("⚠️ Declaration Mismatch Detected")
            
            details = response.mismatch_details
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Matched Items:**")
                matched = details.get("matched_items", [])
                if matched:
                    for item in matched:
                        st.markdown(f"✅ {item}")
                else:
                    st.markdown("*None*")
            
            with col2:
                st.markdown("**Unmatched Items:**")
                unmatched = details.get("unmatched_items", [])
                if unmatched:
                    for item in unmatched:
                        st.markdown(f"❌ {item}")
                else:
                    st.markdown("*None*")
            
            st.markdown(f"**Severity:** {details.get('severity', 'Unknown')}")
            st.markdown(f"**Mismatch Score:** {details.get('mismatch_score', 0):.2%}")
        else:
            st.success("✅ All detected items match declared cargo")
    
    # Concealment Tab
    with tabs[3]:
        st.markdown("### Concealment Analysis")
        
        if response.concealment_detected:
            st.error("🔒 Potential Concealment Detected")
            
            details = response.concealment_details
            
            st.markdown(f"**Concealment Score:** {details.get('concealment_score', 0):.2%}")
            st.markdown(f"**Severity:** {details.get('severity', 'Unknown')}")
            
            indicators = details.get("indicators", [])
            if indicators:
                st.markdown("**Indicators Found:**")
                for ind in indicators:
                    st.markdown(f"- {ind.get('indicator_type', 'Unknown')}: {ind.get('description', '')}")
            
            risk_items = details.get("risk_items", [])
            if risk_items:
                st.markdown("**Risk Items:**")
                for item in risk_items:
                    st.markdown(f"- ⚠️ {item}")
        else:
            st.success("✅ No concealment patterns detected")
    
    # Anomaly Tab
    with tabs[4]:
        st.markdown("### Anomaly Analysis")
        
        if response.anomaly_detected:
            details = response.anomaly_details
            
            if details.get("requires_immediate_action"):
                st.error("🚨 IMMEDIATE ACTION REQUIRED")
            else:
                st.warning("⚠️ Anomalies Detected")
            
            prohibited = details.get("prohibited_items_found", [])
            restricted = details.get("restricted_items_found", [])
            suspicious = details.get("suspicious_items_found", [])
            
            if prohibited:
                st.markdown("**🚫 Prohibited Items:**")
                for item in prohibited:
                    st.error(f"• {item}")
            
            if restricted:
                st.markdown("**⚠️ Restricted Items:**")
                for item in restricted:
                    st.warning(f"• {item}")
            
            if suspicious:
                st.markdown("**❓ Suspicious Items:**")
                for item in suspicious:
                    st.info(f"• {item}")
            
            st.markdown(f"**Anomaly Score:** {details.get('anomaly_score', 0):.2%}")
        else:
            st.success("✅ No anomalies detected")
    
    # Decision Tab
    with tabs[5]:
        st.markdown("### Decision Support")
        
        decision = response.decision_details
        
        if decision:
            # Primary action
            st.markdown("### Primary Action")
            action_level = decision.get("action_level", "REVIEW")
            
            if action_level in ["ALERT", "HOLD"]:
                st.error(f"🚨 {decision.get('primary_action', 'Review required')}")
            elif action_level == "INSPECT":
                st.warning(f"🔍 {decision.get('primary_action', 'Inspection required')}")
            else:
                st.success(f"✅ {decision.get('primary_action', 'Release')}")
            
            # Action items
            action_items = decision.get("action_items", [])
            if action_items:
                st.markdown("### Action Items")
                for i, item in enumerate(action_items, 1):
                    with st.expander(f"Action {i}: {item.get('action', 'Unknown')[:50]}..."):
                        st.markdown(f"**Action:** {item.get('action', 'Unknown')}")
                        st.markdown(f"**Reason:** {item.get('reason', 'Unknown')}")
                        st.markdown(f"**Responsible:** {item.get('responsible_party', 'Unknown')}")
                        st.markdown(f"**Time Sensitivity:** {item.get('time_sensitivity', 'standard')}")
            
            # Escalation
            if decision.get("escalation_required"):
                st.error(f"⚡ **Escalation Required:** {decision.get('escalation_reason', 'See supervisor')}")
            
            # Documentation
            docs = decision.get("documentation_required", [])
            if docs:
                st.markdown("### Required Documentation")
                for doc in docs:
                    st.markdown(f"📄 {doc}")
        else:
            st.info("Decision details not available")
    
    # Full Report Tab
    with tabs[6]:
        st.markdown("### Full Analysis Report")
        
        full_exp = response.full_explanation
        
        if full_exp and "full_report" in full_exp:
            st.text(full_exp["full_report"])
            
            # Download button
            st.download_button(
                label="📥 Download Report",
                data=full_exp["full_report"],
                file_name=f"cargoiq_report_{response.shipment_id}.txt",
                mime="text/plain"
            )
        else:
            # Generate simple report
            report = f"""
CargoIQ Analysis Report
=======================
Shipment ID: {response.shipment_id}
Timestamp: {response.timestamp}

Summary
-------
Images Processed: {response.images_processed}
Total Detections: {response.total_detections}
Risk Score: {response.risk_score}/100 ({response.risk_level})

Findings
--------
Mismatch Detected: {response.mismatch_detected}
Concealment Detected: {response.concealment_detected}
Anomaly Detected: {response.anomaly_detected}

Recommendation
--------------
{response.recommendation}

Explanation
-----------
{response.explanation}
"""
            st.text(report)
            
            st.download_button(
                label="📥 Download Report",
                data=report,
                file_name=f"cargoiq_report_{response.shipment_id}.txt",
                mime="text/plain"
            )


# =============================================================================
# MAIN APPLICATION
# =============================================================================

def main():
    """Main application entry point."""
    setup_page()
    
    # Header
    st.markdown('<h1 class="main-header">📦 CargoIQ</h1>', unsafe_allow_html=True)
    st.markdown(
        '<p class="sub-header">AI-Powered Cargo Intelligence & Risk Analysis System</p>',
        unsafe_allow_html=True
    )
    
    # Sidebar inputs
    sidebar_inputs = render_sidebar()
    
    # Main content
    st.markdown("---")
    
    # Image upload
    uploaded_files = render_image_upload()
    
    # Analysis button
    st.markdown("---")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        analyze_button = st.button(
            "🔍 Analyze Cargo",
            type="primary",
            use_container_width=True,
            disabled=not uploaded_files
        )
    
    # Run analysis
    if analyze_button and uploaded_files:
        with st.spinner("Analyzing cargo images..."):
            try:
                # Initialize CargoIQ
                if 'cargo_iq' not in st.session_state:
                    st.session_state.cargo_iq = CargoIQ()
                
                cargo_iq = st.session_state.cargo_iq
                
                # Prepare image bytes
                image_bytes = []
                for file in uploaded_files:
                    image_bytes.append(file.read())
                    file.seek(0)  # Reset for potential re-use
                
                # Run analysis
                start_time = time.time()
                
                response = cargo_iq.analyze_from_bytes(
                    image_data=image_bytes,
                    declared_cargo=sidebar_inputs["declared_cargo"],
                    shipment_id=sidebar_inputs["shipment_id"]
                )
                
                processing_time = time.time() - start_time
                
                # Store results in session state
                st.session_state.analysis_result = response
                
                st.success(f"✅ Analysis complete in {processing_time:.2f} seconds!")
                
            except Exception as e:
                st.error(f"❌ Error during analysis: {str(e)}")
                logger.error(f"Analysis error: {e}")
                return
    
    # Display results if available
    if 'analysis_result' in st.session_state:
        response = st.session_state.analysis_result
        
        st.markdown("---")
        st.markdown("## 📊 Analysis Results")
        
        # Detection summary
        render_detection_summary(response)
        
        st.markdown("---")
        
        # Analysis status
        render_analysis_status(response)
        
        st.markdown("---")
        
        # Detailed results
        render_detailed_results(response)
    
    # Footer
    st.markdown("---")
    st.markdown(
        """
        <div style="text-align: center; color: #666; font-size: 0.8rem;">
        CargoIQ - AI-Powered Cargo Intelligence System | 
        Built for customs and security applications
        </div>
        """,
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    main()