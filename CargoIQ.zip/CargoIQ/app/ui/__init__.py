"""
CargoIQ UI Package

This package contains the Streamlit dashboard interface.
"""

from app.ui.dashboard import main as run_dashboard

__all__ = ["run_dashboard"]