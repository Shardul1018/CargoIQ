"""
CargoIQ Mismatch Detection Module

This module detects misdeclarations by comparing detected objects
against declared cargo using semantic matching.
"""

from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass, field

from app.intelligence.semantic_matcher import SemanticMatcher, MatchResult, get_semantic_matcher
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class MismatchAnalysis:
    """Complete mismatch analysis result."""
    is_mismatch_detected: bool
    mismatch_score: float  # 0-1 score indicating severity
    total_detected: int
    total_matched: int
    total_unmatched: int
    matched_items: List[str]
    unmatched_items: List[str]
    match_details: List[Dict]
    undeclared_categories: List[str]
    severity: str  # "none", "low", "medium", "high", "critical"
    explanation: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_mismatch_detected": self.is_mismatch_detected,
            "mismatch_score": round(self.mismatch_score, 3),
            "total_detected": self.total_detected,
            "total_matched": self.total_matched,
            "total_unmatched": self.total_unmatched,
            "matched_items": self.matched_items,
            "unmatched_items": self.unmatched_items,
            "match_details": self.match_details,
            "undeclared_categories": self.undeclared_categories,
            "severity": self.severity,
            "explanation": self.explanation
        }


class MismatchDetector:
    """
    Mismatch Detector for Cargo Analysis
    
    This detector identifies discrepancies between declared cargo
    and detected objects in X-ray/cargo images.
    
    Key capabilities:
    - Semantic matching (laptop matches electronics)
    - Category-level matching
    - Severity scoring based on mismatch extent
    - Identification of undeclared item categories
    """
    
    def __init__(self):
        """Initialize the mismatch detector."""
        self.semantic_matcher = get_semantic_matcher()
        
        # Severity thresholds (percentage of unmatched items)
        self.severity_thresholds = {
            "none": 0.0,
            "low": 0.15,
            "medium": 0.30,
            "high": 0.50,
            "critical": 0.70
        }
        
        logger.info("Mismatch Detector initialized")
    
    def _calculate_mismatch_score(
        self,
        total_detected: int,
        unmatched_count: int,
        match_results: List[MatchResult]
    ) -> float:
        """
        Calculate a mismatch score from 0 to 1.
        
        Higher score = more severe mismatch.
        """
        if total_detected == 0:
            return 0.0
        
        # Base score from unmatched ratio
        unmatched_ratio = unmatched_count / total_detected
        
        # Weighted by match quality for matched items
        match_quality_sum = sum(
            r.similarity_score for r in match_results if r.is_match
        )
        matched_count = total_detected - unmatched_count
        avg_match_quality = (
            match_quality_sum / matched_count if matched_count > 0 else 0
        )
        
        # Lower match quality increases mismatch score
        quality_penalty = (1 - avg_match_quality) * 0.2
        
        # Final score
        mismatch_score = min(1.0, unmatched_ratio + quality_penalty)
        
        return mismatch_score
    
    def _determine_severity(self, mismatch_score: float) -> str:
        """Determine severity level based on mismatch score."""
        if mismatch_score >= self.severity_thresholds["critical"]:
            return "critical"
        elif mismatch_score >= self.severity_thresholds["high"]:
            return "high"
        elif mismatch_score >= self.severity_thresholds["medium"]:
            return "medium"
        elif mismatch_score >= self.severity_thresholds["low"]:
            return "low"
        else:
            return "none"
    
    def _identify_undeclared_categories(
        self,
        unmatched_items: List[str]
    ) -> List[str]:
        """Identify categories of unmatched items."""
        categories = set()
        
        for item in unmatched_items:
            category = self.semantic_matcher._find_category(item)
            if category:
                categories.add(category)
            else:
                categories.add(f"unknown ({item})")
        
        return list(categories)
    
    def _generate_explanation(
        self,
        analysis: 'MismatchAnalysis'
    ) -> str:
        """Generate human-readable explanation of mismatch."""
        if not analysis.is_mismatch_detected:
            return "All detected items match the declared cargo. No misdeclaration detected."
        
        explanation_parts = []
        
        # Overview
        explanation_parts.append(
            f"Mismatch detected: {analysis.total_unmatched} of "
            f"{analysis.total_detected} items do not match declared cargo."
        )
        
        # Unmatched items
        if analysis.unmatched_items:
            items_str = ", ".join(analysis.unmatched_items[:5])
            if len(analysis.unmatched_items) > 5:
                items_str += f" and {len(analysis.unmatched_items) - 5} more"
            explanation_parts.append(f"Undeclared items: {items_str}.")
        
        # Undeclared categories
        if analysis.undeclared_categories:
            cats_str = ", ".join(analysis.undeclared_categories[:3])
            explanation_parts.append(f"Undeclared categories: {cats_str}.")
        
        # Severity
        if analysis.severity in ["high", "critical"]:
            explanation_parts.append(
                f"Severity is {analysis.severity.upper()} - immediate review recommended."
            )
        
        return " ".join(explanation_parts)
    
    def detect(
        self,
        detected_objects: List[str],
        declared_cargo: List[str],
        confidence_scores: Optional[Dict[str, float]] = None
    ) -> MismatchAnalysis:
        """
        Detect mismatches between detected objects and declared cargo.
        
        Args:
            detected_objects: List of detected object labels
            declared_cargo: List of declared cargo items
            confidence_scores: Optional dict of item -> confidence
        
        Returns:
            MismatchAnalysis with detailed mismatch information
        """
        logger.info(
            f"Analyzing mismatch: {len(detected_objects)} detected, "
            f"{len(declared_cargo)} declared"
        )
        
        # Handle empty inputs
        if not detected_objects:
            return MismatchAnalysis(
                is_mismatch_detected=False,
                mismatch_score=0.0,
                total_detected=0,
                total_matched=0,
                total_unmatched=0,
                matched_items=[],
                unmatched_items=[],
                match_details=[],
                undeclared_categories=[],
                severity="none",
                explanation="No objects detected in cargo images."
            )
        
        if not declared_cargo:
            return MismatchAnalysis(
                is_mismatch_detected=True,
                mismatch_score=1.0,
                total_detected=len(detected_objects),
                total_matched=0,
                total_unmatched=len(detected_objects),
                matched_items=[],
                unmatched_items=detected_objects,
                match_details=[],
                undeclared_categories=self._identify_undeclared_categories(detected_objects),
                severity="critical",
                explanation="No cargo was declared but items were detected."
            )
        
        # Perform semantic matching
        match_results, matched_items, unmatched_items = self.semantic_matcher.match_all(
            detected_objects,
            declared_cargo
        )
        
        # Calculate mismatch score
        mismatch_score = self._calculate_mismatch_score(
            len(detected_objects),
            len(unmatched_items),
            match_results
        )
        
        # Determine severity
        severity = self._determine_severity(mismatch_score)
        
        # Identify undeclared categories
        undeclared_categories = self._identify_undeclared_categories(unmatched_items)
        
        # Create analysis object
        analysis = MismatchAnalysis(
            is_mismatch_detected=len(unmatched_items) > 0,
            mismatch_score=mismatch_score,
            total_detected=len(detected_objects),
            total_matched=len(matched_items),
            total_unmatched=len(unmatched_items),
            matched_items=matched_items,
            unmatched_items=unmatched_items,
            match_details=[r.to_dict() for r in match_results],
            undeclared_categories=undeclared_categories,
            severity=severity,
            explanation=""
        )
        
        # Generate explanation
        analysis.explanation = self._generate_explanation(analysis)
        
        logger.info(
            f"Mismatch analysis complete: "
            f"detected={analysis.is_mismatch_detected}, "
            f"severity={severity}"
        )
        
        return analysis


# Create singleton instance
_detector_instance: Optional[MismatchDetector] = None


def get_mismatch_detector() -> MismatchDetector:
    """Get or create the singleton mismatch detector instance."""
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = MismatchDetector()
    return _detector_instance