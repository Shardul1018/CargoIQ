"""
CargoIQ Anomaly Detection Module

This module detects anomalies in cargo including restricted items,
prohibited substances, and unusual patterns.
"""

from typing import Dict, List, Any, Set, Optional
from dataclasses import dataclass, field
from collections import Counter

from app.constants.rules import RESTRICTED_ITEMS, ANOMALY_RULES
from app.config import detection_config
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class AnomalyItem:
    """Represents a detected anomaly."""
    item: str
    anomaly_type: str  # "restricted", "prohibited", "suspicious", "unusual"
    confidence: float
    risk_level: str  # "low", "medium", "high", "critical"
    description: str
    action_required: str
    
    def to_dict(self) -> Dict:
        return {
            "item": self.item,
            "anomaly_type": self.anomaly_type,
            "confidence": round(self.confidence, 3),
            "risk_level": self.risk_level,
            "description": self.description,
            "action_required": self.action_required
        }


@dataclass
class AnomalyAnalysis:
    """Complete anomaly analysis result."""
    is_anomaly_detected: bool
    anomaly_score: float
    anomalies: List[AnomalyItem]
    restricted_items_found: List[str]
    prohibited_items_found: List[str]
    suspicious_items_found: List[str]
    severity: str
    requires_immediate_action: bool
    explanation: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_anomaly_detected": self.is_anomaly_detected,
            "anomaly_score": round(self.anomaly_score, 3),
            "anomalies": [a.to_dict() for a in self.anomalies],
            "restricted_items_found": self.restricted_items_found,
            "prohibited_items_found": self.prohibited_items_found,
            "suspicious_items_found": self.suspicious_items_found,
            "severity": self.severity,
            "requires_immediate_action": self.requires_immediate_action,
            "explanation": self.explanation
        }


class AnomalyDetector:
    """
    Anomaly Detector for Cargo Analysis
    
    This detector identifies:
    - Restricted items (require special permits)
    - Prohibited items (not allowed)
    - Suspicious items (unusual for cargo type)
    - Pattern anomalies (unusual combinations or quantities)
    """
    
    def __init__(self):
        """Initialize the anomaly detector."""
        # Categorize restricted items by severity
        self.prohibited_items = {
            "weapon", "gun", "firearm", "explosive", "bomb", "grenade",
            "drugs", "narcotics", "illegal_substance", "contraband"
        }
        
        self.restricted_items = {
            "knife", "ammunition", "prohibited_chemical", "radioactive",
            "unregistered_medication", "counterfeit", "ivory",
            "endangered_species"
        }
        
        self.suspicious_items = {
            "currency", "gold", "diamond", "precious_metal",
            "unidentified_object", "unusual_shape"
        }
        
        # All items requiring attention
        self.all_anomaly_items = (
            self.prohibited_items | 
            self.restricted_items | 
            self.suspicious_items
        )
        
        logger.info("Anomaly Detector initialized")
    
    def _categorize_item(self, item: str) -> Optional[str]:
        """Categorize an item as prohibited, restricted, or suspicious."""
        item_lower = item.lower()
        
        if item_lower in self.prohibited_items:
            return "prohibited"
        elif item_lower in self.restricted_items:
            return "restricted"
        elif item_lower in self.suspicious_items:
            return "suspicious"
        else:
            # Check partial matches
            for prohibited in self.prohibited_items:
                if prohibited in item_lower or item_lower in prohibited:
                    return "prohibited"
            for restricted in self.restricted_items:
                if restricted in item_lower or item_lower in restricted:
                    return "restricted"
            for suspicious in self.suspicious_items:
                if suspicious in item_lower or item_lower in suspicious:
                    return "suspicious"
        
        return None
    
    def _get_risk_level(self, category: str, confidence: float) -> str:
        """Determine risk level based on category and confidence."""
        if category == "prohibited":
            return "critical" if confidence > 0.7 else "high"
        elif category == "restricted":
            return "high" if confidence > 0.8 else "medium"
        elif category == "suspicious":
            return "medium" if confidence > 0.7 else "low"
        else:
            return "low"
    
    def _get_action_required(self, category: str) -> str:
        """Get required action for anomaly category."""
        actions = {
            "prohibited": "IMMEDIATE ALERT: Contact security. Do not release cargo.",
            "restricted": "HOLD: Verify permits and documentation before release.",
            "suspicious": "REVIEW: Manual inspection recommended.",
        }
        return actions.get(category, "Review and document.")
    
    def _get_description(self, item: str, category: str) -> str:
        """Get description for anomaly."""
        descriptions = {
            "prohibited": f"Prohibited item detected: {item}. This item is not allowed in cargo.",
            "restricted": f"Restricted item detected: {item}. Special permits may be required.",
            "suspicious": f"Suspicious item detected: {item}. Requires additional scrutiny.",
        }
        return descriptions.get(category, f"Anomaly detected: {item}")
    
    def _check_quantity_anomalies(
        self,
        frequency: Dict[str, int],
        declared_quantities: Optional[Dict[str, int]] = None
    ) -> List[AnomalyItem]:
        """Check for quantity-based anomalies."""
        anomalies = []
        
        # Flag items with unusually high quantities
        for item, count in frequency.items():
            if count > 10:  # Threshold for suspicious quantity
                anomalies.append(AnomalyItem(
                    item=item,
                    anomaly_type="quantity",
                    confidence=min(0.9, 0.5 + count * 0.02),
                    risk_level="medium",
                    description=f"Unusually high quantity of {item}: {count} items",
                    action_required="Verify quantity against manifest."
                ))
        
        return anomalies
    
    def _calculate_anomaly_score(
        self,
        anomalies: List[AnomalyItem]
    ) -> float:
        """Calculate overall anomaly score."""
        if not anomalies:
            return 0.0
        
        # Weight by risk level
        risk_weights = {
            "critical": 1.0,
            "high": 0.7,
            "medium": 0.4,
            "low": 0.2
        }
        
        total_score = 0.0
        for anomaly in anomalies:
            weight = risk_weights.get(anomaly.risk_level, 0.1)
            total_score += anomaly.confidence * weight
        
        # Normalize
        return min(1.0, total_score / 2)  # Divide by 2 to normalize typical cases
    
    def _determine_severity(
        self,
        anomalies: List[AnomalyItem]
    ) -> str:
        """Determine overall severity."""
        if not anomalies:
            return "none"
        
        risk_levels = [a.risk_level for a in anomalies]
        
        if "critical" in risk_levels:
            return "critical"
        elif "high" in risk_levels:
            return "high"
        elif "medium" in risk_levels:
            return "medium"
        else:
            return "low"
    
    def _generate_explanation(
        self,
        analysis: 'AnomalyAnalysis'
    ) -> str:
        """Generate human-readable explanation."""
        if not analysis.is_anomaly_detected:
            return "No anomalies detected. All items appear compliant."
        
        parts = []
        
        if analysis.prohibited_items_found:
            parts.append(
                f"ALERT: Prohibited items detected: "
                f"{', '.join(analysis.prohibited_items_found)}."
            )
        
        if analysis.restricted_items_found:
            parts.append(
                f"Restricted items requiring permits: "
                f"{', '.join(analysis.restricted_items_found)}."
            )
        
        if analysis.suspicious_items_found:
            parts.append(
                f"Suspicious items for review: "
                f"{', '.join(analysis.suspicious_items_found)}."
            )
        
        if analysis.requires_immediate_action:
            parts.append("IMMEDIATE ACTION REQUIRED.")
        
        return " ".join(parts)
    
    def detect(
        self,
        detected_items: List[str],
        frequency: Optional[Dict[str, int]] = None,
        confidence_scores: Optional[Dict[str, float]] = None,
        declared_items: Optional[List[str]] = None
    ) -> AnomalyAnalysis:
        """
        Detect anomalies in detected items.
        
        Args:
            detected_items: List of detected object labels
            frequency: Optional frequency dict
            confidence_scores: Optional confidence scores
            declared_items: Optional declared cargo for comparison
        
        Returns:
            AnomalyAnalysis with detailed anomaly information
        """
        logger.info(f"Analyzing anomalies for {len(detected_items)} items")
        
        if not detected_items:
            return AnomalyAnalysis(
                is_anomaly_detected=False,
                anomaly_score=0.0,
                anomalies=[],
                restricted_items_found=[],
                prohibited_items_found=[],
                suspicious_items_found=[],
                severity="none",
                requires_immediate_action=False,
                explanation="No objects to analyze for anomalies."
            )
        
        # Initialize frequency if not provided
        if frequency is None:
            frequency = Counter(detected_items)
        
        # Detect item-based anomalies
        anomalies = []
        prohibited_found = []
        restricted_found = []
        suspicious_found = []
        
        unique_items = set(detected_items)
        
        for item in unique_items:
            category = self._categorize_item(item)
            
            if category:
                confidence = (
                    confidence_scores.get(item, 0.8) 
                    if confidence_scores else 0.8
                )
                
                anomaly = AnomalyItem(
                    item=item,
                    anomaly_type=category,
                    confidence=confidence,
                    risk_level=self._get_risk_level(category, confidence),
                    description=self._get_description(item, category),
                    action_required=self._get_action_required(category)
                )
                anomalies.append(anomaly)
                
                if category == "prohibited":
                    prohibited_found.append(item)
                elif category == "restricted":
                    restricted_found.append(item)
                elif category == "suspicious":
                    suspicious_found.append(item)
        
        # Check quantity anomalies
        quantity_anomalies = self._check_quantity_anomalies(frequency)
        anomalies.extend(quantity_anomalies)
        
        # Calculate score and severity
        anomaly_score = self._calculate_anomaly_score(anomalies)
        severity = self._determine_severity(anomalies)
        
        # Check if immediate action required
        requires_immediate = len(prohibited_found) > 0
        
        # Create analysis
        analysis = AnomalyAnalysis(
            is_anomaly_detected=len(anomalies) > 0,
            anomaly_score=anomaly_score,
            anomalies=anomalies,
            restricted_items_found=restricted_found,
            prohibited_items_found=prohibited_found,
            suspicious_items_found=suspicious_found,
            severity=severity,
            requires_immediate_action=requires_immediate,
            explanation=""
        )
        
        analysis.explanation = self._generate_explanation(analysis)
        
        logger.info(
            f"Anomaly analysis complete: "
            f"detected={analysis.is_anomaly_detected}, "
            f"severity={severity}"
        )
        
        return analysis


# Create singleton instance
_detector_instance: Optional[AnomalyDetector] = None


def get_anomaly_detector() -> AnomalyDetector:
    """Get or create the singleton anomaly detector instance."""
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = AnomalyDetector()
    return _detector_instance