"""
CargoIQ Semantic Matcher

This module provides semantic matching capabilities for cargo classification.
It maps detected objects to declared cargo categories using LLM-style simulation.
"""

from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass, field

from app.constants.mappings import SEMANTIC_MAPPINGS, CATEGORY_HIERARCHY
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class MatchResult:
    """Result of semantic matching."""
    detected_item: str
    declared_category: Optional[str]
    is_match: bool
    similarity_score: float
    matched_via: str  # "exact", "category", "semantic", "none"
    
    def to_dict(self) -> Dict:
        return {
            "detected_item": self.detected_item,
            "declared_category": self.declared_category,
            "is_match": self.is_match,
            "similarity_score": round(self.similarity_score, 3),
            "matched_via": self.matched_via
        }


class SemanticMatcher:
    """
    Semantic Matcher for Cargo Classification
    
    This class provides intelligent matching between detected objects
    and declared cargo items using:
    - Exact string matching
    - Category-based matching (e.g., "laptop" matches "electronics")
    - Semantic similarity (using predefined mappings)
    - Hierarchical category matching
    """
    
    def __init__(self):
        """Initialize the semantic matcher."""
        # Build reverse mappings for fast lookup
        self.item_to_category = self._build_reverse_mapping()
        self.synonyms = self._build_synonym_mapping()
        
        logger.info("Semantic Matcher initialized")
    
    def _build_reverse_mapping(self) -> Dict[str, str]:
        """Build reverse mapping from items to categories."""
        reverse_map = {}
        
        for category, items in SEMANTIC_MAPPINGS.items():
            for item in items:
                reverse_map[item.lower()] = category.lower()
        
        return reverse_map
    
    def _build_synonym_mapping(self) -> Dict[str, Set[str]]:
        """Build synonym mappings for common items."""
        synonyms = {
            # Electronics
            "laptop": {"notebook", "computer", "pc", "macbook"},
            "phone": {"mobile", "cellphone", "smartphone", "iphone", "android"},
            "tablet": {"ipad", "pad", "e-reader"},
            "camera": {"dslr", "camcorder", "gopro"},
            
            # Clothing
            "clothing": {"clothes", "apparel", "garments", "wear"},
            "shirt": {"t-shirt", "tshirt", "blouse", "top"},
            "pants": {"trousers", "jeans", "slacks"},
            "shoes": {"footwear", "sneakers", "boots", "sandals"},
            
            # Documents
            "documents": {"papers", "files", "paperwork"},
            "books": {"textbooks", "novels", "magazines", "publications"},
            
            # Food
            "food": {"food_items", "groceries", "edibles", "provisions"},
            
            # Valuables
            "jewelry": {"jewellery", "ornaments", "accessories"},
            "watch": {"watches", "timepiece", "wristwatch"},
            "currency": {"cash", "money", "banknotes"},
            
            # General
            "battery": {"batteries", "power_cell", "power_bank"},
            "charger": {"adapter", "power_adapter", "charging_cable"},
        }
        
        return synonyms
    
    def _normalize(self, text: str) -> str:
        """Normalize text for matching."""
        return text.lower().strip().replace("-", "_").replace(" ", "_")
    
    def _get_synonyms(self, item: str) -> Set[str]:
        """Get all synonyms for an item."""
        normalized = self._normalize(item)
        
        # Check if item is a synonym
        for base, syns in self.synonyms.items():
            if normalized == base or normalized in syns:
                return syns | {base}
        
        return {normalized}
    
    def _find_category(self, item: str) -> Optional[str]:
        """Find the category for an item."""
        normalized = self._normalize(item)
        
        # Check direct mapping
        if normalized in self.item_to_category:
            return self.item_to_category[normalized]
        
        # Check synonyms
        for synonym in self._get_synonyms(item):
            if synonym in self.item_to_category:
                return self.item_to_category[synonym]
        
        # Check if item is itself a category
        if normalized in SEMANTIC_MAPPINGS:
            return normalized
        
        return None
    
    def match_item(
        self,
        detected_item: str,
        declared_items: List[str]
    ) -> MatchResult:
        """
        Match a detected item against declared items.
        
        Args:
            detected_item: The detected object label
            declared_items: List of declared cargo items
        
        Returns:
            MatchResult indicating if and how the item matched
        """
        normalized_detected = self._normalize(detected_item)
        normalized_declared = [self._normalize(d) for d in declared_items]
        
        # 1. Check exact match
        if normalized_detected in normalized_declared:
            return MatchResult(
                detected_item=detected_item,
                declared_category=detected_item,
                is_match=True,
                similarity_score=1.0,
                matched_via="exact"
            )
        
        # 2. Check synonym match
        detected_synonyms = self._get_synonyms(detected_item)
        for declared in declared_items:
            declared_synonyms = self._get_synonyms(declared)
            if detected_synonyms & declared_synonyms:
                return MatchResult(
                    detected_item=detected_item,
                    declared_category=declared,
                    is_match=True,
                    similarity_score=0.9,
                    matched_via="synonym"
                )
        
        # 3. Check category match
        detected_category = self._find_category(detected_item)
        
        if detected_category:
            for declared in declared_items:
                declared_category = self._find_category(declared)
                
                # Check if categories match
                if detected_category == declared_category:
                    return MatchResult(
                        detected_item=detected_item,
                        declared_category=declared,
                        is_match=True,
                        similarity_score=0.8,
                        matched_via="category"
                    )
                
                # Check if detected category is in declared items
                if self._normalize(declared) == detected_category:
                    return MatchResult(
                        detected_item=detected_item,
                        declared_category=declared,
                        is_match=True,
                        similarity_score=0.85,
                        matched_via="category"
                    )
        
        # 4. Check semantic mapping
        for category, items in SEMANTIC_MAPPINGS.items():
            normalized_items = [self._normalize(i) for i in items]
            
            if normalized_detected in normalized_items:
                # Check if category is declared
                if self._normalize(category) in normalized_declared:
                    return MatchResult(
                        detected_item=detected_item,
                        declared_category=category,
                        is_match=True,
                        similarity_score=0.75,
                        matched_via="semantic"
                    )
        
        # 5. No match found
        return MatchResult(
            detected_item=detected_item,
            declared_category=None,
            is_match=False,
            similarity_score=0.0,
            matched_via="none"
        )
    
    def match_all(
        self,
        detected_items: List[str],
        declared_items: List[str]
    ) -> Tuple[List[MatchResult], List[str], List[str]]:
        """
        Match all detected items against declared items.
        
        Args:
            detected_items: List of detected object labels
            declared_items: List of declared cargo items
        
        Returns:
            Tuple of (all match results, matched items, unmatched items)
        """
        results = []
        matched = []
        unmatched = []
        
        for item in detected_items:
            result = self.match_item(item, declared_items)
            results.append(result)
            
            if result.is_match:
                matched.append(item)
            else:
                unmatched.append(item)
        
        return results, matched, unmatched
    
    def get_category_items(self, category: str) -> List[str]:
        """Get all items belonging to a category."""
        normalized = self._normalize(category)
        
        if normalized in SEMANTIC_MAPPINGS:
            return SEMANTIC_MAPPINGS[normalized]
        
        return []
    
    def is_item_in_category(self, item: str, category: str) -> bool:
        """Check if an item belongs to a category."""
        item_category = self._find_category(item)
        return item_category == self._normalize(category)


# Create singleton instance
_matcher_instance: Optional[SemanticMatcher] = None


def get_semantic_matcher() -> SemanticMatcher:
    """Get or create the singleton semantic matcher instance."""
    global _matcher_instance
    if _matcher_instance is None:
        _matcher_instance = SemanticMatcher()
    return _matcher_instance