"""
CargoIQ Concealment Detection Module

This module detects potential concealment patterns in cargo,
identifying suspicious groupings and hidden item indicators.
"""

from typing import Dict, List, Any, Set, Tuple, Optional
from dataclasses import dataclass, field
from collections import Counter

from app.constants.rules import CONCEALMENT_RULES, CONCEALMENT_PATTERNS
from app.config import detection_config
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class ConcealmentIndicator:
    """Represents a single concealment indicator."""
    indicator_type: str
    items_involved: List[str]
    confidence: float
    description: str
    
    def to_dict(self) -> Dict:
        return {
            "indicator_type": self.indicator_type,
            "items_involved": self.items_involved,
            "confidence": round(self.confidence, 3),
            "description": self.description
        }


@dataclass
class ConcealmentAnalysis:
    """Complete concealment analysis result."""
    is_concealment_detected: bool
    concealment_score: float  # 0-1 score
    indicators: List[ConcealmentIndicator]
    suspicious_patterns: List[str]
    risk_items: List[str]
    severity: str
    explanation: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_concealment_detected": self.is_concealment_detected,
            "concealment_score": round(self.concealment_score, 3),
            "indicators": [i.to_dict() for i in self.indicators],
            "suspicious_patterns": self.suspicious_patterns,
            "risk_items": self.risk_items,
            "severity": self.severity,
            "explanation": self.explanation
        }


class ConcealmentDetector:
    """
    Concealment Detector for Cargo Analysis
    
    This detector identifies potential concealment patterns:
    - Dense materials that could shield other items
    - Unusual groupings of items
    - Hidden compartment indicators
    - Layered packaging patterns
    - Anomalous object arrangements
    """
    
    def __init__(self):
        """Initialize the concealment detector."""
        self.concealment_indicators = set(detection_config.concealment_indicators)
        
        # Suspicious item combinations
        self.suspicious_combinations = [
            {"dense_material", "electronics"},
            {"lead", "small_package"},
            {"metal_sheet", "wrapped_bundle"},
            {"false_bottom", "any"},
            {"hidden_compartment", "any"},
            {"shielded_container", "any"},
        ]
        
        # Items that often indicate concealment
        self.high_risk_indicators = {
            "false_bottom", "hidden_compartment", "shielded_container",
            "lead", "unusual_cavity"
        }
        
        logger.info("Concealment Detector initialized")
    
    def _check_concealment_indicators(
        self,
        detected_items: List[str],
        confidence_scores: Optional[Dict[str, float]] = None
    ) -> List[ConcealmentIndicator]:
        """Check for direct concealment indicators."""
        indicators = []
        
        for item in detected_items:
            item_lower = item.lower()
            
            if item_lower in self.concealment_indicators:
                conf = confidence_scores.get(item, 0.8) if confidence_scores else 0.8
                
                indicators.append(ConcealmentIndicator(
                    indicator_type="direct_indicator",
                    items_involved=[item],
                    confidence=conf,
                    description=f"Detected concealment indicator: {item}"
                ))
        
        return indicators
    
    def _check_suspicious_combinations(
        self,
        detected_items: List[str],
        confidence_scores: Optional[Dict[str, float]] = None
    ) -> List[ConcealmentIndicator]:
        """Check for suspicious item combinations."""
        indicators = []
        item_set = set(item.lower() for item in detected_items)
        
        for combo in self.suspicious_combinations:
            matched_items = []
            
            for combo_item in combo:
                if combo_item == "any":
                    continue
                if combo_item in item_set:
                    matched_items.append(combo_item)
            
            if len(matched_items) >= 2 or (
                len(matched_items) >= 1 and "any" in combo
            ):
                avg_conf = 0.75
                if confidence_scores:
                    confs = [confidence_scores.get(i, 0.75) for i in matched_items]
                    avg_conf = sum(confs) / len(confs) if confs else 0.75
                
                indicators.append(ConcealmentIndicator(
                    indicator_type="suspicious_combination",
                    items_involved=matched_items,
                    confidence=avg_conf,
                    description=f"Suspicious item combination detected: {', '.join(matched_items)}"
                ))
        
        return indicators
    
    def _check_frequency_anomalies(
        self,
        detected_items: List[str],
        frequency: Dict[str, int]
    ) -> List[ConcealmentIndicator]:
        """Check for frequency-based anomalies."""
        indicators = []
        
        # High frequency of concealment-related items
        for item, count in frequency.items():
            item_lower = item.lower()
            
            if item_lower in self.concealment_indicators and count > 2:
                indicators.append(ConcealmentIndicator(
                    indicator_type="frequency_anomaly",
                    items_involved=[item],
                    confidence=min(0.9, 0.5 + count * 0.1),
                    description=f"High frequency of concealment indicator: {item} ({count} times)"
                ))
        
        return indicators
    
    def _check_layering_patterns(
        self,
        detected_items: List[str],
        object_positions: Optional[List[Tuple[str, Tuple]]] = None
    ) -> List[ConcealmentIndicator]:
        """Check for layering patterns that might indicate concealment."""
        indicators = []
        
        # Check for wrapped/layered items
        layered_indicators = ["wrapped_bundle", "layered_packaging", "dense_material"]
        detected_lower = [d.lower() for d in detected_items]
        
        layered_found = [i for i in layered_indicators if i in detected_lower]
        
        if len(layered_found) >= 2:
            indicators.append(ConcealmentIndicator(
                indicator_type="layering_pattern",
                items_involved=layered_found,
                confidence=0.7,
                description=f"Multiple layering indicators detected: {', '.join(layered_found)}"
            ))
        
        return indicators
    
    def _calculate_concealment_score(
        self,
        indicators: List[ConcealmentIndicator]
    ) -> float:
        """Calculate overall concealment score."""
        if not indicators:
            return 0.0
        
        # Weight different indicator types
        weights = {
            "direct_indicator": 0.4,
            "suspicious_combination": 0.35,
            "frequency_anomaly": 0.15,
            "layering_pattern": 0.2
        }
        
        total_score = 0.0
        
        for indicator in indicators:
            weight = weights.get(indicator.indicator_type, 0.1)
            total_score += indicator.confidence * weight
        
        # Normalize to 0-1
        return min(1.0, total_score)
    
    def _determine_severity(self, concealment_score: float) -> str:
        """Determine severity level."""
        if concealment_score >= 0.7:
            return "critical"
        elif concealment_score >= 0.5:
            return "high"
        elif concealment_score >= 0.3:
            return "medium"
        elif concealment_score >= 0.1:
            return "low"
        else:
            return "none"
    
    def _identify_risk_items(
        self,
        detected_items: List[str]
    ) -> List[str]:
        """Identify high-risk items related to concealment."""
        risk_items = []
        
        for item in detected_items:
            if item.lower() in self.high_risk_indicators:
                risk_items.append(item)
        
        return risk_items
    
    def _generate_explanation(
        self,
        analysis: 'ConcealmentAnalysis'
    ) -> str:
        """Generate human-readable explanation."""
        if not analysis.is_concealment_detected:
            return "No concealment patterns detected in the cargo images."
        
        parts = []
        
        parts.append(
            f"Potential concealment detected with {len(analysis.indicators)} indicators."
        )
        
        if analysis.risk_items:
            parts.append(f"High-risk items: {', '.join(analysis.risk_items)}.")
        
        if analysis.suspicious_patterns:
            parts.append(f"Suspicious patterns: {', '.join(analysis.suspicious_patterns)}.")
        
        if analysis.severity in ["high", "critical"]:
            parts.append("Physical inspection strongly recommended.")
        
        return " ".join(parts)
    
    def detect(
        self,
        detected_items: List[str],
        frequency: Optional[Dict[str, int]] = None,
        confidence_scores: Optional[Dict[str, float]] = None,
        object_positions: Optional[List[Tuple[str, Tuple]]] = None
    ) -> ConcealmentAnalysis:
        """
        Detect concealment patterns in detected items.
        
        Args:
            detected_items: List of detected object labels
            frequency: Optional frequency dict of items
            confidence_scores: Optional confidence scores
            object_positions: Optional positions for spatial analysis
        
        Returns:
            ConcealmentAnalysis with detailed concealment information
        """
        logger.info(f"Analyzing concealment for {len(detected_items)} items")
        
        if not detected_items:
            return ConcealmentAnalysis(
                is_concealment_detected=False,
                concealment_score=0.0,
                indicators=[],
                suspicious_patterns=[],
                risk_items=[],
                severity="none",
                explanation="No objects to analyze for concealment."
            )
        
        # Initialize frequency if not provided
        if frequency is None:
            frequency = Counter(detected_items)
        
        # Collect all indicators
        all_indicators = []
        
        # Check different concealment patterns
        all_indicators.extend(
            self._check_concealment_indicators(detected_items, confidence_scores)
        )
        all_indicators.extend(
            self._check_suspicious_combinations(detected_items, confidence_scores)
        )
        all_indicators.extend(
            self._check_frequency_anomalies(detected_items, frequency)
        )
        all_indicators.extend(
            self._check_layering_patterns(detected_items, object_positions)
        )
        
        # Calculate score
        concealment_score = self._calculate_concealment_score(all_indicators)
        
        # Determine severity
        severity = self._determine_severity(concealment_score)
        
        # Get suspicious patterns
        suspicious_patterns = list(set(
            i.indicator_type for i in all_indicators
        ))
        
        # Identify risk items
        risk_items = self._identify_risk_items(detected_items)
        
        # Create analysis
        analysis = ConcealmentAnalysis(
            is_concealment_detected=len(all_indicators) > 0,
            concealment_score=concealment_score,
            indicators=all_indicators,
            suspicious_patterns=suspicious_patterns,
            risk_items=risk_items,
            severity=severity,
            explanation=""
        )
        
        analysis.explanation = self._generate_explanation(analysis)
        
        logger.info(
            f"Concealment analysis complete: "
            f"detected={analysis.is_concealment_detected}, "
            f"score={concealment_score:.2f}"
        )
        
        return analysis


# Create singleton instance
_detector_instance: Optional[ConcealmentDetector] = None


def get_concealment_detector() -> ConcealmentDetector:
    """Get or create the singleton concealment detector instance."""
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = ConcealmentDetector()
    return _detector_instance