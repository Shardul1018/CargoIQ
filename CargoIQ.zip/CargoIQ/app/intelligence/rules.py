"""
CargoIQ Rules Engine

This module contains the business rules engine for cargo analysis,
defining thresholds, policies, and decision logic.
"""

from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum

from app.constants.rules import (
    RISK_THRESHOLDS, BASE_RISK_SCORES, 
    CONTEXT_MULTIPLIERS, DECISION_RULES
)
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


class RiskCategory(Enum):
    """Risk category enumeration."""
    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ActionType(Enum):
    """Action type enumeration."""
    RELEASE = "release"
    REVIEW = "review"
    INSPECT = "inspect"
    HOLD = "hold"
    ALERT = "alert"


@dataclass
class RuleResult:
    """Result of rule evaluation."""
    rule_name: str
    triggered: bool
    risk_contribution: float
    details: str
    action_suggested: ActionType


@dataclass
class RuleEvaluation:
    """Complete rule evaluation result."""
    total_rules_checked: int
    rules_triggered: int
    results: List[RuleResult]
    total_risk_contribution: float
    highest_action: ActionType
    summary: str


class RulesEngine:
    """
    Business Rules Engine for Cargo Analysis
    
    This engine evaluates cargo analysis results against
    predefined business rules to determine risk and actions.
    """
    
    def __init__(self):
        """Initialize the rules engine."""
        self.rules: List[Dict[str, Any]] = []
        self._register_default_rules()
        
        logger.info("Rules Engine initialized")
    
    def _register_default_rules(self):
        """Register default business rules."""
        
        # Rule: Mismatch Detection
        self.register_rule(
            name="mismatch_rule",
            condition=lambda ctx: ctx.get("mismatch_detected", False),
            risk_contribution=BASE_RISK_SCORES["mismatch"],
            action=ActionType.REVIEW,
            description="Cargo declaration mismatch detected"
        )
        
        # Rule: Concealment Detection
        self.register_rule(
            name="concealment_rule",
            condition=lambda ctx: ctx.get("concealment_detected", False),
            risk_contribution=BASE_RISK_SCORES["concealment"],
            action=ActionType.INSPECT,
            description="Potential concealment patterns detected"
        )
        
        # Rule: Anomaly Detection
        self.register_rule(
            name="anomaly_rule",
            condition=lambda ctx: ctx.get("anomaly_detected", False),
            risk_contribution=BASE_RISK_SCORES["anomaly"],
            action=ActionType.INSPECT,
            description="Anomalous items detected"
        )
        
        # Rule: Prohibited Items
        self.register_rule(
            name="prohibited_items_rule",
            condition=lambda ctx: len(ctx.get("prohibited_items", [])) > 0,
            risk_contribution=50,
            action=ActionType.ALERT,
            description="Prohibited items detected"
        )
        
        # Rule: High Frequency Anomaly
        self.register_rule(
            name="high_frequency_rule",
            condition=lambda ctx: ctx.get("max_frequency", 0) > 5,
            risk_contribution=10,
            action=ActionType.REVIEW,
            description="High frequency of single item type"
        )
        
        # Rule: Low Confidence Detections
        self.register_rule(
            name="low_confidence_rule",
            condition=lambda ctx: ctx.get("avg_confidence", 1.0) < 0.6,
            risk_contribution=5,
            action=ActionType.REVIEW,
            description="Low confidence in detections"
        )
        
        # Rule: Multiple Issues
        self.register_rule(
            name="multiple_issues_rule",
            condition=lambda ctx: sum([
                ctx.get("mismatch_detected", False),
                ctx.get("concealment_detected", False),
                ctx.get("anomaly_detected", False)
            ]) >= 2,
            risk_contribution=15,
            action=ActionType.HOLD,
            description="Multiple issues detected simultaneously"
        )
        
        # Rule: Critical Severity
        self.register_rule(
            name="critical_severity_rule",
            condition=lambda ctx: ctx.get("severity", "none") == "critical",
            risk_contribution=25,
            action=ActionType.ALERT,
            description="Critical severity level reached"
        )
    
    def register_rule(
        self,
        name: str,
        condition: Callable[[Dict], bool],
        risk_contribution: float,
        action: ActionType,
        description: str
    ):
        """
        Register a new business rule.
        
        Args:
            name: Unique rule name
            condition: Function that takes context and returns bool
            risk_contribution: Risk points added when rule triggers
            action: Suggested action when rule triggers
            description: Human-readable description
        """
        self.rules.append({
            "name": name,
            "condition": condition,
            "risk_contribution": risk_contribution,
            "action": action,
            "description": description
        })
    
    def evaluate(self, context: Dict[str, Any]) -> RuleEvaluation:
        """
        Evaluate all rules against the given context.
        
        Args:
            context: Dictionary containing analysis results
        
        Returns:
            RuleEvaluation with all results
        """
        logger.info(f"Evaluating {len(self.rules)} rules")
        
        results = []
        total_risk = 0.0
        highest_action = ActionType.RELEASE
        triggered_count = 0
        
        action_priority = {
            ActionType.RELEASE: 0,
            ActionType.REVIEW: 1,
            ActionType.INSPECT: 2,
            ActionType.HOLD: 3,
            ActionType.ALERT: 4
        }
        
        for rule in self.rules:
            try:
                triggered = rule["condition"](context)
                
                if triggered:
                    triggered_count += 1
                    total_risk += rule["risk_contribution"]
                    
                    if action_priority[rule["action"]] > action_priority[highest_action]:
                        highest_action = rule["action"]
                
                results.append(RuleResult(
                    rule_name=rule["name"],
                    triggered=triggered,
                    risk_contribution=rule["risk_contribution"] if triggered else 0,
                    details=rule["description"],
                    action_suggested=rule["action"]
                ))
                
            except Exception as e:
                logger.error(f"Error evaluating rule {rule['name']}: {e}")
                results.append(RuleResult(
                    rule_name=rule["name"],
                    triggered=False,
                    risk_contribution=0,
                    details=f"Error: {str(e)}",
                    action_suggested=ActionType.REVIEW
                ))
        
        # Generate summary
        triggered_rules = [r.rule_name for r in results if r.triggered]
        summary = (
            f"Evaluated {len(self.rules)} rules. "
            f"{triggered_count} triggered. "
            f"Triggered rules: {', '.join(triggered_rules) if triggered_rules else 'None'}."
        )
        
        evaluation = RuleEvaluation(
            total_rules_checked=len(self.rules),
            rules_triggered=triggered_count,
            results=results,
            total_risk_contribution=total_risk,
            highest_action=highest_action,
            summary=summary
        )
        
        logger.info(f"Rule evaluation complete: {triggered_count} rules triggered")
        
        return evaluation
    
    def get_risk_category(self, risk_score: float) -> RiskCategory:
        """Get risk category based on score."""
        if risk_score >= RISK_THRESHOLDS["critical"]:
            return RiskCategory.CRITICAL
        elif risk_score >= RISK_THRESHOLDS["high"]:
            return RiskCategory.HIGH
        elif risk_score >= RISK_THRESHOLDS["medium"]:
            return RiskCategory.MEDIUM
        elif risk_score >= RISK_THRESHOLDS["low"]:
            return RiskCategory.LOW
        else:
            return RiskCategory.MINIMAL


# Create singleton instance
_engine_instance: Optional[RulesEngine] = None


def get_rules_engine() -> RulesEngine:
    """Get or create the singleton rules engine instance."""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = RulesEngine()
    return _engine_instance