"""
CargoIQ Main Application Entry Point

This module serves as the main entry point for the CargoIQ system.
It initializes all components and provides the core functionality.
"""

import sys
from pathlib import Path

# Add project root to path for imports
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from typing import List, Dict, Any, Optional
from app.config import (
    model_config, risk_config, detection_config,
    cache_config, log_config, PATHS
)
from app.utils.logger import get_logger
from app.services.pipeline import CargoPipeline
from app.schemas.request_schema import CargoAnalysisRequest, CargoAnalysisResponse


# Initialize logger
logger = get_logger(__name__)


class CargoIQ:
    """
    Main CargoIQ Application Class
    
    This class provides the high-level interface for cargo analysis.
    It orchestrates all components of the system.
    """
    
    def __init__(self):
        """Initialize the CargoIQ system."""
        logger.info("Initializing CargoIQ System...")
        
        # Initialize the main processing pipeline
        self.pipeline = CargoPipeline()
        
        # System status
        self.is_initialized = True
        
        logger.info("CargoIQ System initialized successfully!")
    
    def analyze(
        self,
        image_paths: List[str],
        declared_cargo: List[str],
        shipment_id: Optional[str] = None,
        origin_country: Optional[str] = None,
        destination_country: Optional[str] = None
    ) -> CargoAnalysisResponse:
        """
        Analyze cargo images and provide intelligence report.
        
        Args:
            image_paths: List of paths to cargo/X-ray images
            declared_cargo: List of declared cargo items
            shipment_id: Optional shipment identifier
            origin_country: Optional origin country
            destination_country: Optional destination country
        
        Returns:
            CargoAnalysisResponse containing complete analysis results
        """
        logger.info(f"Starting cargo analysis for {len(image_paths)} images")
        logger.info(f"Declared cargo: {declared_cargo}")
        
        # Create analysis request
        request = CargoAnalysisRequest(
            image_paths=image_paths,
            declared_cargo=declared_cargo,
            shipment_id=shipment_id or "UNKNOWN",
            origin_country=origin_country,
            destination_country=destination_country
        )
        
        # Process through pipeline
        response = self.pipeline.process(request)
        
        logger.info(f"Analysis complete. Risk Score: {response.risk_score}")
        
        return response
    
    def analyze_from_bytes(
        self,
        image_data: List[bytes],
        declared_cargo: List[str],
        shipment_id: Optional[str] = None
    ) -> CargoAnalysisResponse:
        """
        Analyze cargo from image bytes (for Streamlit uploads).
        
        Args:
            image_data: List of image data as bytes
            declared_cargo: List of declared cargo items
            shipment_id: Optional shipment identifier
        
        Returns:
            CargoAnalysisResponse containing complete analysis results
        """
        logger.info(f"Analyzing {len(image_data)} images from bytes")
        
        # Create request with bytes data
        request = CargoAnalysisRequest(
            image_paths=[],
            image_bytes=image_data,
            declared_cargo=declared_cargo,
            shipment_id=shipment_id or "UPLOAD"
        )
        
        # Process through pipeline
        response = self.pipeline.process(request)
        
        return response
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Get current system status and configuration.
        
        Returns:
            Dictionary containing system status information
        """
        return {
            "is_initialized": self.is_initialized,
            "model_config": {
                "weights_dir": str(model_config.weights_dir),
                "confidence_threshold": model_config.confidence_threshold,
                "simulation_mode": model_config.simulation_mode
            },
            "cache_enabled": cache_config.enabled,
            "paths": {k: str(v) for k, v in PATHS.items()}
        }


def main():
    """Main function for testing the CargoIQ system."""
    
    print("=" * 60)
    print("CargoIQ - AI-Powered Cargo Intelligence System")
    print("=" * 60)
    
    # Initialize system
    cargo_iq = CargoIQ()
    
    # Print system status
    status = cargo_iq.get_system_status()
    print("\nSystem Status:")
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    # Example analysis (simulation mode)
    print("\n" + "=" * 60)
    print("Running Example Analysis (Simulation Mode)")
    print("=" * 60)
    
    # Simulated image paths
    test_images = [f"test_image_{i}.jpg" for i in range(5)]
    declared = ["clothing", "electronics", "books"]
    
    # Run analysis
    result = cargo_iq.analyze(
        image_paths=test_images,
        declared_cargo=declared,
        shipment_id="TEST-001"
    )
    
    # Print results
    print("\n📊 Analysis Results:")
    print(f"  Shipment ID: {result.shipment_id}")
    print(f"  Images Processed: {result.images_processed}")
    print(f"  Total Detections: {result.total_detections}")
    print(f"\n🔍 Detected Objects: {result.detected_objects}")
    print(f"\n📈 Object Frequency: {result.object_frequency}")
    print(f"\n⚠️ Mismatch Detected: {result.mismatch_detected}")
    print(f"  Mismatch Details: {result.mismatch_details}")
    print(f"\n🔒 Concealment Detected: {result.concealment_detected}")
    print(f"  Concealment Details: {result.concealment_details}")
    print(f"\n🚨 Anomaly Detected: {result.anomaly_detected}")
    print(f"  Anomaly Details: {result.anomaly_details}")
    print(f"\n📊 Risk Score: {result.risk_score}/100")
    print(f"  Risk Level: {result.risk_level}")
    print(f"\n💡 Explanation: {result.explanation}")
    print(f"\n✅ Recommendation: {result.recommendation}")
    
    print("\n" + "=" * 60)
    print("Analysis Complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()