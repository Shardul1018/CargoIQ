"""
CargoIQ Configuration Module

This module contains all configuration settings for the CargoIQ system.
It centralizes paths, thresholds, and system parameters for easy management.
"""

import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# =============================================================================
# PATH CONFIGURATIONS
# =============================================================================

# Get the project root directory (parent of 'app' folder)
PROJECT_ROOT = Path(__file__).parent.parent.absolute()

# Define all important paths
PATHS = {
    "project_root": PROJECT_ROOT,
    "app": PROJECT_ROOT / "app",
    "data": PROJECT_ROOT / "data",
    "input_images": PROJECT_ROOT / "data" / "input_images",
    "outputs": PROJECT_ROOT / "data" / "outputs",
    "logs": PROJECT_ROOT / "data" / "logs",
    "modelweights": PROJECT_ROOT / "modelweights",
    "cache": PROJECT_ROOT / "data" / "cache",
}


# =============================================================================
# MODEL CONFIGURATION
# =============================================================================

@dataclass
class ModelConfig:
    """Configuration for the detection model."""
    
    # Path to model weights directory
    weights_dir: Path = PATHS["modelweights"]
    
    # Confidence threshold for detections
    confidence_threshold: float = 0.5
    
    # Maximum detections per image
    max_detections_per_image: int = 50
    
    # Input image size (for preprocessing)
    input_size: tuple = (640, 640)
    
    # Device for inference (auto-detect)
    device: str = "auto"
    
    # Batch size for processing multiple images
    batch_size: int = 8
    
    # Enable simulation mode if model loading fails
    simulation_mode: bool = True


# =============================================================================
# RISK ENGINE CONFIGURATION
# =============================================================================

@dataclass
class RiskConfig:
    """Configuration for the risk scoring engine."""
    
    # Base risk scores for different issues
    base_scores: Dict[str, int] = field(default_factory=lambda: {
        "mismatch": 40,      # Misdeclaration detected
        "concealment": 30,   # Concealment detected
        "anomaly": 30,       # Anomaly/restricted item detected
    })
    
    # Minimum and maximum risk scores
    min_risk: int = 0
    max_risk: int = 100
    
    # Risk thresholds for categorization
    thresholds: Dict[str, int] = field(default_factory=lambda: {
        "low": 25,
        "medium": 50,
        "high": 75,
        "critical": 90,
    })
    
    # Context multiplier settings
    context_multipliers: Dict[str, float] = field(default_factory=lambda: {
        "high_frequency": 1.2,      # When object appears frequently
        "concealment": 1.3,         # When concealment is detected
        "anomaly": 1.4,             # When anomaly is detected
        "multiple_issues": 1.5,     # When multiple issues detected
    })


# =============================================================================
# DETECTION CATEGORIES
# =============================================================================

@dataclass
class DetectionConfig:
    """Configuration for object detection categories."""
    
    # List of restricted/prohibited items
    restricted_items: List[str] = field(default_factory=lambda: [
        "weapon", "gun", "knife", "explosive", "drugs", "narcotics",
        "ammunition", "firearm", "grenade", "bomb", "contraband",
        "illegal_substance", "prohibited_chemical", "radioactive",
        "counterfeit", "ivory", "endangered_species", "unregistered_medication"
    ])
    
    # Items that suggest concealment when grouped
    concealment_indicators: List[str] = field(default_factory=lambda: [
        "dense_material", "metal_sheet", "lead", "unusual_cavity",
        "false_bottom", "hidden_compartment", "wrapped_bundle",
        "layered_packaging", "shielded_container"
    ])
    
    # High-value items requiring extra scrutiny
    high_value_items: List[str] = field(default_factory=lambda: [
        "jewelry", "gold", "diamond", "currency", "precious_metal",
        "artwork", "antique", "luxury_watch", "electronics"
    ])


# =============================================================================
# CACHE CONFIGURATION
# =============================================================================

@dataclass
class CacheConfig:
    """Configuration for the caching system."""
    
    # Enable/disable caching
    enabled: bool = True
    
    # Cache directory
    cache_dir: Path = PATHS["cache"]
    
    # Maximum cache size in MB
    max_size_mb: int = 500
    
    # Cache expiration time in seconds (24 hours)
    expiration_seconds: int = 86400
    
    # Hash algorithm for image hashing
    hash_algorithm: str = "sha256"


# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================

@dataclass
class LogConfig:
    """Configuration for logging."""
    
    # Log directory
    log_dir: Path = PATHS["logs"]
    
    # Log file name
    log_file: str = "app.log"
    
    # Log level
    level: str = "INFO"
    
    # Log format
    format: str = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} | {message}"
    
    # Maximum log file size in MB
    max_size_mb: int = 10
    
    # Number of backup log files to keep
    backup_count: int = 5
    
    # Enable console logging
    console_output: bool = True


# =============================================================================
# UI CONFIGURATION
# =============================================================================

@dataclass
class UIConfig:
    """Configuration for the Streamlit UI."""
    
    # Page title
    page_title: str = "CargoIQ - AI Cargo Intelligence"
    
    # Page icon
    page_icon: str = "📦"
    
    # Layout mode
    layout: str = "wide"
    
    # Maximum number of images to upload
    max_upload_images: int = 50
    
    # Allowed image formats
    allowed_formats: List[str] = field(default_factory=lambda: [
        "png", "jpg", "jpeg", "bmp", "tiff", "webp"
    ])
    
    # Maximum file size in MB
    max_file_size_mb: int = 10


# =============================================================================
# SIMULATION CONFIGURATION
# =============================================================================

@dataclass
class SimulationConfig:
    """Configuration for simulation mode (when real model unavailable)."""
    
    # Enable simulation
    enabled: bool = True
    
    # Simulated detection labels with weights (higher = more likely)
    detection_weights: Dict[str, float] = field(default_factory=lambda: {
        # Common cargo items
        "laptop": 0.15,
        "phone": 0.12,
        "tablet": 0.08,
        "camera": 0.06,
        "battery": 0.10,
        "charger": 0.08,
        "clothing": 0.12,
        "shoes": 0.06,
        "books": 0.05,
        "documents": 0.04,
        "food_items": 0.03,
        "cosmetics": 0.04,
        "medicine": 0.03,
        "jewelry": 0.02,
        "watch": 0.02,
        # Less common / suspicious items
        "knife": 0.01,
        "dense_material": 0.02,
        "unusual_shape": 0.02,
        "wrapped_bundle": 0.01,
        "currency": 0.01,
        "unidentified_object": 0.02,
    })
    
    # Range for number of detections per image
    min_detections: int = 2
    max_detections: int = 8
    
    # Confidence score range
    min_confidence: float = 0.55
    max_confidence: float = 0.98


# =============================================================================
# GLOBAL CONFIGURATION INSTANCES
# =============================================================================

# Create global configuration instances
model_config = ModelConfig()
risk_config = RiskConfig()
detection_config = DetectionConfig()
cache_config = CacheConfig()
log_config = LogConfig()
ui_config = UIConfig()
simulation_config = SimulationConfig()


def ensure_directories():
    """Create all required directories if they don't exist."""
    for name, path in PATHS.items():
        if isinstance(path, Path):
            path.mkdir(parents=True, exist_ok=True)


# Ensure directories exist on import
ensure_directories()