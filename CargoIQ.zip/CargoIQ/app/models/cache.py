"""
CargoIQ Inference Cache

This module provides caching functionality for inference results
to avoid recomputation for identical images.
"""

import os
import json
import pickle
import time
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import hashlib
import threading

from app.config import cache_config, PATHS
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class CacheEntry:
    """Represents a cache entry with metadata."""
    data: Any
    timestamp: float
    access_count: int = 0
    
    def is_expired(self, expiration_seconds: int) -> bool:
        """Check if the cache entry has expired."""
        return (time.time() - self.timestamp) > expiration_seconds


class InferenceCache:
    """
    Inference Cache for Detection Results
    
    This cache stores detection results keyed by image hash to avoid
    redundant inference on identical images.
    
    Features:
    - In-memory caching with optional disk persistence
    - Thread-safe operations
    - Automatic expiration
    - Size-based eviction
    """
    
    def __init__(self, persist: bool = True):
        """
        Initialize the cache.
        
        Args:
            persist: Whether to persist cache to disk
        """
        self.enabled = cache_config.enabled
        self.persist = persist
        self.cache_dir = cache_config.cache_dir
        self.max_size = cache_config.max_size_mb * 1024 * 1024  # Convert to bytes
        self.expiration = cache_config.expiration_seconds
        
        # In-memory cache
        self._cache: Dict[str, CacheEntry] = {}
        self._lock = threading.Lock()
        
        # Statistics
        self._hits = 0
        self._misses = 0
        
        # Create cache directory
        if self.persist:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self._load_from_disk()
        
        logger.info(f"Cache initialized (enabled: {self.enabled}, persist: {persist})")
    
    def _get_cache_path(self, key: str) -> Path:
        """Get the file path for a cache entry."""
        return self.cache_dir / f"{key}.pkl"
    
    def _load_from_disk(self):
        """Load cached entries from disk."""
        try:
            cache_files = list(self.cache_dir.glob("*.pkl"))
            loaded = 0
            
            for cache_file in cache_files:
                try:
                    with open(cache_file, 'rb') as f:
                        entry = pickle.load(f)
                    
                    # Check if expired
                    if not entry.is_expired(self.expiration):
                        key = cache_file.stem
                        self._cache[key] = entry
                        loaded += 1
                    else:
                        # Remove expired file
                        cache_file.unlink()
                        
                except Exception as e:
                    logger.warning(f"Error loading cache file {cache_file}: {e}")
            
            logger.info(f"Loaded {loaded} entries from disk cache")
            
        except Exception as e:
            logger.error(f"Error loading disk cache: {e}")
    
    def _save_to_disk(self, key: str, entry: CacheEntry):
        """Save a cache entry to disk."""
        if not self.persist:
            return
        
        try:
            cache_path = self._get_cache_path(key)
            with open(cache_path, 'wb') as f:
                pickle.dump(entry, f)
        except Exception as e:
            logger.warning(f"Error saving cache entry to disk: {e}")
    
    def _remove_from_disk(self, key: str):
        """Remove a cache entry from disk."""
        if not self.persist:
            return
        
        try:
            cache_path = self._get_cache_path(key)
            if cache_path.exists():
                cache_path.unlink()
        except Exception as e:
            logger.warning(f"Error removing cache file: {e}")
    
    def _serialize_detections(self, detections: List[Any]) -> List[Dict]:
        """Serialize detection objects for caching."""
        return [d.to_dict() if hasattr(d, 'to_dict') else d for d in detections]
    
    def _deserialize_detections(self, data: List[Dict]) -> List[Any]:
        """Deserialize cached detection data."""
        from app.models.detector import Detection
        
        detections = []
        for d in data:
            if isinstance(d, dict):
                detections.append(Detection(
                    label=d['label'],
                    confidence=d['confidence'],
                    bbox=d.get('bbox')
                ))
            else:
                detections.append(d)
        
        return detections
    
    def get(self, key: str) -> Optional[List[Any]]:
        """
        Get a cached detection result.
        
        Args:
            key: Image hash key
        
        Returns:
            List of detections if found and not expired, None otherwise
        """
        if not self.enabled:
            return None
        
        with self._lock:
            entry = self._cache.get(key)
            
            if entry is None:
                self._misses += 1
                return None
            
            # Check expiration
            if entry.is_expired(self.expiration):
                self._remove_entry(key)
                self._misses += 1
                return None
            
            # Update access count
            entry.access_count += 1
            self._hits += 1
            
            return self._deserialize_detections(entry.data)
    
    def put(self, key: str, detections: List[Any]):
        """
        Cache a detection result.
        
        Args:
            key: Image hash key
            detections: List of detection objects
        """
        if not self.enabled:
            return
        
        with self._lock:
            # Serialize detections
            serialized = self._serialize_detections(detections)
            
            # Create entry
            entry = CacheEntry(
                data=serialized,
                timestamp=time.time(),
                access_count=0
            )
            
            # Check if we need to evict
            self._evict_if_needed()
            
            # Store entry
            self._cache[key] = entry
            
            # Save to disk
            self._save_to_disk(key, entry)
            
            logger.debug(f"Cached result for key {key[:8]}...")
    
    def _remove_entry(self, key: str):
        """Remove an entry from cache."""
        if key in self._cache:
            del self._cache[key]
            self._remove_from_disk(key)
    
    def _evict_if_needed(self):
        """Evict entries if cache is too large."""
        # Simple size estimation
        current_size = len(str(self._cache)) * 2  # Rough estimate
        
        if current_size > self.max_size:
            # Remove oldest entries
            sorted_entries = sorted(
                self._cache.items(),
                key=lambda x: x[1].timestamp
            )
            
            # Remove oldest 25%
            num_to_remove = len(sorted_entries) // 4
            for key, _ in sorted_entries[:num_to_remove]:
                self._remove_entry(key)
            
            logger.info(f"Evicted {num_to_remove} cache entries")
    
    def clear(self):
        """Clear all cache entries."""
        with self._lock:
            self._cache.clear()
            
            # Clear disk cache
            if self.persist:
                for cache_file in self.cache_dir.glob("*.pkl"):
                    try:
                        cache_file.unlink()
                    except:
                        pass
            
            self._hits = 0
            self._misses = 0
            
        logger.info("Cache cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            total = self._hits + self._misses
            hit_rate = (self._hits / total * 100) if total > 0 else 0
            
            return {
                "enabled": self.enabled,
                "entries": len(self._cache),
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(hit_rate, 2),
                "persist": self.persist
            }
    
    def __len__(self) -> int:
        """Get number of cached entries."""
        return len(self._cache)