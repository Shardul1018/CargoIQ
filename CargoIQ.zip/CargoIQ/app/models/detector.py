"""
CargoIQ Detector Module

This module handles loading and managing the object detection model.
Supports Cascade Mask R-CNN and DDOD models.
"""

import os
import random
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

import torch
import torch.nn as nn
import numpy as np
from PIL import Image

from app.config import model_config, simulation_config, PATHS
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)

# Try to import mmdetection
MMDET_AVAILABLE = False
try:
    from mmdet.apis import init_detector, inference_detector
    MMDET_AVAILABLE = True
    logger.info("MMDetection available")
except ImportError:
    logger.warning("MMDetection not installed - will use simulation mode")


@dataclass
class Detection:
    """Represents a single object detection."""
    label: str
    confidence: float
    bbox: Optional[Tuple[int, int, int, int]] = None  # x1, y1, x2, y2
    mask: Optional[Any] = None  # For instance segmentation
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert detection to dictionary."""
        result = {
            "label": self.label,
            "confidence": round(self.confidence, 4)
        }
        if self.bbox:
            result["bbox"] = self.bbox
        return result


# COCO-style class names (common for these models)
COCO_CLASSES = [
    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck',
    'boat', 'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench',
    'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra',
    'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
    'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove',
    'skateboard', 'surfboard', 'tennis racket', 'bottle', 'wine glass', 'cup',
    'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich', 'orange',
    'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
    'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse',
    'remote', 'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink',
    'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier',
    'toothbrush'
]

# X-ray/Cargo specific classes (if your model was trained on cargo data)
CARGO_CLASSES = [
    'laptop', 'phone', 'tablet', 'camera', 'battery', 'knife', 'scissors',
    'gun', 'weapon', 'bottle', 'liquid', 'electronics', 'clothing', 'shoes',
    'book', 'document', 'food', 'organic', 'metal', 'wire', 'cable',
    'bag', 'container', 'box', 'suspicious_object', 'prohibited_item'
]


class CargoDetector:
    """
    Cargo Object Detection Model Handler
    
    Supports:
    - Cascade Mask R-CNN (cascade_mask_rcnn_r101_with_RoR1.pth)
    - DDOD (ddod_r101_with_RoR1.pth)
    """
    
    def __init__(self, model_name: str = "ddod"):
        """
        Initialize the cargo detector.
        
        Args:
            model_name: Which model to use - "ddod" (faster) or "cascade" (more accurate)
        """
        self.model = None
        self.model_name = model_name
        self.device = self._get_device()
        self.is_simulation = False
        self.model_path = None
        self.config_path = None
        self.classes = COCO_CLASSES  # Default, may be updated
        
        # Try to load the real model
        self._load_model()
    
    def _get_device(self) -> str:
        """Determine the best device for inference."""
        if torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
            gpu_mem = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            logger.info(f"Using GPU: {gpu_name} ({gpu_mem:.1f} GB)")
            return "cuda:0"
        else:
            logger.info("Using CPU")
            return "cpu"
    
    def _find_model_weights(self) -> Optional[Path]:
        """Find available model weight files."""
        weights_dir = PATHS["modelweights"]
        
        if not weights_dir.exists():
            logger.warning(f"Model weights directory not found: {weights_dir}")
            return None
        
        # Look for specific models
        ddod_path = weights_dir / "ddod_r101_with_RoR1.pth"
        cascade_path = weights_dir / "cascade_mask_rcnn_r101_with_RoR1.pth"
        
        # Choose based on preference
        if self.model_name == "ddod" and ddod_path.exists():
            logger.info(f"Selected DDOD model: {ddod_path}")
            return ddod_path
        elif self.model_name == "cascade" and cascade_path.exists():
            logger.info(f"Selected Cascade Mask R-CNN model: {cascade_path}")
            return cascade_path
        elif ddod_path.exists():
            logger.info(f"Using DDOD model (default): {ddod_path}")
            return ddod_path
        elif cascade_path.exists():
            logger.info(f"Using Cascade Mask R-CNN model: {cascade_path}")
            return cascade_path
        
        # Fallback: any .pth file
        pth_files = list(weights_dir.glob("*.pth"))
        if pth_files:
            logger.info(f"Using model: {pth_files[0]}")
            return pth_files[0]
        
        logger.warning("No model weights found")
        return None
    
    def _load_model(self):
        """Load the detection model."""
        model_path = self._find_model_weights()
        
        if model_path is None:
            logger.info("No model weights found. Enabling simulation mode.")
            self.is_simulation = True
            return
        
        self.model_path = model_path
        
        # Try MMDetection loading
        if MMDET_AVAILABLE:
            try:
                self._load_mmdet_model(model_path)
                return
            except Exception as e:
                logger.warning(f"MMDetection loading failed: {e}")
        
        # Try direct PyTorch loading
        try:
            self._load_pytorch_model(model_path)
            return
        except Exception as e:
            logger.warning(f"PyTorch loading failed: {e}")
        
        # Fall back to simulation
        logger.info("Could not load model. Using simulation mode.")
        self.is_simulation = True
    
    def _load_mmdet_model(self, model_path: Path):
        """Load model using MMDetection."""
        logger.info(f"Loading with MMDetection: {model_path}")
        
        # Create a minimal config for the model
        config_str = self._generate_model_config(model_path)
        
        # Save temp config
        config_path = PATHS["modelweights"] / "temp_config.py"
        with open(config_path, 'w') as f:
            f.write(config_str)
        
        # Initialize model
        self.model = init_detector(str(config_path), str(model_path), device=self.device)
        self.config_path = config_path
        
        logger.info("Model loaded successfully with MMDetection!")
    
    def _generate_model_config(self, model_path: Path) -> str:
        """Generate minimal config for the model."""
        model_name = model_path.stem.lower()
        
        if "cascade" in model_name:
            # Cascade Mask R-CNN config
            config = """
# Cascade Mask R-CNN config
_base_ = []

model = dict(
    type='CascadeRCNN',
    backbone=dict(
        type='ResNet',
        depth=101,
        num_stages=4,
        out_indices=(0, 1, 2, 3),
        frozen_stages=1,
        norm_cfg=dict(type='BN', requires_grad=True),
        norm_eval=True,
        style='pytorch'
    ),
    neck=dict(
        type='FPN',
        in_channels=[256, 512, 1024, 2048],
        out_channels=256,
        num_outs=5
    )
)
"""
        else:
            # DDOD config
            config = """
# DDOD config
_base_ = []

model = dict(
    type='DDOD',
    backbone=dict(
        type='ResNet',
        depth=101,
        num_stages=4,
        out_indices=(0, 1, 2, 3),
        frozen_stages=1,
        norm_cfg=dict(type='BN', requires_grad=True),
        norm_eval=True,
        style='pytorch'
    )
)
"""
        return config
    
    def _load_pytorch_model(self, model_path: Path):
        """Load model using pure PyTorch."""
        logger.info(f"Loading with PyTorch: {model_path}")
        
        checkpoint = torch.load(model_path, map_location=self.device)
        
        # Analyze checkpoint structure
        if isinstance(checkpoint, dict):
            logger.info(f"Checkpoint keys: {list(checkpoint.keys())}")
            
            # Extract model state dict
            if 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
            elif 'model' in checkpoint:
                state_dict = checkpoint['model']
            else:
                state_dict = checkpoint
            
            # Get class names if available
            if 'meta' in checkpoint and 'CLASSES' in checkpoint['meta']:
                self.classes = checkpoint['meta']['CLASSES']
                logger.info(f"Found {len(self.classes)} classes in checkpoint")
            
            # Store for later use
            self.checkpoint = checkpoint
            self.state_dict = state_dict
            
            logger.info("Checkpoint loaded - using simulation with real class info")
            self.is_simulation = True  # Will simulate but with real classes
            
        else:
            logger.warning("Unexpected checkpoint format")
            self.is_simulation = True
    
    def detect(self, image: Any) -> List[Detection]:
        """
        Run object detection on an image.
        
        Args:
            image: Input image (PIL Image, numpy array, or path)
        
        Returns:
            List of Detection objects
        """
        if self.is_simulation:
            return self._simulate_detection(image)
        
        return self._real_detection(image)
    
    def _real_detection(self, image: Any) -> List[Detection]:
        """Run actual model inference."""
        try:
            # Convert image to numpy array
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            elif isinstance(image, (str, Path)):
                img_array = np.array(Image.open(image))
            else:
                img_array = image
            
            # Run inference with MMDetection
            if MMDET_AVAILABLE and self.model is not None:
                result = inference_detector(self.model, img_array)
                return self._parse_mmdet_result(result)
            
            # Fallback to simulation
            return self._simulate_detection(image)
            
        except Exception as e:
            logger.error(f"Detection error: {e}")
            return self._simulate_detection(image)
    
    def _parse_mmdet_result(self, result) -> List[Detection]:
        """Parse MMDetection result to Detection objects."""
        detections = []
        
        # Handle different result formats
        if isinstance(result, tuple):
            bbox_result, mask_result = result
        else:
            bbox_result = result
            mask_result = None
        
        # Process each class
        for class_id, bboxes in enumerate(bbox_result):
            if len(bboxes) == 0:
                continue
            
            class_name = self.classes[class_id] if class_id < len(self.classes) else f"class_{class_id}"
            
            for bbox in bboxes:
                x1, y1, x2, y2, score = bbox[:5]
                
                if score < model_config.confidence_threshold:
                    continue
                
                detections.append(Detection(
                    label=class_name,
                    confidence=float(score),
                    bbox=(int(x1), int(y1), int(x2), int(y2))
                ))
        
        # Sort by confidence and limit
        detections.sort(key=lambda x: x.confidence, reverse=True)
        return detections[:model_config.max_detections_per_image]
    
    def _simulate_detection(self, image: Any) -> List[Detection]:
        """
        Simulate object detection for testing/demo purposes.
        Uses realistic cargo/X-ray item categories.
        """
        # Cargo-specific detection weights
        cargo_weights = {
            # Electronics (common in cargo)
            "laptop": 0.12,
            "cell phone": 0.10,
            "keyboard": 0.05,
            "mouse": 0.04,
            "remote": 0.03,
            "tv": 0.02,
            
            # Personal items
            "backpack": 0.08,
            "handbag": 0.06,
            "suitcase": 0.07,
            "umbrella": 0.03,
            
            # Clothing/Accessories
            "tie": 0.02,
            
            # Containers
            "bottle": 0.08,
            "cup": 0.04,
            "bowl": 0.03,
            
            # Tools/Dangerous items
            "knife": 0.02,
            "scissors": 0.02,
            
            # Other common items
            "book": 0.06,
            "clock": 0.03,
            "vase": 0.02,
            "toothbrush": 0.02,
            
            # Food items
            "banana": 0.02,
            "apple": 0.02,
            "orange": 0.02,
        }
        
        # Determine number of detections
        num_detections = random.randint(
            simulation_config.min_detections,
            simulation_config.max_detections
        )
        
        # Select items based on weights
        labels = list(cargo_weights.keys())
        weights = list(cargo_weights.values())
        
        selected_labels = random.choices(labels, weights=weights, k=num_detections)
        
        detections = []
        for label in selected_labels:
            # Generate confidence score
            confidence = random.uniform(
                simulation_config.min_confidence,
                simulation_config.max_confidence
            )
            
            # Generate bounding box
            x1 = random.randint(10, 400)
            y1 = random.randint(10, 300)
            x2 = x1 + random.randint(50, 200)
            y2 = y1 + random.randint(50, 150)
            
            detections.append(Detection(
                label=label,
                confidence=confidence,
                bbox=(x1, y1, x2, y2)
            ))
        
        return detections
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the loaded model."""
        return {
            "model_name": self.model_name,
            "is_simulation": self.is_simulation,
            "model_path": str(self.model_path) if self.model_path else None,
            "device": self.device,
            "num_classes": len(self.classes),
            "confidence_threshold": model_config.confidence_threshold,
            "mmdet_available": MMDET_AVAILABLE
        }


# Singleton instance
_detector_instance: Optional[CargoDetector] = None


def get_detector(model_name: str = "ddod") -> CargoDetector:
    """Get or create the singleton detector instance."""
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = CargoDetector(model_name=model_name)
    return _detector_instance