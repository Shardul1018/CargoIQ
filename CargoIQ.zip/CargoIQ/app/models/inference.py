"""
CargoIQ Inference Engine

This module manages the inference process for cargo images,
including batch processing and result aggregation.
"""

import time
from pathlib import Path
from typing import List, Dict, Any, Union, Optional
from dataclasses import dataclass, field
from PIL import Image
import numpy as np

from app.models.detector import CargoDetector, Detection, get_detector
from app.models.cache import InferenceCache
from app.utils.image_utils import load_image, preprocess_image
from app.utils.hashing import compute_image_hash
from app.utils.logger import get_logger
from app.config import model_config


# Initialize logger
logger = get_logger(__name__)


@dataclass
class ImageInferenceResult:
    """Result of inference on a single image."""
    image_id: str
    image_hash: str
    detections: List[Detection]
    inference_time: float
    from_cache: bool
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "image_id": self.image_id,
            "image_hash": self.image_hash,
            "detections": [d.to_dict() for d in self.detections],
            "inference_time": round(self.inference_time, 4),
            "from_cache": self.from_cache
        }


@dataclass
class BatchInferenceResult:
    """Result of inference on multiple images."""
    results: List[ImageInferenceResult] = field(default_factory=list)
    total_images: int = 0
    total_detections: int = 0
    total_time: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "results": [r.to_dict() for r in self.results],
            "total_images": self.total_images,
            "total_detections": self.total_detections,
            "total_time": round(self.total_time, 4),
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses
        }


class InferenceEngine:
    """
    Inference Engine for Cargo Detection
    
    This engine handles:
    - Single and batch image inference
    - Caching of results to avoid recomputation
    - Image preprocessing
    - Result aggregation
    """
    
    def __init__(self, use_cache: bool = True):
        """
        Initialize the inference engine.
        
        Args:
            use_cache: Whether to use caching for inference results
        """
        self.detector = get_detector()
        self.cache = InferenceCache() if use_cache else None
        self.use_cache = use_cache
        
        logger.info(f"Inference Engine initialized (cache: {use_cache})")
    
    def infer_single(
        self,
        image: Union[str, Path, Image.Image, bytes, np.ndarray],
        image_id: Optional[str] = None
    ) -> ImageInferenceResult:
        """
        Run inference on a single image.
        
        Args:
            image: Input image (path, PIL Image, bytes, or numpy array)
            image_id: Optional identifier for the image
        
        Returns:
            ImageInferenceResult containing detections
        """
        start_time = time.time()
        
        # Load and preprocess image
        pil_image = load_image(image)
        
        # Compute hash for caching
        image_hash = compute_image_hash(pil_image)
        
        # Generate image ID if not provided
        if image_id is None:
            if isinstance(image, (str, Path)):
                image_id = Path(image).name
            else:
                image_id = f"image_{image_hash[:8]}"
        
        # Check cache
        if self.use_cache and self.cache is not None:
            cached_result = self.cache.get(image_hash)
            if cached_result is not None:
                logger.debug(f"Cache hit for {image_id}")
                return ImageInferenceResult(
                    image_id=image_id,
                    image_hash=image_hash,
                    detections=cached_result,
                    inference_time=time.time() - start_time,
                    from_cache=True
                )
        
        # Run detection
        logger.debug(f"Running inference on {image_id}")
        detections = self.detector.detect(pil_image)
        
        # Cache the result
        if self.use_cache and self.cache is not None:
            self.cache.put(image_hash, detections)
        
        inference_time = time.time() - start_time
        
        return ImageInferenceResult(
            image_id=image_id,
            image_hash=image_hash,
            detections=detections,
            inference_time=inference_time,
            from_cache=False
        )
    
    def infer_batch(
        self,
        images: List[Union[str, Path, Image.Image, bytes, np.ndarray]],
        image_ids: Optional[List[str]] = None
    ) -> BatchInferenceResult:
        """
        Run inference on multiple images.
        
        Args:
            images: List of input images
            image_ids: Optional list of identifiers for images
        
        Returns:
            BatchInferenceResult containing all detections
        """
        start_time = time.time()
        
        # Generate image IDs if not provided
        if image_ids is None:
            image_ids = [None] * len(images)
        
        # Process each image
        results = []
        cache_hits = 0
        cache_misses = 0
        total_detections = 0
        
        for i, (image, image_id) in enumerate(zip(images, image_ids)):
            try:
                result = self.infer_single(image, image_id)
                results.append(result)
                
                if result.from_cache:
                    cache_hits += 1
                else:
                    cache_misses += 1
                
                total_detections += len(result.detections)
                
                logger.debug(f"Processed image {i+1}/{len(images)}: {result.image_id}")
                
            except Exception as e:
                logger.error(f"Error processing image {i}: {e}")
                # Create empty result for failed image
                results.append(ImageInferenceResult(
                    image_id=str(image_id) if image_id else f"image_{i}",
                    image_hash="error",
                    detections=[],
                    inference_time=0,
                    from_cache=False
                ))
        
        total_time = time.time() - start_time
        
        logger.info(
            f"Batch inference complete: {len(images)} images, "
            f"{total_detections} detections, {total_time:.2f}s"
        )
        
        return BatchInferenceResult(
            results=results,
            total_images=len(images),
            total_detections=total_detections,
            total_time=total_time,
            cache_hits=cache_hits,
            cache_misses=cache_misses
        )
    
    def clear_cache(self):
        """Clear the inference cache."""
        if self.cache is not None:
            self.cache.clear()
            logger.info("Inference cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        if self.cache is not None:
            return self.cache.get_stats()
        return {"enabled": False}


# Create singleton instance
_inference_engine: Optional[InferenceEngine] = None


def get_inference_engine() -> InferenceEngine:
    """Get or create the singleton inference engine instance."""
    global _inference_engine
    if _inference_engine is None:
        _inference_engine = InferenceEngine()
    return _inference_engine