"""
CargoIQ Logger Module

This module provides centralized logging functionality for the application.
"""

import sys
import os
from pathlib import Path
from typing import Optional
from datetime import datetime

from loguru import logger

from app.config import log_config, PATHS


def setup_logging(
    log_level: str = None,
    log_file: str = None,
    console: bool = None
) -> None:
    """
    Set up logging configuration.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_file: Path to log file
        console: Whether to output to console
    """
    # Use config defaults if not specified
    level = log_level or log_config.level
    console_output = console if console is not None else log_config.console_output
    
    # Remove default handler
    logger.remove()
    
    # Add console handler
    if console_output:
        logger.add(
            sys.stdout,
            level=level,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
                   "<level>{level: <8}</level> | "
                   "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
                   "<level>{message}</level>",
            colorize=True
        )
    
    # Add file handler
    log_path = log_file or (log_config.log_dir / log_config.log_file)
    
    # Ensure log directory exists
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    
    logger.add(
        str(log_path),
        level=level,
        format=log_config.format,
        rotation=f"{log_config.max_size_mb} MB",
        retention=log_config.backup_count,
        compression="zip"
    )
    
    logger.info(f"Logging initialized. Level: {level}, File: {log_path}")


def get_logger(name: str = None):
    """
    Get a logger instance.
    
    Args:
        name: Logger name (usually __name__)
    
    Returns:
        Logger instance
    """
    if name:
        return logger.bind(name=name)
    return logger


# Initialize logging on module import
_initialized = False

def _ensure_initialized():
    global _initialized
    if not _initialized:
        setup_logging()
        _initialized = True

_ensure_initialized()