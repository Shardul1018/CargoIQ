"""
CargoIQ Hashing Utilities

This module provides hashing functions for images and files,
used for caching and deduplication.
"""

import hashlib
from pathlib import Path
from typing import Union
from io import BytesIO

from PIL import Image
import numpy as np

try:
    import imagehash
    IMAGEHASH_AVAILABLE = True
except ImportError:
    IMAGEHASH_AVAILABLE = False

from app.config import cache_config
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


def compute_file_hash(
    file_path: Union[str, Path],
    algorithm: str = None
) -> str:
    """
    Compute hash of a file.
    
    Args:
        file_path: Path to file
        algorithm: Hash algorithm (default from config)
    
    Returns:
        Hex digest of file hash
    """
    algorithm = algorithm or cache_config.hash_algorithm
    
    hash_obj = hashlib.new(algorithm)
    
    with open(file_path, 'rb') as f:
        # Read in chunks to handle large files
        for chunk in iter(lambda: f.read(8192), b''):
            hash_obj.update(chunk)
    
    return hash_obj.hexdigest()


def compute_bytes_hash(
    data: bytes,
    algorithm: str = None
) -> str:
    """
    Compute hash of bytes data.
    
    Args:
        data: Bytes to hash
        algorithm: Hash algorithm (default from config)
    
    Returns:
        Hex digest of data hash
    """
    algorithm = algorithm or cache_config.hash_algorithm
    
    hash_obj = hashlib.new(algorithm)
    hash_obj.update(data)
    
    return hash_obj.hexdigest()


def compute_image_hash(
    image: Union[str, Path, Image.Image, bytes, np.ndarray],
    method: str = "average"
) -> str:
    """
    Compute perceptual hash of an image.
    
    Perceptual hashing creates similar hashes for visually similar images,
    making it useful for detecting duplicate or near-duplicate images.
    
    Args:
        image: Input image (path, PIL Image, bytes, or numpy array)
        method: Hash method ("average", "phash", "dhash", "whash")
    
    Returns:
        Hex string of image hash
    """
    # Convert to PIL Image if necessary
    pil_image = _to_pil_image(image)
    
    if pil_image is None:
        # Fall back to simple content hash
        logger.warning("Could not load image for perceptual hashing, using content hash")
        if isinstance(image, bytes):
            return compute_bytes_hash(image)
        elif isinstance(image, (str, Path)):
            return compute_file_hash(image)
        else:
            return hashlib.sha256(str(image).encode()).hexdigest()
    
    # Use imagehash library if available
    if IMAGEHASH_AVAILABLE:
        try:
            if method == "average":
                img_hash = imagehash.average_hash(pil_image)
            elif method == "phash":
                img_hash = imagehash.phash(pil_image)
            elif method == "dhash":
                img_hash = imagehash.dhash(pil_image)
            elif method == "whash":
                img_hash = imagehash.whash(pil_image)
            else:
                img_hash = imagehash.average_hash(pil_image)
            
            return str(img_hash)
            
        except Exception as e:
            logger.warning(f"imagehash failed: {e}, using fallback")
    
    # Fallback: simple pixel-based hash
    return _simple_image_hash(pil_image)


def _to_pil_image(
    image: Union[str, Path, Image.Image, bytes, np.ndarray]
) -> Image.Image:
    """
    Convert various image formats to PIL Image.
    
    Args:
        image: Input in various formats
    
    Returns:
        PIL Image or None if conversion fails
    """
    try:
        if isinstance(image, Image.Image):
            return image
        
        elif isinstance(image, (str, Path)):
            path = Path(image)
            if path.exists():
                return Image.open(path)
            else:
                logger.warning(f"Image path does not exist: {path}")
                return None
        
        elif isinstance(image, bytes):
            return Image.open(BytesIO(image))
        
        elif isinstance(image, np.ndarray):
            return Image.fromarray(image)
        
        else:
            logger.warning(f"Unknown image type: {type(image)}")
            return None
            
    except Exception as e:
        logger.error(f"Error converting to PIL Image: {e}")
        return None


def _simple_image_hash(image: Image.Image, size: int = 16) -> str:
    """
    Compute a simple hash based on downscaled image pixels.
    
    Args:
        image: PIL Image
        size: Size to downscale to
    
    Returns:
        Hex hash string
    """
    try:
        # Convert to grayscale and resize
        img = image.convert('L').resize((size, size), Image.Resampling.LANCZOS)
        
        # Get pixel data
        pixels = list(img.getdata())
        
        # Compute average
        avg = sum(pixels) / len(pixels)
        
        # Create binary hash based on average
        bits = ''.join('1' if p > avg else '0' for p in pixels)
        
        # Convert to hex
        hash_int = int(bits, 2)
        hex_hash = format(hash_int, 'x').zfill(size * size // 4)
        
        return hex_hash
        
    except Exception as e:
        logger.error(f"Error in simple image hash: {e}")
        # Ultimate fallback
        return hashlib.sha256(image.tobytes()).hexdigest()[:32]


def compute_combined_hash(
    image: Union[str, Path, Image.Image, bytes, np.ndarray]
) -> str:
    """
    Compute a combined hash using both content and perceptual hashing.
    
    This provides a unique identifier that considers both exact content
    and visual similarity.
    
    Args:
        image: Input image
    
    Returns:
        Combined hash string
    """
    # Get perceptual hash
    perceptual = compute_image_hash(image, method="average")
    
    # Get content hash
    if isinstance(image, bytes):
        content = compute_bytes_hash(image)[:16]
    elif isinstance(image, (str, Path)):
        if Path(image).exists():
            content = compute_file_hash(image)[:16]
        else:
            content = "0" * 16
    elif isinstance(image, Image.Image):
        content = compute_bytes_hash(image.tobytes())[:16]
    elif isinstance(image, np.ndarray):
        content = compute_bytes_hash(image.tobytes())[:16]
    else:
        content = "0" * 16
    
    # Combine hashes
    return f"{perceptual}_{content}"


def are_images_similar(
    image1: Union[str, Path, Image.Image, bytes],
    image2: Union[str, Path, Image.Image, bytes],
    threshold: int = 5
) -> bool:
    """
    Check if two images are visually similar using perceptual hashing.
    
    Args:
        image1: First image
        image2: Second image
        threshold: Maximum hamming distance for similarity
    
    Returns:
        True if images are similar
    """
    if not IMAGEHASH_AVAILABLE:
        # Fall back to exact content comparison
        hash1 = compute_image_hash(image1)
        hash2 = compute_image_hash(image2)
        return hash1 == hash2
    
    try:
        pil1 = _to_pil_image(image1)
        pil2 = _to_pil_image(image2)
        
        if pil1 is None or pil2 is None:
            return False
        
        hash1 = imagehash.average_hash(pil1)
        hash2 = imagehash.average_hash(pil2)
        
        # Hamming distance
        distance = hash1 - hash2
        
        return distance <= threshold
        
    except Exception as e:
        logger.error(f"Error comparing images: {e}")
        return False


def get_hash_info() -> dict:
    """
    Get information about available hashing capabilities.
    
    Returns:
        Dict with hashing capability information
    """
    return {
        "imagehash_available": IMAGEHASH_AVAILABLE,
        "default_algorithm": cache_config.hash_algorithm,
        "supported_methods": ["average", "phash", "dhash", "whash"] if IMAGEHASH_AVAILABLE else ["simple"],
        "fallback_available": True
    }