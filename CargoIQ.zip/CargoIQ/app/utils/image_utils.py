"""
CargoIQ Image Utilities

This module provides image loading, preprocessing, and manipulation utilities.
"""

import os
from pathlib import Path
from typing import Union, Tuple, List, Optional
from io import BytesIO

from PIL import Image, ImageOps, ImageEnhance, ImageFilter
import numpy as np

from app.config import model_config, ui_config
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


def load_image(
    source: Union[str, Path, bytes, Image.Image, np.ndarray]
) -> Optional[Image.Image]:
    """
    Load an image from various sources.
    
    Args:
        source: Image source (path, bytes, PIL Image, or numpy array)
    
    Returns:
        PIL Image or None if loading fails
    """
    try:
        if isinstance(source, Image.Image):
            return source
        
        elif isinstance(source, np.ndarray):
            return Image.fromarray(source)
        
        elif isinstance(source, bytes):
            return Image.open(BytesIO(source))
        
        elif isinstance(source, (str, Path)):
            path = Path(source)
            if path.exists():
                return Image.open(path)
            else:
                logger.warning(f"Image file not found: {path}")
                return None
        
        else:
            logger.warning(f"Unsupported image source type: {type(source)}")
            return None
            
    except Exception as e:
        logger.error(f"Error loading image: {e}")
        return None


def preprocess_image(
    image: Image.Image,
    target_size: Tuple[int, int] = None,
    normalize: bool = False,
    to_rgb: bool = True
) -> Image.Image:
    """
    Preprocess an image for model inference.
    
    Args:
        image: PIL Image to preprocess
        target_size: Target size (width, height) for resizing
        normalize: Whether to normalize pixel values
        to_rgb: Whether to convert to RGB
    
    Returns:
        Preprocessed PIL Image
    """
    # Use config default if not specified
    if target_size is None:
        target_size = model_config.input_size
    
    # Convert to RGB if needed
    if to_rgb and image.mode != 'RGB':
        image = image.convert('RGB')
    
    # Resize while maintaining aspect ratio
    image = resize_with_padding(image, target_size)
    
    return image


def resize_with_padding(
    image: Image.Image,
    target_size: Tuple[int, int],
    fill_color: Tuple[int, int, int] = (128, 128, 128)
) -> Image.Image:
    """
    Resize image to target size while maintaining aspect ratio,
    adding padding as needed.
    
    Args:
        image: PIL Image
        target_size: Target (width, height)
        fill_color: Color for padding
    
    Returns:
        Resized and padded image
    """
    target_w, target_h = target_size
    orig_w, orig_h = image.size
    
    # Calculate scaling factor
    scale = min(target_w / orig_w, target_h / orig_h)
    
    # Calculate new size
    new_w = int(orig_w * scale)
    new_h = int(orig_h * scale)
    
    # Resize image
    resized = image.resize((new_w, new_h), Image.Resampling.LANCZOS)
    
    # Create padded image
    padded = Image.new('RGB', target_size, fill_color)
    
    # Calculate position to paste
    paste_x = (target_w - new_w) // 2
    paste_y = (target_h - new_h) // 2
    
    padded.paste(resized, (paste_x, paste_y))
    
    return padded


def resize_image(
    image: Image.Image,
    max_size: int = 1024,
    maintain_aspect: bool = True
) -> Image.Image:
    """
    Resize image to fit within max_size.
    
    Args:
        image: PIL Image
        max_size: Maximum dimension
        maintain_aspect: Whether to maintain aspect ratio
    
    Returns:
        Resized image
    """
    if maintain_aspect:
        image.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
        return image
    else:
        return image.resize((max_size, max_size), Image.Resampling.LANCZOS)


def enhance_image(
    image: Image.Image,
    brightness: float = 1.0,
    contrast: float = 1.0,
    sharpness: float = 1.0
) -> Image.Image:
    """
    Enhance image quality.
    
    Args:
        image: PIL Image
        brightness: Brightness factor (1.0 = original)
        contrast: Contrast factor (1.0 = original)
        sharpness: Sharpness factor (1.0 = original)
    
    Returns:
        Enhanced image
    """
    if brightness != 1.0:
        enhancer = ImageEnhance.Brightness(image)
        image = enhancer.enhance(brightness)
    
    if contrast != 1.0:
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(contrast)
    
    if sharpness != 1.0:
        enhancer = ImageEnhance.Sharpness(image)
        image = enhancer.enhance(sharpness)
    
    return image


def apply_xray_enhancement(image: Image.Image) -> Image.Image:
    """
    Apply enhancement suitable for X-ray images.
    
    Args:
        image: PIL Image
    
    Returns:
        Enhanced X-ray image
    """
    # Convert to grayscale if not already
    if image.mode != 'L':
        gray = image.convert('L')
    else:
        gray = image
    
    # Enhance contrast
    enhancer = ImageEnhance.Contrast(gray)
    enhanced = enhancer.enhance(1.5)
    
    # Apply slight sharpening
    enhanced = enhanced.filter(ImageFilter.SHARPEN)
    
    # Convert back to RGB
    return enhanced.convert('RGB')


def image_to_bytes(
    image: Image.Image,
    format: str = 'PNG',
    quality: int = 95
) -> bytes:
    """
    Convert PIL Image to bytes.
    
    Args:
        image: PIL Image
        format: Output format (PNG, JPEG, etc.)
        quality: Quality for lossy formats
    
    Returns:
        Image as bytes
    """
    buffer = BytesIO()
    
    if format.upper() == 'JPEG':
        # JPEG doesn't support alpha
        if image.mode in ('RGBA', 'LA'):
            image = image.convert('RGB')
        image.save(buffer, format=format, quality=quality)
    else:
        image.save(buffer, format=format)
    
    return buffer.getvalue()


def bytes_to_image(data: bytes) -> Optional[Image.Image]:
    """
    Convert bytes to PIL Image.
    
    Args:
        data: Image bytes
    
    Returns:
        PIL Image or None
    """
    try:
        return Image.open(BytesIO(data))
    except Exception as e:
        logger.error(f"Error converting bytes to image: {e}")
        return None


def get_image_info(image: Image.Image) -> dict:
    """
    Get information about an image.
    
    Args:
        image: PIL Image
    
    Returns:
        Dict with image information
    """
    return {
        "size": image.size,
        "width": image.width,
        "height": image.height,
        "mode": image.mode,
        "format": image.format,
        "is_animated": getattr(image, 'is_animated', False),
        "n_frames": getattr(image, 'n_frames', 1)
    }


def validate_image(
    source: Union[str, Path, bytes],
    max_size_mb: float = None,
    allowed_formats: List[str] = None
) -> Tuple[bool, str]:
    """
    Validate an image file.
    
    Args:
        source: Image source
        max_size_mb: Maximum file size in MB
        allowed_formats: List of allowed format extensions
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    max_size_mb = max_size_mb or ui_config.max_file_size_mb
    allowed_formats = allowed_formats or ui_config.allowed_formats
    
    try:
        # Check file size
        if isinstance(source, bytes):
            size_mb = len(source) / (1024 * 1024)
        elif isinstance(source, (str, Path)):
            size_mb = os.path.getsize(source) / (1024 * 1024)
        else:
            size_mb = 0
        
        if size_mb > max_size_mb:
            return False, f"File size ({size_mb:.2f}MB) exceeds maximum ({max_size_mb}MB)"
        
        # Try to load image
        image = load_image(source)
        if image is None:
            return False, "Could not load image"
        
        # Check format
        if isinstance(source, (str, Path)):
            ext = Path(source).suffix.lower().lstrip('.')
            if ext not in allowed_formats:
                return False, f"Format '{ext}' not allowed. Allowed: {allowed_formats}"
        
        return True, "Valid"
        
    except Exception as e:
        return False, f"Validation error: {str(e)}"


def create_thumbnail(
    image: Image.Image,
    size: Tuple[int, int] = (128, 128)
) -> Image.Image:
    """
    Create a thumbnail of an image.
    
    Args:
        image: PIL Image
        size: Thumbnail size
    
    Returns:
        Thumbnail image
    """
    thumb = image.copy()
    thumb.thumbnail(size, Image.Resampling.LANCZOS)
    return thumb


def create_image_grid(
    images: List[Image.Image],
    columns: int = 4,
    cell_size: Tuple[int, int] = (200, 200),
    padding: int = 10,
    background: Tuple[int, int, int] = (255, 255, 255)
) -> Image.Image:
    """
    Create a grid of images.
    
    Args:
        images: List of PIL Images
        columns: Number of columns
        cell_size: Size of each cell
        padding: Padding between cells
        background: Background color
    
    Returns:
        Grid image
    """
    if not images:
        return Image.new('RGB', (100, 100), background)
    
    # Calculate grid dimensions
    rows = (len(images) + columns - 1) // columns
    
    grid_width = columns * (cell_size[0] + padding) + padding
    grid_height = rows * (cell_size[1] + padding) + padding
    
    # Create grid
    grid = Image.new('RGB', (grid_width, grid_height), background)
    
    # Paste images
    for i, img in enumerate(images):
        row = i // columns
        col = i % columns
        
        x = padding + col * (cell_size[0] + padding)
        y = padding + row * (cell_size[1] + padding)
        
        # Resize to fit cell
        thumb = resize_with_padding(img, cell_size, background)
        grid.paste(thumb, (x, y))
    
    return grid


def generate_placeholder_image(
    size: Tuple[int, int] = (640, 640),
    text: str = "No Image",
    background: Tuple[int, int, int] = (200, 200, 200),
    text_color: Tuple[int, int, int] = (100, 100, 100)
) -> Image.Image:
    """
    Generate a placeholder image.
    
    Args:
        size: Image size
        text: Text to display
        background: Background color
        text_color: Text color
    
    Returns:
        Placeholder image
    """
    from PIL import ImageDraw
    
    image = Image.new('RGB', size, background)
    draw = ImageDraw.Draw(image)
    
    # Draw text in center
    bbox = draw.textbbox((0, 0), text)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    x = (size[0] - text_width) // 2
    y = (size[1] - text_height) // 2
    
    draw.text((x, y), text, fill=text_color)
    
    return image