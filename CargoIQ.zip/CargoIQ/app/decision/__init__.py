"""
CargoIQ Decision Package

This package provides decision support and recommendation functionality.
"""

from app.decision.advisor import DecisionAdvisor

__all__ = ["DecisionAdvisor"]