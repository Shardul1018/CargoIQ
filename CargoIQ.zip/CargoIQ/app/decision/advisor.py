"""
CargoIQ Decision Advisor Module

This module provides decision support and recommendations
for customs officers based on analysis results.
"""

from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


class ActionLevel(Enum):
    """Action level enumeration."""
    RELEASE = 1
    REVIEW = 2
    INSPECT = 3
    HOLD = 4
    ALERT = 5


@dataclass
class ActionItem:
    """Specific action item for officers."""
    priority: int  # 1 = highest
    action: str
    reason: str
    responsible_party: str
    time_sensitivity: str  # "immediate", "urgent", "standard"
    
    def to_dict(self) -> Dict:
        return {
            "priority": self.priority,
            "action": self.action,
            "reason": self.reason,
            "responsible_party": self.responsible_party,
            "time_sensitivity": self.time_sensitivity
        }


@dataclass
class Decision:
    """Complete decision recommendation."""
    primary_action: str
    action_level: ActionLevel
    action_items: List[ActionItem]
    risk_summary: str
    confidence_in_recommendation: float
    escalation_required: bool
    escalation_reason: Optional[str]
    documentation_required: List[str]
    follow_up_actions: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "primary_action": self.primary_action,
            "action_level": self.action_level.name,
            "action_items": [a.to_dict() for a in self.action_items],
            "risk_summary": self.risk_summary,
            "confidence_in_recommendation": round(self.confidence_in_recommendation, 2),
            "escalation_required": self.escalation_required,
            "escalation_reason": self.escalation_reason,
            "documentation_required": self.documentation_required,
            "follow_up_actions": self.follow_up_actions
        }


class DecisionAdvisor:
    """
    Decision Advisor for Cargo Clearance
    
    This advisor provides:
    - Primary action recommendations
    - Prioritized action items
    - Escalation guidance
    - Documentation requirements
    - Follow-up procedures
    """
    
    def __init__(self):
        """Initialize the decision advisor."""
        # Action thresholds based on risk score
        self.action_thresholds = {
            ActionLevel.RELEASE: (0, 25),
            ActionLevel.REVIEW: (25, 50),
            ActionLevel.INSPECT: (50, 75),
            ActionLevel.HOLD: (75, 90),
            ActionLevel.ALERT: (90, 100)
        }
        
        # Primary action descriptions
        self.action_descriptions = {
            ActionLevel.RELEASE: "RELEASE - Clear cargo for processing",
            ActionLevel.REVIEW: "REVIEW - Manual documentation review required",
            ActionLevel.INSPECT: "INSPECT - Physical inspection required",
            ActionLevel.HOLD: "HOLD - Do not release, pending investigation",
            ActionLevel.ALERT: "ALERT - Immediate security escalation required"
        }
        
        logger.info("Decision Advisor initialized")
    
    def _determine_action_level(
        self,
        risk_score: float,
        requires_immediate: bool,
        prohibited_found: bool
    ) -> ActionLevel:
        """Determine the appropriate action level."""
        # Override for critical situations
        if prohibited_found:
            return ActionLevel.ALERT
        if requires_immediate:
            return ActionLevel.HOLD
        
        # Determine by risk score
        for level, (low, high) in self.action_thresholds.items():
            if low <= risk_score < high:
                return level
        
        return ActionLevel.ALERT  # Default to highest if score >= 100
    
    def _generate_action_items(
        self,
        action_level: ActionLevel,
        mismatch_detected: bool,
        concealment_detected: bool,
        anomaly_detected: bool,
        anomaly_details: Dict[str, Any]
    ) -> List[ActionItem]:
        """Generate prioritized action items."""
        items = []
        priority = 1
        
        # Critical actions first
        if action_level == ActionLevel.ALERT:
            items.append(ActionItem(
                priority=priority,
                action="Contact security personnel immediately",
                reason="Critical risk level requires security involvement",
                responsible_party="Duty Officer",
                time_sensitivity="immediate"
            ))
            priority += 1
            
            items.append(ActionItem(
                priority=priority,
                action="Isolate cargo - do not allow access",
                reason="Potential prohibited items detected",
                responsible_party="Warehouse Staff",
                time_sensitivity="immediate"
            ))
            priority += 1
        
        # Prohibited items specific actions
        prohibited = anomaly_details.get("prohibited_items_found", [])
        if prohibited:
            items.append(ActionItem(
                priority=priority,
                action=f"Document prohibited items: {', '.join(prohibited)}",
                reason="Evidence preservation required",
                responsible_party="Inspection Officer",
                time_sensitivity="immediate"
            ))
            priority += 1
        
        # Mismatch actions
        if mismatch_detected:
            items.append(ActionItem(
                priority=priority,
                action="Verify cargo manifest against detected contents",
                reason="Mismatch between declared and detected items",
                responsible_party="Documentation Officer",
                time_sensitivity="urgent" if action_level.value >= 3 else "standard"
            ))
            priority += 1
            
            items.append(ActionItem(
                priority=priority,
                action="Request updated declaration from shipper",
                reason="Potential misdeclaration identified",
                responsible_party="Customs Officer",
                time_sensitivity="standard"
            ))
            priority += 1
        
        # Concealment actions
        if concealment_detected:
            items.append(ActionItem(
                priority=priority,
                action="Conduct physical inspection of flagged areas",
                reason="Concealment patterns detected in imaging",
                responsible_party="Inspection Team",
                time_sensitivity="urgent"
            ))
            priority += 1
            
            items.append(ActionItem(
                priority=priority,
                action="Request additional X-ray angles if available",
                reason="Verify concealment indicators",
                responsible_party="X-ray Operator",
                time_sensitivity="standard"
            ))
            priority += 1
        
        # Restricted items actions
        restricted = anomaly_details.get("restricted_items_found", [])
        if restricted:
            items.append(ActionItem(
                priority=priority,
                action=f"Verify permits for: {', '.join(restricted)}",
                reason="Restricted items require valid documentation",
                responsible_party="Documentation Officer",
                time_sensitivity="urgent"
            ))
            priority += 1
        
        # Standard review actions
        if action_level == ActionLevel.REVIEW:
            items.append(ActionItem(
                priority=priority,
                action="Review all shipping documentation",
                reason="Moderate risk level requires verification",
                responsible_party="Customs Officer",
                time_sensitivity="standard"
            ))
            priority += 1
        
        # Release with documentation
        if action_level == ActionLevel.RELEASE:
            items.append(ActionItem(
                priority=priority,
                action="Process cargo for release",
                reason="All checks passed within acceptable parameters",
                responsible_party="Clearance Officer",
                time_sensitivity="standard"
            ))
            priority += 1
        
        return items
    
    def _determine_documentation(
        self,
        action_level: ActionLevel,
        mismatch_detected: bool,
        concealment_detected: bool,
        anomaly_detected: bool
    ) -> List[str]:
        """Determine required documentation."""
        docs = []
        
        # Always required
        docs.append("Analysis report with timestamp")
        docs.append("Image identifiers analyzed")
        
        if action_level.value >= ActionLevel.REVIEW.value:
            docs.append("Officer notes and observations")
        
        if mismatch_detected:
            docs.append("Mismatch details and affected items list")
            docs.append("Original cargo manifest copy")
        
        if concealment_detected:
            docs.append("Concealment indicator screenshots")
            docs.append("Physical inspection findings (if conducted)")
        
        if anomaly_detected:
            docs.append("Anomaly item documentation")
            docs.append("Permit verification results")
        
        if action_level.value >= ActionLevel.HOLD.value:
            docs.append("Supervisor approval documentation")
            docs.append("Chain of custody form")
        
        if action_level == ActionLevel.ALERT:
            docs.append("Security incident report")
            docs.append("Evidence photographs")
            docs.append("Witness statements if applicable")
        
        return docs
    
    def _determine_follow_up(
        self,
        action_level: ActionLevel,
        requires_immediate: bool
    ) -> List[str]:
        """Determine follow-up actions."""
        follow_ups = []
        
        if action_level.value >= ActionLevel.INSPECT.value:
            follow_ups.append("Update case file with inspection results")
            follow_ups.append("Notify shipper of inspection status")
        
        if action_level.value >= ActionLevel.HOLD.value:
            follow_ups.append("Schedule case review within 24 hours")
            follow_ups.append("Coordinate with relevant authorities")
        
        if action_level == ActionLevel.ALERT:
            follow_ups.append("File formal incident report within 4 hours")
            follow_ups.append("Preserve all evidence chain documentation")
            follow_ups.append("Debrief involved personnel")
        
        if not follow_ups:
            follow_ups.append("No specific follow-up required - proceed with standard processing")
        
        return follow_ups
    
    def _calculate_confidence(
        self,
        avg_detection_confidence: float,
        num_detections: int,
        num_images: int
    ) -> float:
        """Calculate confidence in recommendation."""
        # Base confidence from detection confidence
        base = avg_detection_confidence
        
        # Adjust for amount of data
        data_factor = min(1.0, (num_detections / 10) * 0.2 + (num_images / 5) * 0.1)
        
        confidence = base * 0.7 + data_factor * 0.3
        
        return min(0.99, max(0.5, confidence))
    
    def advise(
        self,
        risk_score: float,
        risk_level: str,
        mismatch_detected: bool,
        mismatch_details: Dict[str, Any],
        concealment_detected: bool,
        concealment_details: Dict[str, Any],
        anomaly_detected: bool,
        anomaly_details: Dict[str, Any],
        avg_detection_confidence: float = 0.8,
        num_detections: int = 0,
        num_images: int = 0
    ) -> Decision:
        """
        Generate decision recommendation.
        
        Args:
            risk_score: Final risk score (0-100)
            risk_level: Risk level category
            mismatch_detected: Whether mismatch was detected
            mismatch_details: Mismatch analysis details
            concealment_detected: Whether concealment was detected
            concealment_details: Concealment analysis details
            anomaly_detected: Whether anomaly was detected
            anomaly_details: Anomaly analysis details
            avg_detection_confidence: Average detection confidence
            num_detections: Total number of detections
            num_images: Number of images analyzed
        
        Returns:
            Decision with complete recommendation
        """
        logger.info(f"Generating decision for risk score {risk_score}")
        
        # Check for critical conditions
        requires_immediate = anomaly_details.get("requires_immediate_action", False)
        prohibited_found = len(anomaly_details.get("prohibited_items_found", [])) > 0
        
        # Determine action level
        action_level = self._determine_action_level(
            risk_score, requires_immediate, prohibited_found
        )
        
        # Get primary action description
        primary_action = self.action_descriptions[action_level]
        
        # Generate action items
        action_items = self._generate_action_items(
            action_level,
            mismatch_detected,
            concealment_detected,
            anomaly_detected,
            anomaly_details
        )
        
        # Generate risk summary
        issues = []
        if mismatch_detected:
            issues.append("declaration mismatch")
        if concealment_detected:
            issues.append("concealment indicators")
        if anomaly_detected:
            issues.append("anomalous items")
        
        if issues:
            risk_summary = f"Risk factors identified: {', '.join(issues)}. Score: {risk_score:.1f}/100."
        else:
            risk_summary = f"No significant risk factors. Score: {risk_score:.1f}/100."
        
        # Determine escalation
        escalation_required = action_level.value >= ActionLevel.HOLD.value
        escalation_reason = None
        if escalation_required:
            if prohibited_found:
                escalation_reason = "Prohibited items detected - security escalation mandatory"
            elif requires_immediate:
                escalation_reason = "Critical anomaly requiring immediate supervisor attention"
            else:
                escalation_reason = "High risk score requires supervisory approval"
        
        # Get documentation requirements
        documentation = self._determine_documentation(
            action_level, mismatch_detected, concealment_detected, anomaly_detected
        )
        
        # Get follow-up actions
        follow_ups = self._determine_follow_up(action_level, requires_immediate)
        
        # Calculate confidence
        confidence = self._calculate_confidence(
            avg_detection_confidence, num_detections, num_images
        )
        
        decision = Decision(
            primary_action=primary_action,
            action_level=action_level,
            action_items=action_items,
            risk_summary=risk_summary,
            confidence_in_recommendation=confidence,
            escalation_required=escalation_required,
            escalation_reason=escalation_reason,
            documentation_required=documentation,
            follow_up_actions=follow_ups
        )
        
        logger.info(f"Decision generated: {action_level.name}")
        
        return decision


# Create singleton instance
_advisor_instance: Optional[DecisionAdvisor] = None


def get_decision_advisor() -> DecisionAdvisor:
    """Get or create the singleton decision advisor instance."""
    global _advisor_instance
    if _advisor_instance is None:
        _advisor_instance = DecisionAdvisor()
    return _advisor_instance