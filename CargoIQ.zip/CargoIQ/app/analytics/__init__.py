"""
CargoIQ Analytics Package

This package contains analytics modules for cargo analysis.
"""

from app.analytics.frequency import FrequencyAnalyzer

__all__ = ["FrequencyAnalyzer"]