"""
CargoIQ Frequency Analysis Module

This module provides frequency analysis for detected objects,
counting occurrences and identifying patterns across multiple images.
"""

from typing import Dict, List, Any, Tuple, Optional
from collections import Counter
from dataclasses import dataclass, field

from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class FrequencyStatistics:
    """Statistics from frequency analysis."""
    total_items: int
    unique_items: int
    most_common: List[Tuple[str, int]]
    least_common: List[Tuple[str, int]]
    average_frequency: float
    max_frequency: int
    min_frequency: int
    frequency_distribution: Dict[str, int]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_items": self.total_items,
            "unique_items": self.unique_items,
            "most_common": self.most_common,
            "least_common": self.least_common,
            "average_frequency": round(self.average_frequency, 2),
            "max_frequency": self.max_frequency,
            "min_frequency": self.min_frequency,
            "frequency_distribution": self.frequency_distribution
        }


@dataclass
class FrequencyAnalysis:
    """Complete frequency analysis result."""
    frequency: Dict[str, int]
    statistics: FrequencyStatistics
    high_frequency_items: List[str]  # Items appearing more than threshold
    single_occurrence_items: List[str]  # Items appearing only once
    confidence_weighted_frequency: Dict[str, float]
    category_frequency: Dict[str, int]  # Frequency by category
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "frequency": self.frequency,
            "statistics": self.statistics.to_dict(),
            "high_frequency_items": self.high_frequency_items,
            "single_occurrence_items": self.single_occurrence_items,
            "confidence_weighted_frequency": {
                k: round(v, 3) for k, v in self.confidence_weighted_frequency.items()
            },
            "category_frequency": self.category_frequency
        }


class FrequencyAnalyzer:
    """
    Frequency Analyzer for Object Detection Results
    
    This analyzer computes:
    - Item frequency counts
    - Frequency statistics
    - High/low frequency items
    - Confidence-weighted frequencies
    - Category-level frequencies
    """
    
    def __init__(self, high_frequency_threshold: int = 3):
        """
        Initialize the frequency analyzer.
        
        Args:
            high_frequency_threshold: Items appearing more than this are flagged
        """
        self.high_frequency_threshold = high_frequency_threshold
        
        # Category mappings for grouping
        self.category_map = {
            "laptop": "electronics",
            "phone": "electronics",
            "tablet": "electronics",
            "camera": "electronics",
            "battery": "electronics",
            "charger": "electronics",
            "clothing": "apparel",
            "shirt": "apparel",
            "pants": "apparel",
            "shoes": "apparel",
            "books": "documents",
            "documents": "documents",
            "food_items": "consumables",
            "cosmetics": "consumables",
            "medicine": "consumables",
            "jewelry": "valuables",
            "watch": "valuables",
            "currency": "valuables",
            "gold": "valuables",
            "knife": "restricted",
            "weapon": "prohibited",
        }
        
        logger.info("Frequency Analyzer initialized")
    
    def _compute_frequency(self, items: List[str]) -> Dict[str, int]:
        """Compute raw frequency counts."""
        return dict(Counter(items))
    
    def _compute_statistics(self, frequency: Dict[str, int]) -> FrequencyStatistics:
        """Compute frequency statistics."""
        if not frequency:
            return FrequencyStatistics(
                total_items=0,
                unique_items=0,
                most_common=[],
                least_common=[],
                average_frequency=0.0,
                max_frequency=0,
                min_frequency=0,
                frequency_distribution={}
            )
        
        counts = list(frequency.values())
        sorted_items = sorted(frequency.items(), key=lambda x: x[1], reverse=True)
        
        return FrequencyStatistics(
            total_items=sum(counts),
            unique_items=len(frequency),
            most_common=sorted_items[:5],
            least_common=sorted_items[-5:] if len(sorted_items) > 5 else sorted_items,
            average_frequency=sum(counts) / len(counts),
            max_frequency=max(counts),
            min_frequency=min(counts),
            frequency_distribution=frequency
        )
    
    def _compute_weighted_frequency(
        self,
        items: List[str],
        confidence_scores: Dict[str, float]
    ) -> Dict[str, float]:
        """Compute confidence-weighted frequency."""
        weighted = {}
        item_counts = Counter(items)
        
        for item, count in item_counts.items():
            confidence = confidence_scores.get(item, 1.0)
            weighted[item] = count * confidence
        
        return weighted
    
    def _compute_category_frequency(
        self,
        frequency: Dict[str, int]
    ) -> Dict[str, int]:
        """Compute frequency by category."""
        category_freq = Counter()
        
        for item, count in frequency.items():
            category = self.category_map.get(item.lower(), "other")
            category_freq[category] += count
        
        return dict(category_freq)
    
    def _identify_high_frequency(
        self,
        frequency: Dict[str, int]
    ) -> List[str]:
        """Identify items with high frequency."""
        return [
            item for item, count in frequency.items()
            if count > self.high_frequency_threshold
        ]
    
    def _identify_single_occurrence(
        self,
        frequency: Dict[str, int]
    ) -> List[str]:
        """Identify items appearing only once."""
        return [
            item for item, count in frequency.items()
            if count == 1
        ]
    
    def analyze(
        self,
        detected_items: List[str],
        confidence_scores: Optional[Dict[str, float]] = None
    ) -> FrequencyAnalysis:
        """
        Perform complete frequency analysis.
        
        Args:
            detected_items: List of detected object labels
            confidence_scores: Optional dict of item -> confidence
        
        Returns:
            FrequencyAnalysis with complete results
        """
        logger.info(f"Analyzing frequency for {len(detected_items)} items")
        
        # Compute raw frequency
        frequency = self._compute_frequency(detected_items)
        
        # Compute statistics
        statistics = self._compute_statistics(frequency)
        
        # Compute weighted frequency
        if confidence_scores is None:
            confidence_scores = {item: 1.0 for item in set(detected_items)}
        weighted_freq = self._compute_weighted_frequency(detected_items, confidence_scores)
        
        # Compute category frequency
        category_freq = self._compute_category_frequency(frequency)
        
        # Identify high/low frequency items
        high_freq_items = self._identify_high_frequency(frequency)
        single_items = self._identify_single_occurrence(frequency)
        
        analysis = FrequencyAnalysis(
            frequency=frequency,
            statistics=statistics,
            high_frequency_items=high_freq_items,
            single_occurrence_items=single_items,
            confidence_weighted_frequency=weighted_freq,
            category_frequency=category_freq
        )
        
        logger.info(
            f"Frequency analysis complete: "
            f"{statistics.unique_items} unique items, "
            f"{len(high_freq_items)} high-frequency items"
        )
        
        return analysis
    
    def analyze_per_image(
        self,
        detections_per_image: List[List[str]]
    ) -> Dict[str, Any]:
        """
        Analyze frequency patterns across multiple images.
        
        Args:
            detections_per_image: List of detection lists per image
        
        Returns:
            Dict with per-image and aggregate analysis
        """
        # Aggregate all detections
        all_items = []
        for detections in detections_per_image:
            all_items.extend(detections)
        
        # Overall analysis
        overall = self.analyze(all_items)
        
        # Per-image statistics
        per_image_stats = []
        for i, detections in enumerate(detections_per_image):
            img_analysis = self.analyze(detections)
            per_image_stats.append({
                "image_index": i,
                "total_items": len(detections),
                "unique_items": len(set(detections)),
                "items": list(set(detections))
            })
        
        return {
            "overall": overall.to_dict(),
            "per_image": per_image_stats,
            "total_images": len(detections_per_image)
        }


# Create singleton instance
_analyzer_instance: Optional[FrequencyAnalyzer] = None


def get_frequency_analyzer() -> FrequencyAnalyzer:
    """Get or create the singleton frequency analyzer instance."""
    global _analyzer_instance
    if _analyzer_instance is None:
        _analyzer_instance = FrequencyAnalyzer()
    return _analyzer_instance