"""
CargoIQ - AI-Powered Cargo Intelligence & Risk Analysis System

This package provides comprehensive cargo analysis capabilities including:
- Object detection in cargo/X-ray images
- Misdeclaration detection
- Concealment detection
- Anomaly detection
- Risk scoring and assessment
- Decision support for customs officers
"""

__version__ = "1.0.0"
__author__ = "CargoIQ Team"
__description__ = "AI-Powered Cargo Intelligence & Risk Analysis System"