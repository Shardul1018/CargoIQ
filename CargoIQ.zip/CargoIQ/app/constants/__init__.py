"""
CargoIQ Constants Package

This package contains constant definitions and mappings.
"""

from app.constants.rules import *
from app.constants.mappings import *