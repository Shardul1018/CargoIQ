"""
CargoIQ Rules Constants

This module contains constant definitions for business rules,
thresholds, and scoring parameters.
"""

# =============================================================================
# RISK THRESHOLDS
# =============================================================================

RISK_THRESHOLDS = {
    "minimal": 0,
    "low": 25,
    "medium": 50,
    "high": 75,
    "critical": 90
}

# =============================================================================
# BASE RISK SCORES
# =============================================================================

BASE_RISK_SCORES = {
    "mismatch": 40,
    "concealment": 30,
    "anomaly": 30
}

# =============================================================================
# CONTEXT MULTIPLIERS
# =============================================================================

CONTEXT_MULTIPLIERS = {
    "high_frequency": 1.2,
    "concealment": 1.3,
    "anomaly": 1.4,
    "multiple_issues": 1.5
}

# =============================================================================
# RESTRICTED ITEMS
# =============================================================================

RESTRICTED_ITEMS = [
    "weapon",
    "gun",
    "knife",
    "explosive",
    "drugs",
    "narcotics",
    "ammunition",
    "firearm",
    "grenade",
    "bomb",
    "contraband",
    "illegal_substance",
    "prohibited_chemical",
    "radioactive",
    "counterfeit",
    "ivory",
    "endangered_species",
    "unregistered_medication"
]

# =============================================================================
# CONCEALMENT RULES
# =============================================================================

CONCEALMENT_RULES = {
    "dense_material_threshold": 0.7,
    "layering_detection_min_items": 2,
    "suspicious_combination_score": 0.6
}

CONCEALMENT_PATTERNS = [
    "dense_material",
    "metal_sheet",
    "lead",
    "unusual_cavity",
    "false_bottom",
    "hidden_compartment",
    "wrapped_bundle",
    "layered_packaging",
    "shielded_container"
]

# =============================================================================
# ANOMALY RULES
# =============================================================================

ANOMALY_RULES = {
    "quantity_threshold": 10,
    "high_value_scrutiny": True,
    "restricted_auto_flag": True
}

# =============================================================================
# DECISION RULES
# =============================================================================

DECISION_RULES = {
    "release_max_score": 25,
    "review_max_score": 50,
    "inspect_max_score": 75,
    "hold_max_score": 90,
    "alert_min_score": 90
}

# =============================================================================
# CONFIDENCE THRESHOLDS
# =============================================================================

CONFIDENCE_THRESHOLDS = {
    "high": 0.85,
    "medium": 0.65,
    "low": 0.50,
    "minimum": 0.30
}

# =============================================================================
# FREQUENCY THRESHOLDS
# =============================================================================

FREQUENCY_THRESHOLDS = {
    "high": 5,
    "medium": 3,
    "low": 2
}