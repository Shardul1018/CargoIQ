"""
CargoIQ Mappings Constants

This module contains semantic mappings for cargo classification
and category hierarchies.
"""

# =============================================================================
# SEMANTIC MAPPINGS (Category -> Items)
# =============================================================================

SEMANTIC_MAPPINGS = {
    "electronics": [
        "laptop", "notebook", "computer", "pc", "macbook",
        "phone", "mobile", "cellphone", "smartphone", "iphone",
        "tablet", "ipad", "e-reader",
        "camera", "dslr", "camcorder", "gopro",
        "television", "tv", "monitor", "display",
        "speaker", "headphones", "earbuds", "airpods",
        "gaming_console", "playstation", "xbox", "nintendo",
        "drone", "robot", "smart_device",
        "battery", "batteries", "power_bank",
        "charger", "adapter", "cable", "usb",
        "hard_drive", "ssd", "memory_card", "usb_drive",
        "router", "modem", "networking_equipment",
        "printer", "scanner", "projector"
    ],
    
    "clothing": [
        "clothes", "apparel", "garments", "wear",
        "shirt", "t-shirt", "tshirt", "blouse", "top",
        "pants", "trousers", "jeans", "slacks", "shorts",
        "dress", "skirt", "gown",
        "jacket", "coat", "sweater", "hoodie", "cardigan",
        "suit", "blazer", "formal_wear",
        "underwear", "socks", "lingerie",
        "sportswear", "activewear", "athletic_wear",
        "uniform", "workwear"
    ],
    
    "footwear": [
        "shoes", "sneakers", "boots", "sandals",
        "heels", "flats", "loafers", "oxfords",
        "athletic_shoes", "running_shoes",
        "slippers", "flip_flops"
    ],
    
    "accessories": [
        "bag", "handbag", "purse", "wallet",
        "belt", "tie", "scarf", "hat", "cap",
        "sunglasses", "glasses", "eyewear",
        "umbrella", "gloves"
    ],
    
    "jewelry": [
        "jewelry", "jewellery", "ornaments",
        "necklace", "bracelet", "ring", "earring",
        "pendant", "brooch", "anklet",
        "gold", "silver", "diamond", "precious_stone",
        "watch", "watches", "luxury_watch"
    ],
    
    "documents": [
        "documents", "papers", "files", "paperwork",
        "books", "textbooks", "novels", "magazines",
        "newspapers", "publications", "journals",
        "certificates", "licenses", "contracts"
    ],
    
    "food": [
        "food", "food_items", "groceries", "edibles",
        "snacks", "beverages", "drinks",
        "canned_goods", "packaged_food",
        "fresh_produce", "fruits", "vegetables",
        "meat", "seafood", "dairy",
        "spices", "condiments", "sauces"
    ],
    
    "cosmetics": [
        "cosmetics", "makeup", "beauty_products",
        "skincare", "haircare", "perfume", "fragrance",
        "lotion", "cream", "soap", "shampoo",
        "nail_polish", "lipstick", "mascara"
    ],
    
    "medicine": [
        "medicine", "medication", "pharmaceuticals",
        "pills", "tablets", "capsules",
        "vitamins", "supplements",
        "first_aid", "medical_supplies",
        "prescription_drugs", "over_the_counter"
    ],
    
    "toys": [
        "toys", "games", "puzzles",
        "dolls", "action_figures", "stuffed_animals",
        "board_games", "card_games",
        "building_blocks", "lego"
    ],
    
    "sports_equipment": [
        "sports_equipment", "fitness_equipment",
        "balls", "rackets", "bats",
        "weights", "dumbbells", "exercise_equipment",
        "bicycle", "skateboard", "skates",
        "golf_clubs", "tennis_racket"
    ],
    
    "tools": [
        "tools", "hand_tools", "power_tools",
        "hammer", "screwdriver", "wrench", "pliers",
        "drill", "saw", "sander",
        "measuring_tools", "level"
    ],
    
    "household": [
        "household_items", "home_goods",
        "kitchenware", "cookware", "utensils",
        "furniture", "decor", "bedding",
        "cleaning_supplies", "storage_containers"
    ],
    
    "automotive": [
        "automotive_parts", "car_parts",
        "tires", "wheels", "brakes",
        "engine_parts", "filters", "batteries",
        "car_accessories", "car_electronics"
    ],
    
    "valuables": [
        "currency", "cash", "money", "banknotes",
        "gold_bars", "silver_bars", "precious_metals",
        "antiques", "artwork", "collectibles",
        "luxury_items", "designer_goods"
    ]
}

# =============================================================================
# CATEGORY HIERARCHY
# =============================================================================

CATEGORY_HIERARCHY = {
    "consumer_goods": ["electronics", "clothing", "footwear", "accessories"],
    "personal_items": ["jewelry", "cosmetics", "accessories"],
    "consumables": ["food", "medicine", "cosmetics"],
    "recreational": ["toys", "sports_equipment", "games"],
    "industrial": ["tools", "automotive", "machinery"],
    "home": ["household", "furniture", "decor"],
    "documents": ["documents", "books", "publications"],
    "high_value": ["jewelry", "valuables", "electronics"]
}

# =============================================================================
# ITEM SYNONYMS
# =============================================================================

ITEM_SYNONYMS = {
    "laptop": ["notebook", "computer", "pc", "macbook", "chromebook"],
    "phone": ["mobile", "cellphone", "smartphone", "iphone", "android"],
    "tablet": ["ipad", "pad", "e-reader", "kindle"],
    "camera": ["dslr", "camcorder", "gopro", "digital_camera"],
    "clothing": ["clothes", "apparel", "garments", "wear", "attire"],
    "shoes": ["footwear", "sneakers", "boots", "sandals"],
    "jewelry": ["jewellery", "ornaments", "accessories"],
    "watch": ["watches", "timepiece", "wristwatch"],
    "bag": ["handbag", "purse", "backpack", "luggage"],
    "documents": ["papers", "files", "paperwork", "records"],
    "books": ["textbooks", "novels", "publications", "literature"],
    "food": ["food_items", "groceries", "edibles", "provisions"],
    "medicine": ["medication", "pharmaceuticals", "drugs", "pills"],
    "currency": ["cash", "money", "banknotes", "bills"]
}

# =============================================================================
# HIGH RISK CATEGORIES
# =============================================================================

HIGH_RISK_CATEGORIES = [
    "valuables",
    "jewelry",
    "electronics",
    "medicine"
]

# =============================================================================
# PROHIBITED COMBINATIONS
# =============================================================================

PROHIBITED_COMBINATIONS = [
    ("weapon", "any"),
    ("explosive", "any"),
    ("drugs", "any"),
    ("radioactive", "any")
]