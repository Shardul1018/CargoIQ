"""
CargoIQ Explanation Generator Module

This module generates human-readable explanations for cargo analysis results,
providing clear reasoning for risk scores and recommendations.
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime

from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class Explanation:
    """Complete explanation for analysis results."""
    summary: str
    detection_explanation: str
    mismatch_explanation: str
    concealment_explanation: str
    anomaly_explanation: str
    risk_explanation: str
    recommendation_explanation: str
    full_report: str
    timestamp: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "summary": self.summary,
            "detection_explanation": self.detection_explanation,
            "mismatch_explanation": self.mismatch_explanation,
            "concealment_explanation": self.concealment_explanation,
            "anomaly_explanation": self.anomaly_explanation,
            "risk_explanation": self.risk_explanation,
            "recommendation_explanation": self.recommendation_explanation,
            "full_report": self.full_report,
            "timestamp": self.timestamp
        }


class ExplanationGenerator:
    """
    Explanation Generator for Cargo Analysis
    
    This generator creates human-readable explanations that:
    - Summarize analysis findings
    - Explain each risk factor
    - Justify the risk score
    - Clarify recommendations
    - Provide actionable insights
    """
    
    def __init__(self):
        """Initialize the explanation generator."""
        logger.info("Explanation Generator initialized")
    
    def _generate_summary(
        self,
        total_images: int,
        total_detections: int,
        risk_level: str,
        risk_score: float
    ) -> str:
        """Generate executive summary."""
        summary_templates = {
            "minimal": "Analysis complete. Cargo appears compliant with minimal risk.",
            "low": "Analysis complete. Low-level concerns identified, standard processing applicable.",
            "medium": "Analysis complete. Moderate risk factors detected requiring review.",
            "high": "ATTENTION: Significant risk factors detected. Detailed inspection required.",
            "critical": "ALERT: Critical risk identified. Immediate action required."
        }
        
        base = summary_templates.get(risk_level, "Analysis complete.")
        
        return (
            f"{base} Analyzed {total_images} images with {total_detections} "
            f"total detections. Overall risk score: {risk_score:.1f}/100 ({risk_level.upper()})."
        )
    
    def _generate_detection_explanation(
        self,
        detected_objects: List[str],
        frequency: Dict[str, int],
        avg_confidence: float
    ) -> str:
        """Generate explanation of detections."""
        if not detected_objects:
            return "No objects were detected in the cargo images."
        
        unique_count = len(set(detected_objects))
        total_count = len(detected_objects)
        
        # Top 3 most frequent items
        sorted_freq = sorted(frequency.items(), key=lambda x: x[1], reverse=True)
        top_items = sorted_freq[:3]
        top_str = ", ".join([f"{item} ({count}x)" for item, count in top_items])
        
        return (
            f"Detected {total_count} objects across {unique_count} unique categories. "
            f"Most frequent items: {top_str}. "
            f"Average detection confidence: {avg_confidence:.1%}."
        )
    
    def _generate_mismatch_explanation(
        self,
        mismatch_detected: bool,
        mismatch_details: Dict[str, Any]
    ) -> str:
        """Generate explanation for mismatch analysis."""
        if not mismatch_detected:
            return (
                "Declaration Verification: PASSED. All detected items match or are "
                "semantically related to declared cargo categories. No misdeclaration suspected."
            )

        unmatched = mismatch_details.get("unmatched_items", [])
        severity = mismatch_details.get("severity", "unknown")
        matched_count = mismatch_details.get("total_matched", 0)
        total = mismatch_details.get("total_detected", 0)

        unmatched_str = ", ".join(unmatched[:5])
        if len(unmatched) > 5:
            unmatched_str += f" and {len(unmatched) - 5} more"

        explanation = (
            f"Declaration Verification: FAILED. Detected {len(unmatched)} undeclared items "
            f"out of {total} total detections ({matched_count} matched). "
            f"Undeclared items include: {unmatched_str}. "
            f"Severity level: {severity.upper()}. "
        )

        if severity in ["high", "critical"]:
            explanation += "This significant mismatch requires immediate attention."
        elif severity == "medium":
            explanation += "Manual verification of cargo manifest recommended."
        else:
            explanation += "Minor discrepancy - may be due to categorization differences."

        return explanation
    
    def _generate_concealment_explanation(
        self,
        concealment_detected: bool,
        concealment_details: Dict[str, Any]
    ) -> str:
        """Generate explanation for concealment analysis."""
        if not concealment_detected:
            return (
                "Concealment Analysis: CLEAR. No suspicious patterns or concealment "
                "indicators detected in cargo arrangement."
            )

        indicators = concealment_details.get("indicators", [])
        risk_items = concealment_details.get("risk_items", [])
        severity = concealment_details.get("severity", "unknown")
        score = concealment_details.get("concealment_score", 0)

        indicator_types = list(set(
            i.get("indicator_type", "unknown") for i in indicators
        ))

        explanation = (
            f"Concealment Analysis: SUSPICIOUS PATTERNS DETECTED. "
            f"Concealment score: {score:.1%}. "
            f"Detected {len(indicators)} concealment indicators of types: "
            f"{', '.join(indicator_types) if indicator_types else 'unknown'}. "
        )

        if risk_items:
            explanation += f"High-risk items identified: {', '.join(risk_items[:3])}. "

        if severity in ["high", "critical"]:
            explanation += "Physical inspection strongly recommended to verify cargo contents."
        else:
            explanation += "Additional X-ray angles or manual spot-check advised."

        return explanation
    
    def _generate_anomaly_explanation(
        self,
        anomaly_detected: bool,
        anomaly_details: Dict[str, Any]
    ) -> str:
        """Generate explanation for anomaly analysis."""
        if not anomaly_detected:
            return (
                "Anomaly Screening: PASSED. No restricted, prohibited, or suspicious "
                "items detected in cargo."
            )

        prohibited = anomaly_details.get("prohibited_items_found", [])
        restricted = anomaly_details.get("restricted_items_found", [])
        suspicious = anomaly_details.get("suspicious_items_found", [])
        requires_immediate = anomaly_details.get("requires_immediate_action", False)

        parts = ["Anomaly Screening: ITEMS FLAGGED."]

        if prohibited:
            parts.append(
                f"PROHIBITED ITEMS DETECTED: {', '.join(prohibited)}. "
                "These items are not permitted in cargo under any circumstances."
            )

        if restricted:
            parts.append(
                f"RESTRICTED ITEMS DETECTED: {', '.join(restricted)}. "
                "Valid permits and documentation required for these items."
            )

        if suspicious:
            parts.append(
                f"SUSPICIOUS ITEMS FLAGGED: {', '.join(suspicious)}. "
                "Additional scrutiny recommended."
            )

        if requires_immediate:
            parts.append(
                "IMMEDIATE ACTION REQUIRED: Do not release cargo. "
                "Contact security and supervisory personnel."
            )

        return " ".join(parts)
    
    def _generate_risk_explanation(
        self,
        risk_score: float,
        risk_level: str,
        risk_breakdown: Dict[str, float],
        context_factors: List[str]
    ) -> str:
        """Generate explanation for risk score."""
        contributions = []
        if risk_breakdown.get("mismatch_contribution", 0) > 0:
            contributions.append(
                f"mismatch ({risk_breakdown['mismatch_contribution']:.0f}pts)"
            )
        if risk_breakdown.get("concealment_contribution", 0) > 0:
            contributions.append(
                f"concealment ({risk_breakdown['concealment_contribution']:.0f}pts)"
            )
        if risk_breakdown.get("anomaly_contribution", 0) > 0:
            contributions.append(
                f"anomaly ({risk_breakdown['anomaly_contribution']:.0f}pts)"
            )

        contribution_str = ", ".join(contributions) if contributions else "none"

        explanation = (
            f"Risk Assessment: Score {risk_score:.1f}/100 ({risk_level.upper()}). "
            f"Contributing factors: {contribution_str}. "
        )

        multiplier = risk_breakdown.get("context_multiplier", 1.0)
        if multiplier > 1.0:
            explanation += (
                f"Context multiplier of {multiplier:.2f}x applied due to: "
                f"{', '.join(context_factors)}. "
            )

        level_guidance = {
            "minimal": "Standard processing appropriate.",
            "low": "Proceed with normal procedures, document findings.",
            "medium": "Supervisor review recommended before release.",
            "high": "Detailed inspection required. Hold for physical examination.",
            "critical": "DO NOT RELEASE. Escalate to security immediately."
        }

        explanation += level_guidance.get(risk_level, "")

        return explanation
    
    def _generate_recommendation_explanation(
        self,
        recommendation: str,
        risk_level: str,
        key_findings: List[str]
    ) -> str:
        """Generate explanation for recommendations."""
        explanation = f"Recommended Action: {recommendation}. "

        if key_findings:
            explanation += f"This recommendation is based on: {'; '.join(key_findings[:3])}. "

        procedural_notes = {
            "RELEASE": "No further action required. Cargo may proceed.",
            "REVIEW": "Officer should verify documentation matches detected contents.",
            "INSPECT": "Physical inspection required. Document all findings.",
            "HOLD": "Cargo must not be released until cleared by supervisor.",
            "ALERT": "Immediate escalation required. Contact security and document thoroughly."
        }

        for key, note in procedural_notes.items():
            if key in recommendation.upper():
                explanation += note
                break

        return explanation
    
    def _generate_full_report(
        self,
        summary: str,
        detection_exp: str,
        mismatch_exp: str,
        concealment_exp: str,
        anomaly_exp: str,
        risk_exp: str,
        recommendation_exp: str,
        shipment_id: str
    ) -> str:
        """Generate complete formatted report."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        report = f"""
================================================================================
                    CARGOIQ ANALYSIS REPORT
================================================================================
Shipment ID : {shipment_id}
Generated   : {timestamp}
--------------------------------------------------------------------------------

EXECUTIVE SUMMARY
{summary}

--------------------------------------------------------------------------------
DETECTION ANALYSIS
{detection_exp}

--------------------------------------------------------------------------------
DECLARATION VERIFICATION
{mismatch_exp}

--------------------------------------------------------------------------------
CONCEALMENT ANALYSIS
{concealment_exp}

--------------------------------------------------------------------------------
ANOMALY SCREENING
{anomaly_exp}

--------------------------------------------------------------------------------
RISK ASSESSMENT
{risk_exp}

--------------------------------------------------------------------------------
RECOMMENDATION
{recommendation_exp}

================================================================================
                         END OF REPORT
================================================================================
"""
        return report.strip()

    def generate(
        self,
        shipment_id: str = "UNKNOWN",
        total_images: int = 0,
        total_detections: int = 0,
        detected_objects: List[str] = None,
        frequency: Dict[str, int] = None,
        avg_confidence: float = 0.0,
        mismatch_detected: bool = False,
        mismatch_details: Dict[str, Any] = None,
        concealment_detected: bool = False,
        concealment_details: Dict[str, Any] = None,
        anomaly_detected: bool = False,
        anomaly_details: Dict[str, Any] = None,
        risk_score: float = 0.0,
        risk_level: str = "minimal",
        risk_breakdown: Dict[str, float] = None,
        context_factors: List[str] = None,
        recommendation: str = "",
        **kwargs
    ) -> Explanation:
        """
        Generate complete explanation for analysis results.
        Fully backwards compatible - accepts all parameter naming conventions.
        """

        # ── safe defaults ──────────────────────────────────────────────────
        detected_objects    = detected_objects  or []
        frequency           = frequency         or {}
        mismatch_details    = mismatch_details  or {}
        concealment_details = concealment_details or {}
        anomaly_details     = anomaly_details   or {}
        risk_breakdown      = risk_breakdown    or {}
        context_factors     = context_factors   or []
        # ───────────────────────────────────────────────────────────────────

        logger.info(f"Generating explanation for shipment {shipment_id}")

        # Generate all component explanations
        summary = self._generate_summary(
            total_images, total_detections, risk_level, risk_score
        )

        detection_exp = self._generate_detection_explanation(
            detected_objects, frequency, avg_confidence
        )

        mismatch_exp = self._generate_mismatch_explanation(
            mismatch_detected, mismatch_details
        )

        concealment_exp = self._generate_concealment_explanation(
            concealment_detected, concealment_details
        )

        anomaly_exp = self._generate_anomaly_explanation(
            anomaly_detected, anomaly_details
        )

        risk_exp = self._generate_risk_explanation(
            risk_score, risk_level, risk_breakdown, context_factors
        )

        # Gather key findings
        key_findings = []
        if mismatch_detected:
            key_findings.append("cargo mismatch detected")
        if concealment_detected:
            key_findings.append("concealment patterns identified")
        if anomaly_detected:
            key_findings.append("anomalous items found")

        recommendation_exp = self._generate_recommendation_explanation(
            recommendation, risk_level, key_findings
        )

        full_report = self._generate_full_report(
            summary, detection_exp, mismatch_exp, concealment_exp,
            anomaly_exp, risk_exp, recommendation_exp, shipment_id
        )

        explanation = Explanation(
            summary=summary,
            detection_explanation=detection_exp,
            mismatch_explanation=mismatch_exp,
            concealment_explanation=concealment_exp,
            anomaly_explanation=anomaly_exp,
            risk_explanation=risk_exp,
            recommendation_explanation=recommendation_exp,
            full_report=full_report,
            timestamp=datetime.now().isoformat()
        )

        logger.info("Explanation generation complete")

        return explanation


# ── singleton ──────────────────────────────────────────────────────────────────
_generator_instance: Optional[ExplanationGenerator] = None


def get_explanation_generator() -> ExplanationGenerator:
    """Get or create the singleton explanation generator instance."""
    global _generator_instance
    if _generator_instance is None:
        _generator_instance = ExplanationGenerator()
    return _generator_instance