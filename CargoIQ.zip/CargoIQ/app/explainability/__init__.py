"""
CargoIQ Explainability Package

This package provides explanation generation for analysis results.
"""

from app.explainability.generator import ExplanationGenerator

__all__ = ["ExplanationGenerator"]