"""
CargoIQ Schemas Package

This package contains data schemas for requests and responses.
"""

from app.schemas.request_schema import CargoAnalysisRequest, CargoAnalysisResponse

__all__ = ["CargoAnalysisRequest", "CargoAnalysisResponse"]