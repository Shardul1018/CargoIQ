"""
CargoIQ Request and Response Schemas

This module defines the data structures for API requests and responses.
"""

from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class CargoAnalysisRequest:
    """Request schema for cargo analysis."""
    
    # Image inputs (one of these should be provided)
    image_paths: List[str] = field(default_factory=list)
    image_bytes: List[bytes] = field(default_factory=list)
    
    # Declared cargo information
    declared_cargo: List[str] = field(default_factory=list)
    
    # Shipment metadata
    shipment_id: str = "UNKNOWN"
    origin_country: Optional[str] = None
    destination_country: Optional[str] = None
    
    # Optional additional information
    shipper_name: Optional[str] = None
    consignee_name: Optional[str] = None
    declared_value: Optional[float] = None
    weight_kg: Optional[float] = None
    
    # Analysis options
    skip_cache: bool = False
    detailed_output: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "image_paths": self.image_paths,
            "image_bytes_count": len(self.image_bytes),
            "declared_cargo": self.declared_cargo,
            "shipment_id": self.shipment_id,
            "origin_country": self.origin_country,
            "destination_country": self.destination_country,
            "shipper_name": self.shipper_name,
            "consignee_name": self.consignee_name,
            "declared_value": self.declared_value,
            "weight_kg": self.weight_kg,
            "skip_cache": self.skip_cache,
            "detailed_output": self.detailed_output
        }


@dataclass
class CargoAnalysisResponse:
    """Response schema for cargo analysis."""
    
    # Identification
    shipment_id: str
    
    # Processing summary
    images_processed: int
    total_detections: int
    processing_time: float = 0.0
    
    # Detection results
    detected_objects: List[str] = field(default_factory=list)
    object_frequency: Dict[str, int] = field(default_factory=dict)
    avg_confidence: float = 0.0
    
    # Mismatch analysis
    mismatch_detected: bool = False
    mismatch_details: Dict[str, Any] = field(default_factory=dict)
    
    # Concealment analysis
    concealment_detected: bool = False
    concealment_details: Dict[str, Any] = field(default_factory=dict)
    
    # Anomaly analysis
    anomaly_detected: bool = False
    anomaly_details: Dict[str, Any] = field(default_factory=dict)
    
    # Risk assessment
    risk_score: float = 0.0
    risk_level: str = "minimal"
    risk_breakdown: Dict[str, float] = field(default_factory=dict)
    
    # Explanation and recommendation
    explanation: str = ""
    full_explanation: Dict[str, Any] = field(default_factory=dict)
    recommendation: str = ""
    decision_details: Dict[str, Any] = field(default_factory=dict)
    
    # Metadata
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "shipment_id": self.shipment_id,
            "images_processed": self.images_processed,
            "total_detections": self.total_detections,
            "processing_time": round(self.processing_time, 3),
            "detected_objects": self.detected_objects,
            "object_frequency": self.object_frequency,
            "avg_confidence": round(self.avg_confidence, 4),
            "mismatch_detected": self.mismatch_detected,
            "mismatch_details": self.mismatch_details,
            "concealment_detected": self.concealment_detected,
            "concealment_details": self.concealment_details,
            "anomaly_detected": self.anomaly_detected,
            "anomaly_details": self.anomaly_details,
            "risk_score": round(self.risk_score, 1),
            "risk_level": self.risk_level,
            "risk_breakdown": self.risk_breakdown,
            "explanation": self.explanation,
            "full_explanation": self.full_explanation,
            "recommendation": self.recommendation,
            "decision_details": self.decision_details,
            "timestamp": self.timestamp
        }
    
    def summary(self) -> str:
        """Generate a brief summary of the analysis."""
        return (
            f"Shipment {self.shipment_id}: "
            f"{self.images_processed} images, "
            f"{self.total_detections} detections, "
            f"Risk: {self.risk_score:.1f}/100 ({self.risk_level})"
        )