"""
CargoIQ Risk Scorer Module

This module calculates the final risk score using base scores,
confidence levels, and context multipliers.
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

from app.config import risk_config
from app.risk_engine.context import ContextAnalyzer, ContextAnalysis, get_context_analyzer
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class RiskComponent:
    """Individual risk component."""
    name: str
    base_score: float
    confidence: float
    weighted_score: float
    description: str
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "base_score": self.base_score,
            "confidence": round(self.confidence, 3),
            "weighted_score": round(self.weighted_score, 2),
            "description": self.description
        }


@dataclass
class RiskAssessment:
    """Complete risk assessment result."""
    raw_score: float  # Before normalization
    normalized_score: float  # 0-100 scale
    risk_level: str  # "minimal", "low", "medium", "high", "critical"
    components: List[RiskComponent]
    context_multiplier: float
    context_factors: List[str]
    breakdown: Dict[str, float]
    explanation: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "raw_score": round(self.raw_score, 2),
            "normalized_score": round(self.normalized_score, 1),
            "risk_level": self.risk_level,
            "components": [c.to_dict() for c in self.components],
            "context_multiplier": round(self.context_multiplier, 3),
            "context_factors": self.context_factors,
            "breakdown": {k: round(v, 2) for k, v in self.breakdown.items()},
            "explanation": self.explanation
        }


class RiskScorer:
    """
    Risk Scorer for Cargo Analysis
    
    This scorer calculates the final risk score using:
    - Base risk scores for different issues
    - Confidence-weighted scoring
    - Context multipliers
    - Normalization to 0-100 scale
    
    Formula: risk = base_risk × confidence × context_multiplier
    """
    
    def __init__(self):
        """Initialize the risk scorer."""
        self.base_scores = risk_config.base_scores
        self.thresholds = risk_config.thresholds
        self.min_risk = risk_config.min_risk
        self.max_risk = risk_config.max_risk
        
        self.context_analyzer = get_context_analyzer()
        
        logger.info("Risk Scorer initialized")
    
    def _calculate_component_score(
        self,
        name: str,
        detected: bool,
        confidence: float,
        severity_score: float
    ) -> RiskComponent:
        """Calculate score for a single risk component."""
        if not detected:
            return RiskComponent(
                name=name,
                base_score=0,
                confidence=0,
                weighted_score=0,
                description=f"No {name} detected"
            )
        
        base = self.base_scores.get(name, 0)
        # Weight by both confidence and severity
        weighted = base * confidence * (0.5 + 0.5 * severity_score)
        
        return RiskComponent(
            name=name,
            base_score=base,
            confidence=confidence,
            weighted_score=weighted,
            description=f"{name.title()} detected with {confidence:.0%} confidence"
        )
    
    def _normalize_score(self, raw_score: float) -> float:
        """Normalize score to 0-100 range."""
        # Clamp to valid range
        normalized = max(self.min_risk, min(self.max_risk, raw_score))
        return normalized
    
    def _determine_risk_level(self, score: float) -> str:
        """Determine risk level from score."""
        if score >= self.thresholds["critical"]:
            return "critical"
        elif score >= self.thresholds["high"]:
            return "high"
        elif score >= self.thresholds["medium"]:
            return "medium"
        elif score >= self.thresholds["low"]:
            return "low"
        else:
            return "minimal"
    
    def _generate_explanation(
        self,
        assessment: 'RiskAssessment'
    ) -> str:
        """Generate explanation of risk assessment."""
        parts = []
        
        # Overall assessment
        level_descriptions = {
            "minimal": "Cargo appears compliant with minimal risk indicators.",
            "low": "Low risk detected. Standard processing recommended.",
            "medium": "Moderate risk detected. Additional review advised.",
            "high": "High risk detected. Detailed inspection required.",
            "critical": "CRITICAL RISK. Immediate action required. Hold cargo."
        }
        parts.append(level_descriptions.get(assessment.risk_level, ""))
        
        # Score breakdown
        active_components = [c for c in assessment.components if c.weighted_score > 0]
        if active_components:
            component_strs = [
                f"{c.name} ({c.weighted_score:.0f}pts)" 
                for c in active_components
            ]
            parts.append(f"Risk factors: {', '.join(component_strs)}.")
        
        # Context factors
        if assessment.context_factors:
            parts.append(
                f"Context multiplier {assessment.context_multiplier:.2f}x applied "
                f"due to: {', '.join(assessment.context_factors)}."
            )
        
        return " ".join(parts)
    
    def calculate(
        self,
        mismatch_detected: bool = False,
        mismatch_confidence: float = 0.0,
        mismatch_severity: float = 0.0,
        concealment_detected: bool = False,
        concealment_confidence: float = 0.0,
        concealment_severity: float = 0.0,
        anomaly_detected: bool = False,
        anomaly_confidence: float = 0.0,
        anomaly_severity: float = 0.0,
        requires_immediate: bool = False,
        frequency: Optional[Dict[str, int]] = None,
        avg_detection_confidence: float = 0.8,
        origin_country: Optional[str] = None
    ) -> RiskAssessment:
        """
        Calculate complete risk assessment.
        
        Args:
            mismatch_detected: Whether mismatch was detected
            mismatch_confidence: Confidence in mismatch detection
            mismatch_severity: Severity of mismatch (0-1)
            concealment_detected: Whether concealment was detected
            concealment_confidence: Confidence in concealment detection
            concealment_severity: Severity of concealment (0-1)
            anomaly_detected: Whether anomaly was detected
            anomaly_confidence: Confidence in anomaly detection
            anomaly_severity: Severity of anomaly (0-1)
            requires_immediate: Whether immediate action required
            frequency: Object frequency dict
            avg_detection_confidence: Average confidence of all detections
            origin_country: Shipment origin
        
        Returns:
            RiskAssessment with complete scoring information
        """
        logger.info("Calculating risk score")
        
        # Calculate individual components
        components = [
            self._calculate_component_score(
                "mismatch", mismatch_detected, mismatch_confidence, mismatch_severity
            ),
            self._calculate_component_score(
                "concealment", concealment_detected, concealment_confidence, concealment_severity
            ),
            self._calculate_component_score(
                "anomaly", anomaly_detected, anomaly_confidence, anomaly_severity
            )
        ]
        
        # Sum base scores
        base_score = sum(c.weighted_score for c in components)
        
        # Get context analysis
        context = self.context_analyzer.analyze(
            mismatch_detected=mismatch_detected,
            mismatch_score=mismatch_severity,
            concealment_detected=concealment_detected,
            concealment_score=concealment_severity,
            anomaly_detected=anomaly_detected,
            anomaly_score=anomaly_severity,
            requires_immediate=requires_immediate,
            frequency=frequency,
            origin_country=origin_country
        )
        
        # Apply context multiplier
        raw_score = base_score * context.final_multiplier
        
        # Add bonus for immediate action requirement
        if requires_immediate:
            raw_score += 20
        
        # Normalize to 0-100
        normalized_score = self._normalize_score(raw_score)
        
        # Determine risk level
        risk_level = self._determine_risk_level(normalized_score)
        
        # Create breakdown
        breakdown = {
            "mismatch_contribution": components[0].weighted_score,
            "concealment_contribution": components[1].weighted_score,
            "anomaly_contribution": components[2].weighted_score,
            "context_multiplier": context.final_multiplier,
            "immediate_action_bonus": 20 if requires_immediate else 0
        }
        
        # Create assessment
        assessment = RiskAssessment(
            raw_score=raw_score,
            normalized_score=normalized_score,
            risk_level=risk_level,
            components=components,
            context_multiplier=context.final_multiplier,
            context_factors=context.active_factors,
            breakdown=breakdown,
            explanation=""
        )
        
        assessment.explanation = self._generate_explanation(assessment)
        
        logger.info(
            f"Risk calculation complete: "
            f"score={normalized_score:.1f}, level={risk_level}"
        )
        
        return assessment


# Create singleton instance
_scorer_instance: Optional[RiskScorer] = None


def get_risk_scorer() -> RiskScorer:
    """Get or create the singleton risk scorer instance."""
    global _scorer_instance
    if _scorer_instance is None:
        _scorer_instance = RiskScorer()
    return _scorer_instance