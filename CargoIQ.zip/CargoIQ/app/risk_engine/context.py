"""
CargoIQ Context Analyzer Module

This module analyzes contextual factors that influence risk scoring,
calculating context multipliers based on various conditions.
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

from app.config import risk_config
from app.utils.logger import get_logger


# Initialize logger
logger = get_logger(__name__)


@dataclass
class ContextFactor:
    """Represents a single context factor."""
    name: str
    present: bool
    multiplier: float
    description: str
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "present": self.present,
            "multiplier": self.multiplier,
            "description": self.description
        }


@dataclass
class ContextAnalysis:
    """Complete context analysis result."""
    factors: List[ContextFactor]
    final_multiplier: float
    active_factors: List[str]
    explanation: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "factors": [f.to_dict() for f in self.factors],
            "final_multiplier": round(self.final_multiplier, 3),
            "active_factors": self.active_factors,
            "explanation": self.explanation
        }


class ContextAnalyzer:
    """
    Context Analyzer for Risk Assessment
    
    This analyzer evaluates contextual factors that modify
    the base risk score, including:
    - High frequency detections
    - Concealment indicators
    - Anomaly presence
    - Multiple simultaneous issues
    - Origin/destination risk
    - Shipment history
    """
    
    def __init__(self):
        """Initialize the context analyzer."""
        self.multipliers = risk_config.context_multipliers
        
        logger.info("Context Analyzer initialized")
    
    def _check_high_frequency(
        self,
        frequency: Dict[str, int],
        threshold: int = 5
    ) -> ContextFactor:
        """Check for high frequency items."""
        max_freq = max(frequency.values()) if frequency else 0
        is_high = max_freq > threshold
        
        return ContextFactor(
            name="high_frequency",
            present=is_high,
            multiplier=self.multipliers["high_frequency"] if is_high else 1.0,
            description=f"Max item frequency: {max_freq} (threshold: {threshold})"
        )
    
    def _check_concealment(
        self,
        concealment_detected: bool,
        concealment_score: float
    ) -> ContextFactor:
        """Check for concealment indicators."""
        # Scale multiplier by concealment score
        if concealment_detected:
            mult = 1.0 + (self.multipliers["concealment"] - 1.0) * concealment_score
        else:
            mult = 1.0
        
        return ContextFactor(
            name="concealment",
            present=concealment_detected,
            multiplier=mult,
            description=f"Concealment score: {concealment_score:.2f}"
        )
    
    def _check_anomaly(
        self,
        anomaly_detected: bool,
        anomaly_score: float,
        requires_immediate: bool
    ) -> ContextFactor:
        """Check for anomaly indicators."""
        if anomaly_detected:
            base_mult = self.multipliers["anomaly"]
            if requires_immediate:
                mult = base_mult * 1.5  # Extra multiplier for critical anomalies
            else:
                mult = 1.0 + (base_mult - 1.0) * anomaly_score
        else:
            mult = 1.0
        
        return ContextFactor(
            name="anomaly",
            present=anomaly_detected,
            multiplier=mult,
            description=f"Anomaly score: {anomaly_score:.2f}, immediate action: {requires_immediate}"
        )
    
    def _check_multiple_issues(
        self,
        mismatch: bool,
        concealment: bool,
        anomaly: bool
    ) -> ContextFactor:
        """Check for multiple simultaneous issues."""
        issue_count = sum([mismatch, concealment, anomaly])
        is_multiple = issue_count >= 2
        
        return ContextFactor(
            name="multiple_issues",
            present=is_multiple,
            multiplier=self.multipliers["multiple_issues"] if is_multiple else 1.0,
            description=f"Issues detected: {issue_count}/3"
        )
    
    def _check_origin_risk(
        self,
        origin_country: Optional[str],
        high_risk_origins: Optional[List[str]] = None
    ) -> ContextFactor:
        """Check for high-risk origin countries."""
        if high_risk_origins is None:
            high_risk_origins = []  # Would be configured based on policy
        
        is_high_risk = origin_country in high_risk_origins if origin_country else False
        
        return ContextFactor(
            name="high_risk_origin",
            present=is_high_risk,
            multiplier=1.3 if is_high_risk else 1.0,
            description=f"Origin: {origin_country or 'Unknown'}"
        )
    
    def _calculate_final_multiplier(
        self,
        factors: List[ContextFactor]
    ) -> float:
        """Calculate the final combined multiplier."""
        # Multiplicative combination of all active multipliers
        final = 1.0
        for factor in factors:
            if factor.present:
                final *= factor.multiplier
        
        # Cap at reasonable maximum
        return min(final, 3.0)
    
    def _generate_explanation(
        self,
        factors: List[ContextFactor],
        final_multiplier: float
    ) -> str:
        """Generate explanation of context analysis."""
        active = [f.name for f in factors if f.present]
        
        if not active:
            return "No contextual risk factors identified. Standard risk assessment applies."
        
        parts = [f"Context factors active: {', '.join(active)}."]
        parts.append(f"Combined multiplier: {final_multiplier:.2f}x.")
        
        if final_multiplier >= 2.0:
            parts.append("HIGH contextual risk - elevated scrutiny required.")
        elif final_multiplier >= 1.5:
            parts.append("MODERATE contextual risk - additional review recommended.")
        
        return " ".join(parts)
    
    def analyze(
        self,
        mismatch_detected: bool = False,
        mismatch_score: float = 0.0,
        concealment_detected: bool = False,
        concealment_score: float = 0.0,
        anomaly_detected: bool = False,
        anomaly_score: float = 0.0,
        requires_immediate: bool = False,
        frequency: Optional[Dict[str, int]] = None,
        origin_country: Optional[str] = None,
        destination_country: Optional[str] = None
    ) -> ContextAnalysis:
        """
        Perform complete context analysis.
        
        Args:
            mismatch_detected: Whether mismatch was detected
            mismatch_score: Mismatch severity score
            concealment_detected: Whether concealment was detected
            concealment_score: Concealment severity score
            anomaly_detected: Whether anomaly was detected
            anomaly_score: Anomaly severity score
            requires_immediate: Whether immediate action required
            frequency: Object frequency dict
            origin_country: Shipment origin
            destination_country: Shipment destination
        
        Returns:
            ContextAnalysis with multiplier information
        """
        logger.info("Performing context analysis")
        
        if frequency is None:
            frequency = {}
        
        # Evaluate all context factors
        factors = [
            self._check_high_frequency(frequency),
            self._check_concealment(concealment_detected, concealment_score),
            self._check_anomaly(anomaly_detected, anomaly_score, requires_immediate),
            self._check_multiple_issues(mismatch_detected, concealment_detected, anomaly_detected),
            self._check_origin_risk(origin_country),
        ]
        
        # Calculate final multiplier
        final_multiplier = self._calculate_final_multiplier(factors)
        
        # Get active factors
        active_factors = [f.name for f in factors if f.present]
        
        # Generate explanation
        explanation = self._generate_explanation(factors, final_multiplier)
        
        analysis = ContextAnalysis(
            factors=factors,
            final_multiplier=final_multiplier,
            active_factors=active_factors,
            explanation=explanation
        )
        
        logger.info(
            f"Context analysis complete: "
            f"multiplier={final_multiplier:.2f}, "
            f"active_factors={len(active_factors)}"
        )
        
        return analysis


# Create singleton instance
_analyzer_instance: Optional[ContextAnalyzer] = None


def get_context_analyzer() -> ContextAnalyzer:
    """Get or create the singleton context analyzer instance."""
    global _analyzer_instance
    if _analyzer_instance is None:
        _analyzer_instance = ContextAnalyzer()
    return _analyzer_instance