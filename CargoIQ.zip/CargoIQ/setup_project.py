"""
CargoIQ - Project Setup Script
Creates all necessary directories and placeholder files
"""

import os
import shutil
from pathlib import Path


def create_directory_structure():
    """Create the complete directory structure for CargoIQ project."""
    
    # Define all directories to create
    directories = [
        "app",
        "app/models",
        "app/intelligence",
        "app/analytics",
        "app/risk_engine",
        "app/explainability",
        "app/decision",
        "app/services",
        "app/schemas",
        "app/constants",
        "app/utils",
        "app/ui",
        "data",
        "data/input_images",
        "data/outputs",
        "data/logs",
        "modelweights",
    ]
    
    # Create each directory
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✅ Created directory: {directory}")
    
    # Create __init__.py files for all Python packages
    init_directories = [
        "app",
        "app/models",
        "app/intelligence",
        "app/analytics",
        "app/risk_engine",
        "app/explainability",
        "app/decision",
        "app/services",
        "app/schemas",
        "app/constants",
        "app/utils",
        "app/ui",
    ]
    
    for directory in init_directories:
        init_file = Path(directory) / "__init__.py"
        if not init_file.exists():
            init_file.touch()
            print(f"✅ Created: {init_file}")
    
    # Create placeholder for logs
    log_file = Path("data/logs/app.log")
    log_file.parent.mkdir(parents=True, exist_ok=True)
    if not log_file.exists():
        log_file.touch()
        print(f"✅ Created: {log_file}")
    
    # Create .gitkeep files for empty directories
    gitkeep_dirs = [
        "data/input_images",
        "data/outputs",
    ]
    
    for directory in gitkeep_dirs:
        gitkeep_file = Path(directory) / ".gitkeep"
        if not gitkeep_file.exists():
            gitkeep_file.touch()
            print(f"✅ Created: {gitkeep_file}")
    
    print("\n🎉 Project structure created successfully!")
    print("\nNext steps:")
    print("1. Place your .pth model files in 'modelweights/' directory")
    print("2. Add sample images to 'data/input_images/' directory")
    print("3. Run 'pip install -r requirements.txt'")
    print("4. Run 'python run.py' or 'streamlit run app/ui/dashboard.py'")


if __name__ == "__main__":
    create_directory_structure()