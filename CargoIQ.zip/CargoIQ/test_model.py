"""
Test the model loading and detection
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import torch

def test_model():
    print("="*60)
    print("CargoIQ Model Test")
    print("="*60)
    
    # Check GPU
    print(f"\n🎮 CUDA Available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"   GPU: {torch.cuda.get_device_name(0)}")
        print(f"   VRAM: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    
    # Check model files
    print(f"\n📦 Model Files:")
    modelweights = Path("modelweights")
    for f in modelweights.glob("*.pth"):
        size_mb = f.stat().st_size / (1024**2)
        print(f"   - {f.name}: {size_mb:.1f} MB")
    
    # Try loading model info
    print(f"\n🔍 Analyzing Model...")
    
    ddod_path = modelweights / "ddod_r101_with_RoR1.pth"
    if ddod_path.exists():
        checkpoint = torch.load(ddod_path, map_location='cpu')
        print(f"   Type: {type(checkpoint)}")
        if isinstance(checkpoint, dict):
            print(f"   Keys: {list(checkpoint.keys())}")
            if 'meta' in checkpoint:
                print(f"   Meta: {checkpoint['meta'].keys() if isinstance(checkpoint['meta'], dict) else checkpoint['meta']}")
    
    # Test detector
    print(f"\n🧪 Testing Detector...")
    try:
        from app.models.detector import get_detector
        
        detector = get_detector(model_name="ddod")
        info = detector.get_model_info()
        
        print(f"   Model: {info['model_name']}")
        print(f"   Simulation Mode: {info['is_simulation']}")
        print(f"   Device: {info['device']}")
        print(f"   MMDet Available: {info['mmdet_available']}")
        
        # Test detection
        print(f"\n📷 Testing Detection...")
        from PIL import Image
        
        # Create test image
        test_img = Image.new('RGB', (640, 480), (128, 128, 128))
        
        detections = detector.detect(test_img)
        print(f"   Detections: {len(detections)}")
        for d in detections[:5]:
            print(f"   - {d.label}: {d.confidence:.2%}")
        
        print(f"\n✅ Model test complete!")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_model()